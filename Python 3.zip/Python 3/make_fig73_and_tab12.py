#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make_fig73_and_tab12.py — Fig.73 spider + Tabella riassuntiva (auto-rigenerante, v4)

Requisiti: Python 3, pandas, numpy
"""

import argparse, os, glob, re, json, math
import numpy as np
import pandas as pd

# -------------------- util --------------------

def log(msg, kind="INFO", verbose=True):
    if verbose:
        print(f"[{kind}] {msg}")

def clamp01(x):
    try:
        x = float(x)
    except Exception:
        x = 0.0
    return max(0.0, min(1.0, x))

def norm_col(s: str) -> str:
    s2 = re.sub(r'[^0-9a-zA-Z]+', '_', str(s).strip().lower())
    return re.sub(r'_+', '_', s2).strip('_')

def norm_cols(df):
    return {norm_col(c): c for c in df.columns}

def read_csv_any(path):
    try:
        return pd.read_csv(path)
    except Exception:
        try:
            return pd.read_csv(path, sep=None, engine="python")
        except Exception:
            return pd.read_csv(path, delimiter=r"\s+", engine="python")

def read_json_records(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        data = json.load(f)
    if isinstance(data, dict):
        return pd.DataFrame(data)
    if isinstance(data, list):
        return pd.DataFrame(data)
    return pd.json_normalize(data)

def read_any_table(path):
    p = path.lower()
    if p.endswith(".csv"):
        return read_csv_any(path)
    if p.endswith(".json") or p.endswith(".geojson"):
        return read_json_records(path)
    if p.endswith(".txt"):
        try:
            return read_csv_any(path)
        except Exception:
            rows = []
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    nums = [float(x) for x in re.findall(r'[-+]?\d+(?:\.\d+)?', line)]
                    if nums:
                        rows.append({"vals": nums})
            return pd.DataFrame(rows)
    return None

def find_files(root, patterns):
    out = []
    for pat in patterns:
        out.extend(glob.glob(os.path.join(root, pat)))
    return sorted(set(out))

def load_summary_index(root, verbose):
    for name in ("sommary.csv", "summary.csv"):
        p = os.path.join(root, name)
        if os.path.isfile(p):
            df = read_csv_any(p)
            fcols = [c for c in df.columns if norm_col(c) in ("filename","file","path")]
            ccols = [c for c in df.columns if "column" in norm_col(c)]
            if fcols and ccols:
                fn, cc = fcols[0], ccols[0]
                m = {}
                for _, r in df.iterrows():
                    fnm = str(r[fn]).strip()
                    if not fnm:
                        continue
                    cols = str(r[cc])
                    lst = [norm_col(x) for x in re.split(r'[|,;]', cols) if x.strip()]
                    m[fnm] = set(lst)
                log(f"Caricato indice colonne da {name} ({len(m)} file).", "INFO", verbose)
                return m
            else:
                log(f"{name} non ha (filename/columns) riconoscibili; lo ignoro.", "WARN", verbose)
    log("Nessun sommary/summary.csv trovato (procedo senza indice).", "WARN", verbose)
    return {}

def score_candidates(summary_map, need_any=(), need_all=(), hints=()):
    if not summary_map:
        return []
    req_any = {norm_col(x) for x in need_any}
    req_all = {norm_col(x) for x in need_all}
    hh      = [norm_col(x) for x in hints]
    scored = []
    for f, cols in summary_map.items():
        base = norm_col(os.path.basename(f))
        if hh and not any(h in base for h in hh):
            continue
        score = 0
        miss_all = len(req_all - cols)
        score += 2 * (len(req_all) - miss_all) - 3 * miss_all
        score += sum(1 for x in req_any if x in cols)
        if score > 0:
            scored.append((score, f))
    return [f for s, f in sorted(scored, key=lambda t: t[0], reverse=True)]

def first_number(series):
    s = pd.to_numeric(series, errors="coerce").dropna()
    return None if s.empty else float(s.iloc[0])

# ---------- helper per ricostruzione geometriche (ridge/edge) ----------

def small_angle_xy(l_deg, b_deg):
    l = np.asarray(l_deg, dtype=float)
    b = np.asarray(b_deg, dtype=float)
    x = l * np.cos(np.deg2rad(b))
    y = b
    return x, y

def local_pca_angle_deg(x, y, k=6):
    n = len(x)
    ang = np.full(n, np.nan, dtype=float)
    dx = x[:, None] - x[None, :]
    dy = y[:, None] - y[None, :]
    d2 = dx*dx + dy*dy
    np.fill_diagonal(d2, np.inf)
    for i in range(n):
        nn = np.argsort(d2[i])[:max(2, min(k, n-1))]
        X = np.column_stack([x[nn] - x[i], y[nn] - y[i]])
        if X.shape[0] < 2:
            continue
        _, _, Vt = np.linalg.svd(X, full_matrices=False)
        vx, vy = Vt[0]
        ang[i] = (np.degrees(np.arctan2(vy, vx)) + 360.0) % 180.0
    return ang

def endpoints_to_angle_deg(l1, b1, l2, b2):
    l1 = np.asarray(l1, dtype=float); b1 = np.asarray(b1, dtype=float)
    l2 = np.asarray(l2, dtype=float); b2 = np.asarray(b2, dtype=float)
    bmid = 0.5*(b1 + b2)
    dx = (l2 - l1) * np.cos(np.deg2rad(bmid))
    dy = (b2 - b1)
    ang = (np.degrees(np.arctan2(dy, dx)) + 360.0) % 180.0
    return ang

# -------------------- METRICHE --------------------

# 1) ALIGNMENT STRENGTH
def metric_alignment_strength(root, summary, verbose):
    easy = find_files(root, ["fig69_stats.csv","*fig69*stats*.csv",
                             "fig69_angles.csv","*angles*.csv","*dtheta*.csv","*delta*theta*.csv"])
    cand_sum = score_candidates(summary,
        need_any=("r","rayleigh_r","mean_abs_cos","abs_cos","z","n","delta","dtheta","delta_deg","angle","angles"),
        hints=("fig69","rayleigh","angles","align"))
    candidates = [*(os.path.join(root,c) if not os.path.isabs(c) else c for c in cand_sum), *easy]

    tried = set()
    for p in candidates:
        if not os.path.isfile(p) or p in tried:
            continue
        tried.add(p)
        try:
            df = read_any_table(p)
            if df is None or df.empty:
                continue
            L = norm_cols(df)

            # R diretto
            for key in ("r","rayleigh_r","r_axial","rstat","rayleighr"):
                k = norm_col(key)
                if k in L:
                    raw = first_number(df[L[k]])
                    if raw is not None:
                        return dict(metric="alignment_strength", value=raw, norm=clamp01(raw), source=os.path.basename(p))

            # mean |cos Δθ| (anche 'abs_cos' distribuzionale)
            for key in ("mean_abs_cos","mean_cosabs","mean_cos","mean_abs_cos_dtheta","mean_cos_delta","abs_cos"):
                k = norm_col(key)
                if k in L:
                    vals = pd.to_numeric(df[L[k]], errors="coerce").dropna()
                    if vals.empty:
                        continue
                    raw = float(np.nanmean(vals))
                    norm = clamp01((raw-0.5)/0.5)
                    return dict(metric="alignment_strength", value=raw, norm=norm, source=os.path.basename(p))

            # Z e N -> R = sqrt(Z/N)
            zcol = next((L[c] for c in L if c in ("z","rayleigh_z","zstat","z_axial")), None)
            ncol = next((L[c] for c in L if c in ("n","nsamp","n_samples","count","num","samples")), None)
            if zcol is not None and ncol is not None:
                z = first_number(df[zcol]); n = first_number(df[ncol])
                if z is not None and n and n>0:
                    R = float(np.sqrt(max(0.0, z)/n))
                    return dict(metric="alignment_strength", value=R, norm=clamp01(R), source=os.path.basename(p))

            # Δθ (rad/gradi) -> R = |mean(exp(i*2Δθ))|
            for key in ("delta","dtheta","delta_theta","delta_rad","delta_deg","angle","angles","angle_diff"):
                k = norm_col(key)
                if k in L:
                    a = pd.to_numeric(df[L[k]], errors="coerce").dropna().to_numpy()
                    if len(a) >= 3:
                        if np.nanmax(np.abs(a)) > np.pi*1.1:  # gradi
                            a = np.deg2rad(a)
                        R = float(np.abs(np.mean(np.exp(1j*2.0*a))))
                        return dict(metric="alignment_strength", value=R, norm=clamp01(R), source=os.path.basename(p))

        except Exception as e:
            log(f"alignment_strength: errore con {os.path.basename(p)} ({e})", "WARN", verbose)

    log("alignment_strength non derivabile (mancano Δθ/R/Z&N).", "WARN", verbose)
    return None

# 2) FILAMENT ENRICHMENT
def patch_area_guess(root):
    for p in find_files(root, ["selection_map.csv","*selection*map*.csv"]):
        try:
            df = read_csv_any(p)
            L = norm_cols(df)
            for k in ("area_deg2","area","pixel_area","pix_area"):
                kk = norm_col(k)
                if kk in L:
                    s = pd.to_numeric(df[L[kk]], errors="coerce"); s = s[np.isfinite(s)]
                    if len(s)>0:
                        return max(1e-6, float(s.sum()))
        except Exception:
            pass
    return 0.816  # fallback dal testo

def metric_filament_enrichment(root, summary, verbose):
    easy = find_files(root, ["fig67_enrichment*.csv","*enrichment*.csv"])
    cand_sum = score_candidates(summary,
        need_any=("enrichment","ratio","obs_over_null","delta_f","f_obs","observed","null_median","expected"),
        hints=("fig67","enrichment","arms","gmc"))
    candidates = [*(os.path.join(root,c) if not os.path.isabs(c) else c for c in cand_sum), *easy]

    for p in candidates:
        try:
            df = read_any_table(p)
            if df is None or df.empty:
                continue
            L = norm_cols(df)
            # ratio diretto
            for key in ("ratio","enrichment_ratio","obs_over_null","ratio_obs_null"):
                k = norm_col(key)
                if k in L:
                    raw = float(np.nanmedian(pd.to_numeric(df[L[k]], errors="coerce")))
                    norm = clamp01((raw-1.0)/(2.0-1.0))
                    return dict(metric="filament_enrichment", value=raw, norm=norm, source=os.path.basename(p))
            # Δf = obs - null
            obs, nul = None, None
            for k in ("observed","obs","f_obs"):
                kk = norm_col(k)
                if kk in L: obs = pd.to_numeric(df[L[kk]], errors="coerce")
            for k in ("null_median","null","f_null","expected","null_mean"):
                kk = norm_col(k)
                if kk in L: nul = pd.to_numeric(df[L[kk]], errors="coerce")
            if obs is not None and nul is not None and obs.notna().any() and nul.notna().any():
                raw = float(np.nanmedian(obs - nul))
                norm = clamp01(raw)
                return dict(metric="filament_enrichment", value=raw, norm=norm, source=os.path.basename(p))
        except Exception as e:
            log(f"filament_enrichment: errore con {os.path.basename(p)} ({e})", "WARN", verbose)

    # fallback: distances_arms*.csv
    for p in find_files(root, ["distances_arms*.csv","*arms*distance*.csv"]):
        try:
            df = read_csv_any(p)
            L = norm_cols(df)
            dcol = None
            for key in ("distance_deg","dist_deg","d_deg","distance","dist"):
                kk = norm_col(key)
                if kk in L:
                    dcol = L[kk]; break
            if dcol is None:
                nums = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
                if not nums:
                    continue
                dcol = nums[0]
            d = pd.to_numeric(df[dcol], errors="coerce").dropna()
            if len(d)==0:
                continue
            f_obs = float((d <= 2.0).mean())
            A_patch = patch_area_guess(root)
            Ltot = None
            for q in ("ridge_length_deg","length_deg","len_deg","arcdeg"):
                qq = norm_col(q)
                if qq in L:
                    try:
                        Ltot = float(df[L[qq]].dropna().sum()); break
                    except Exception:
                        pass
            if Ltot is None:
                f_exp = min(1.0, (4.0 / max(0.1, math.sqrt(A_patch))))
            else:
                f_exp = min(1.0, (Ltot * 4.0) / max(1e-6, A_patch))
            raw = f_obs / max(1e-6, f_exp)
            norm = clamp01((raw-1.0)/(2.0-1.0))
            return dict(metric="filament_enrichment", value=raw, norm=norm, source=os.path.basename(p))
        except Exception as e:
            log(f"filament_enrichment (fallback distances_arms): {e}", "WARN", verbose)

    log("filament_enrichment non ricostruibile con gli artefatti presenti.", "WARN", verbose)
    return None

# 3) DENSITY CONTRAST (Q90/Q50)
def metric_density_contrast(root, summary, verbose):
    candidates = [*(os.path.join(root,c) if not os.path.isabs(c) else c
                    for c in score_candidates(summary, need_any=("q90","q50","density","counts","value"),
                                              hints=("filtered_density","density","gaia_codex")))]
    candidates += find_files(root, ["gaia_codex_filtered_density*.csv","*filtered_density*.csv","*density*.csv"])
    for p in candidates:
        try:
            df = read_any_table(p)
            if df is None or df.empty:
                continue
            L = norm_cols(df)

            def pick_q(df, L, names):
                for k in names:
                    kk = norm_col(k)
                    if kk in L:
                        s = pd.to_numeric(df[L[kk]], errors="coerce").dropna()
                        if len(s):
                            return float(np.nanmedian(s))
                for c_norm, c_orig in L.items():
                    if re.fullmatch(r'(q|p|quantile)(_)?(0[_\.]?9|90)', c_norm):
                        s = pd.to_numeric(df[c_orig], errors="coerce").dropna()
                        if len(s):
                            return float(np.nanmedian(s))
                return None

            q90 = pick_q(df, L, ["q90","p90","quantile_0_9","quantile90","q_90"])
            q50 = pick_q(df, L, ["q50","p50","quantile_0_5","quantile50","q_50","median"])
            if (q90 is None or q50 is None) or q50 == 0:
                dens = None
                for k in ("density","value","counts","n"):
                    kk = norm_col(k)
                    if kk in L:
                        s = pd.to_numeric(df[L[kk]], errors="coerce").dropna()
                        if len(s):
                            dens = s; break
                if dens is None:
                    nums = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
                    if not nums:
                        raise ValueError("nessuna colonna numerica")
                    variances = [(df[c].var(skipna=True), c) for c in nums]
                    dens = pd.to_numeric(df[max(variances)[1]], errors="coerce").dropna()
                q90 = float(dens.quantile(0.9)); q50 = float(dens.quantile(0.5))
            ratio = float(q90/q50)
            ratio_clip = min(2.0, max(1.0, ratio))
            norm = clamp01((2.0 - ratio_clip)/(2.0-1.0))  # 1→1, 2→0
            return dict(metric="density_contrast", value=ratio, norm=norm, source=os.path.basename(p))
        except Exception as e:
            log(f"density_contrast: errore con {os.path.basename(p)} ({e})", "WARN", verbose)
    log("density_contrast non derivabile.", "WARN", verbose)
    return None

# 4) RIDGE ALIGNMENT MAD (gradi; più basso=meglio) — robusto con ricostruzione
def metric_ridge_alignment_mad(root, summary, verbose):
    import math

    def _find_one(patterns):
        files = []
        for pat in patterns:
            files += glob.glob(os.path.join(root, pat))
        return sorted(set(files))

    def _normcols(df):  # comodo locale
        return {norm_col(c): c for c in df.columns}

    def _small_sep_deg(l1,b1,l2,b2):
        # distanza piccol-angolo (gradi)
        cb = np.cos(np.deg2rad(0.5*(b1+b2)))
        dl = (l2-l1)*cb
        db = (b2-b1)
        return np.hypot(dl, db)

    def _angle_deg(l1,b1,l2,b2):
        # orientazione edge/tangente (assiale); x=l cos b, y=b
        cb = np.cos(np.deg2rad(0.5*(b1+b2)))
        dx = (l2 - l1)*cb
        dy = (b2 - b1)
        ang = np.degrees(np.arctan2(dy, dx)) % 180.0
        return ang

    # --------- 1) carica EDGE (da l1,b1,l2,b2 oppure u,v + nodes) ----------
    edges = None

    # (a) edges con endpoint già in gradi
    for p in _find_one(["*edges*patch*.csv", "topo_edges*.csv", "topo_graph_edges*.csv"]):
        try:
            df = read_any_table(p)
            if df is None or df.empty: 
                continue
            L = _normcols(df)
            need = [("l1","b1","l2","b2"),
                    ("lon1","lat1","lon2","lat2"),
                    ("l1_deg","b1_deg","l2_deg","b2_deg")]
            hit = None
            for a,b,c,d in need:
                if all(x in L for x in (a,b,c,d)):
                    hit = (L[a],L[b],L[c],L[d]); break
            if hit:
                e = pd.DataFrame({
                    "l1": pd.to_numeric(df[hit[0]], errors="coerce"),
                    "b1": pd.to_numeric(df[hit[1]], errors="coerce"),
                    "l2": pd.to_numeric(df[hit[2]], errors="coerce"),
                    "b2": pd.to_numeric(df[hit[3]], errors="coerce"),
                }).dropna()
                if len(e):
                    edges = e
                    if verbose: log(f"ridge_alignment_mad: edges da {os.path.basename(p)} (endpoint espliciti).", "INFO", True)
                    break
        except: 
            pass

    # (b) edges come u,v + nodes
    if edges is None:
        # prova più file per edges e nodes
        edge_files = _find_one(["*edges*patch*.csv", "topo_edges*.csv"])
        node_files = _find_one(["clean_topo_nodes_patch*.csv","topo_nodes_patch*.csv","topo_nodes*.csv"])
        for pe in edge_files:
            try:
                E = read_any_table(pe); 
                if E is None or E.empty: 
                    continue
                Le = _normcols(E)
                # possibili nomi per le colonne endpoint
                for uv in (("u","v"),("src","dst"),("i","j"),("n1","n2"),("a","b")):
                    if all(x in Le for x in uv):
                        ucol, vcol = Le[uv[0]], Le[uv[1]]
                        # ora cerca nodes
                        for pn in node_files:
                            N = read_any_table(pn)
                            if N is None or N.empty: 
                                continue
                            Ln = _normcols(N)
                            # id nodo
                            nid = None
                            for cand in ("id","node","node_id","index"):
                                if cand in Ln: nid = Ln[cand]; break
                            if nid is None: 
                                continue
                            # long/lat
                            lkey = next((Ln[c] for c in ("l_deg","lon_deg","l","lon") if c in Ln), None)
                            bkey = next((Ln[c] for c in ("b_deg","lat_deg","b","lat") if c in Ln), None)
                            if lkey is None or bkey is None:
                                continue
                            Nd = N[[nid,lkey,bkey]].dropna().copy()
                            Nd.columns = ["id","l_deg","b_deg"]
                            # join doppio
                            J = E[[ucol,vcol]].copy()
                            J.columns = ["u","v"]
                            Ju = J.merge(Nd, left_on="u", right_on="id", how="left").rename(
                                columns={"l_deg":"l1","b_deg":"b1"})
                            Juv = Ju.merge(Nd, left_on="v", right_on="id", how="left").rename(
                                columns={"l_deg":"l2","b_deg":"b2"})
                            e = Juv[["l1","b1","l2","b2"]].dropna()
                            if len(e):
                                edges = e
                                if verbose: 
                                    log(f"ridge_alignment_mad: edges da {os.path.basename(pe)} + {os.path.basename(pn)} (join u,v→nodes).", "INFO", True)
                                break
                        if edges is not None:
                            break
                if edges is not None:
                    break
            except:
                pass

    if edges is None or edges.empty:
        log("ridge_alignment_mad non ricostruibile: edge non trovati (né endpoint espliciti né u,v+nodes).", "WARN", verbose)
        return None

    # calcola midpoint e orientazione per ogni edge
    e_arr = edges.to_numpy()
    l1,b1,l2,b2 = e_arr[:,0], e_arr[:,1], e_arr[:,2], e_arr[:,3]
    theta_e = _angle_deg(l1,b1,l2,b2)
    lm = 0.5*(l1+l2); bm = 0.5*(b1+b2)

    # --------- 2) carica ARM/RIDGE e crea tangenti ----------
    arms = None
    for p in _find_one(["arms_ridge_aligned*.csv","arms_ridge*.csv"]):
        try:
            A = read_any_table(p)
            if A is None or A.empty: 
                continue
            La = _normcols(A)
            lkey = next((La[c] for c in ("l_deg","lon_deg","l","lon") if c in La), None)
            bkey = next((La[c] for c in ("b_deg","lat_deg","b","lat") if c in La), None)
            gid  = next((La[c] for c in ("arm_id","ridge_id","id") if c in La), None)
            if lkey is None or bkey is None:
                continue
            if gid is None:
                A["__gid__"] = 0
                gid = "__gid__"
            A = A[[gid,lkey,bkey]].dropna().copy()
            A.columns = ["gid","l_deg","b_deg"]
            # ordina per “cammino” (se manca indice, usa la riga)
            A["_ord"] = np.arange(len(A))
            arms = A
            if verbose: log(f"ridge_alignment_mad: ridge/tangenti da {os.path.basename(p)}.", "INFO", True)
            break
        except:
            pass

    if arms is None or arms.empty:
        log("ridge_alignment_mad non ricostruibile: ridge non trovati.", "WARN", verbose)
        return None

    # costruisci tangenti per ogni braccio (differenze finite su coppie consecutive)
    segs = []
    for gid, G in arms.groupby("gid"):
        G = G.sort_values("_ord").reset_index(drop=True)
        if len(G) < 2:
            continue
        l = G["l_deg"].to_numpy(); b = G["b_deg"].to_numpy()
        l1, b1 = l[:-1], b[:-1]
        l2, b2 = l[1:],  b[1:]
        ang = _angle_deg(l1,b1,l2,b2)
        lm  = 0.5*(l1+l2); bm = 0.5*(b1+b2)
        segs.append(pd.DataFrame({"gid":gid, "lmid":lm, "bmid":bm, "phi":ang}))
    if not segs:
        log("ridge_alignment_mad: nessun segmento/tangente ricostruibile.", "WARN", verbose)
        return None
    T = pd.concat(segs, ignore_index=True)

    # --------- 3) per ogni edge, trova tangente più vicina e differenza assiale ----------
    # (KD tree “manuale” su piccole N: O(N*M) va bene per le nostre taglie)
    diffs = []
    for le, be, te in zip(lm, bm, theta_e):
        # distanza al segmento più vicino
        d = np.hypot((T["lmid"].to_numpy()-le)*np.cos(np.deg2rad(0.5*(T["bmid"].to_numpy()+be))),
                     (T["bmid"].to_numpy()-be))
        j = int(np.argmin(d))
        phi = float(T["phi"].iloc[j])
        # differenza assiale mod 180°
        diff = abs((te - phi + 90.0) % 180.0 - 90.0)
        diffs.append(diff)

    diffs = np.asarray(diffs, dtype=float)
    diffs = diffs[np.isfinite(diffs)]
    if len(diffs) == 0:
        log("ridge_alignment_mad: nessuna differenza angolare valida.", "WARN", verbose)
        return None

    raw = float(np.median(np.abs(diffs - np.median(diffs))))  # MAD in gradi
    norm = clamp01(1.0 - min(1.0, raw/30.0))
    return dict(metric="ridge_alignment_mad", value=raw, norm=norm, source="edges+nodes vs arms_ridge")


# 5) ECDF TAIL SLOPE
def metric_ecdf_tail_slope(root, summary, verbose):
    ins = find_files(root, ["ecdf_*_inside.*"])
    outs= find_files(root, ["ecdf_*_outside.*"])
    def key(p):
        b = os.path.basename(p)
        return (b.replace("_inside.csv","").replace("_outside.csv","")
                 .replace("_inside.json","").replace("_outside.json",""))
    insm = {key(p): p for p in ins}
    pairs= [(k, insm[k], p) for k,p in ((key(o),o) for o in outs) if k in insm]
    if not pairs:
        log("Nessuna coppia ecdf_*_inside/outside trovata.", "WARN", verbose)
        return None
    k, p_in, p_out = pairs[0]

    def slope(path):
        df = read_any_table(path)
        if df is None or df.empty:
            raise ValueError("ECDF vuota")
        L = norm_cols(df)
        xcol = next((L[c] for c in ("x","value","vt","mu","v_t","v") if c in L), None)
        ycol = next((L[c] for c in ("ecdf","cdf","f","y") if c in L), None)
        if xcol is None or ycol is None:
            raise ValueError("colonne ECDF non riconosciute")
        x = pd.to_numeric(df[xcol], errors="coerce").to_numpy()
        y = pd.to_numeric(df[ycol], errors="coerce").to_numpy()
        m = np.isfinite(x) & np.isfinite(y)
        x, y = x[m], y[m]
        if len(x) < 10:
            raise ValueError("serie ECDF troppo corta")
        n = max(5, int(0.2*len(x)))
        xs, ys = x[-n:], y[-n:]
        eps = 1e-9
        t = np.log(np.clip(1.0-ys, eps, 1.0))
        X = np.vstack([np.log(np.clip(xs, eps, None)), np.ones_like(xs)]).T
        beta, *_ = np.linalg.lstsq(X, t, rcond=None)
        return float(beta[0])

    try:
        s_in  = slope(p_in)
        s_out = slope(p_out)
        d = abs(s_in - s_out)
        norm = clamp01(1.0 - min(1.0, d/2.0))
        return dict(metric="ecdf_tail_slope", value=d, norm=norm,
                    source=f"{os.path.basename(p_in)} & {os.path.basename(p_out)}")
    except Exception as e:
        log(f"ECDF tail slope fallita: {e}", "WARN", verbose)
        return None

# -------------------- MAIN --------------------

def main():
    ap = argparse.ArgumentParser(description="Crea Fig.73 (spider CSV) e tabella LaTeX; ricostruisce metriche se mancano gli artefatti.")
    ap.add_argument("--root", default=".")
    ap.add_argument("--out-csv", default="fig73_spider_metrics.csv")
    ap.add_argument("--out-tex", default="tab12_summary.tex")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    root = os.path.abspath(args.root)
    summary = load_summary_index(root, args.verbose)

    calculators = [
        metric_alignment_strength,
        metric_filament_enrichment,
        metric_density_contrast,
        metric_ridge_alignment_mad,
        metric_ecdf_tail_slope,
    ]

    rows = []
    for fn in calculators:
        try:
            r = fn(root, summary, args.verbose)
            if r is not None:
                rows.append(r)
                log(f"{r['metric']}: value={r['value']:.6g} norm={r['norm']:.6g} (source={r['source']})", "INFO", args.verbose)
        except Exception as e:
            log(f"{fn.__name__}: {e}", "WARN", args.verbose)

    if not rows:
        log("Nessuna metrica calcolata. Controlla che in cartella ci siano almeno ECDF inside/outside o i CSV base.", "WARN", True)
        return

    df = pd.DataFrame(rows, columns=["metric","value","norm","source"])
    out_csv = os.path.join(root, args.out_csv)
    df.to_csv(out_csv, index=False)
    log(f"WROTE CSV: {out_csv} (rows={len(df)})", "WRITE", True)

    out_tex = os.path.join(root, args.out_tex)
    with open(out_tex, "w", encoding="utf-8") as f:
        f.write(r"\begin{table}[t]"+"\n")
        f.write(r"\centering"+"\n")
        f.write(r"\caption{Quantitative summary of cross-correlation metrics used in the Fig.~73 spider plot. \textit{Norm} is a $[0,1]$ heuristic score (higher is better).}"+"\n")
        f.write(r"\begin{tabular}{l r r l}"+"\n")
        f.write(r"\toprule"+"\n")
        f.write(r"Metric & Value & Norm & Source \\"+"\n")
        f.write(r"\midrule"+"\n")
        for _, r in df.iterrows():
            f.write(f"{str(r['metric']).replace('_','\\_')} & {float(r['value']):.3g} & {float(r['norm']):.3g} & {str(r['source']).replace('_','\\_')} \\\\\n")
        f.write(r"\bottomrule"+"\n")
        f.write(r"\end{tabular}"+"\n")
        f.write(r"\end{table}"+"\n")
    log(f"WROTE TeX: {out_tex}", "WRITE", True)

if __name__ == "__main__":
    main()
