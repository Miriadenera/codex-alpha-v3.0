#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make_fig67.py
-------------
Figure 67: (Left) histogram/ECDF of nearest-ridge distance d for min-basin centroids
with selection-preserving null band; (Right) bar chart of areal enrichment R with 95% CI
for each structural template (spiral arms, GMCs).

Inputs (expected in --root):
  - basins_min_centroids.csv      (l_deg, b_deg) for min-basin centroids (from 2.2)
  - topo_basins_patch.geojson     (optional, polygons) for per-basin area and area intersections
  - selection_map.csv             (l_deg, b_deg, S) gridded selection used only to size nulls (N)

Templates (provide any available; the script will compute what it can):
  - --arms template_arms.geojson  (LineString or MultiLineString ridges for spiral arms)
    or --arms-csv arms_ridge.csv  (columns: arm_id,l_deg,b_deg; grouped per arm_id as polyline)
  - --gmcs template_gmcs.geojson  (Polygon/MultiPolygon mask of GMC regions)
    or --gmc-csv gmc_catalog.csv  (columns: l_deg,b_deg,r_deg) interpreted as circular caps

Options:
  --arm-width-deg 0.5   Corridor half-width (deg) around arm ridges to build an area mask for enrichment
  --B 999               Number of null rotations (longitude shifts) for ECDF bands and CI
  --mc 4000             Monte Carlo samples for area estimation (per polygon)
  --make-fig            Also produce PDFs and LaTeX snippet
Outputs:
  - fig67_distances.csv             (per-centroid distances to ARM/GMC)
  - fig67_enrichment.csv            (R and CI per template)
  - fig67_left_distance.(pdf|png)   (Left panel)
  - fig67_right_enrichment.(pdf|png)(Right panel)
"""

import os, sys, json, math, argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# --------------------- spherical helpers ---------------------

def angdist_deg(l1, b1, l2, b2):
    """Great-circle distance (deg) between points (l1,b1) and (l2,b2)."""
    dl = np.radians((l2 - l1 + 540.0) % 360.0 - 180.0)
    b1r = np.radians(b1); b2r = np.radians(b2)
    s = np.sin((b2r-b1r)/2.0)**2 + np.cos(b1r)*np.cos(b2r)*np.sin(dl/2.0)**2
    c = 2.0*np.arcsin(np.sqrt(np.clip(s, 0.0, 1.0)))
    return np.degrees(c)

def sinabsb_deg(b_deg):
    return np.sin(np.deg2rad(np.abs(b_deg)))

def wrap_l(l):
    return (l % 360.0)

# --------------------- geometry helpers (flat-sky approx) ---------------------

def project_flat(l_deg, b_deg, l0=None, b0=None):
    """Flat-sky projection around (l0,b0); x = (l-l0) cos b0, y = (b-b0) in deg."""
    if l0 is None: l0 = float(np.mean(l_deg))
    if b0 is None: b0 = float(np.mean(b_deg))
    x = (wrap_l(l_deg - l0 + 180.0) - 180.0) * np.cos(np.deg2rad(b0))
    y = (b_deg - b0)
    return x, y, l0, b0

def point_in_poly(x, y, poly_xy):
    """Ray casting for (x,y) inside polygon poly_xy=[[x0,y0],...]."""
    inside = False
    n = len(poly_xy)
    for i in range(n):
        x1,y1 = poly_xy[i]
        x2,y2 = poly_xy[(i+1)%n]
        if ((y1>y) != (y2>y)) and (x < (x2-x1)*(y-y1)/(y2-y1+1e-15) + x1):
            inside = not inside
    return inside

def poly_area_xy(poly_xy):
    """Shoelace area (square deg in projected xy)."""
    x = np.array([p[0] for p in poly_xy]); y = np.array([p[1] for p in poly_xy])
    return 0.5*np.abs(np.dot(x, np.roll(y,-1)) - np.dot(y, np.roll(x,-1)))

def densify_line(l_list, b_list, max_step_deg=0.2):
    """Interpolate intermediate points along a polyline so that segment length <= max_step_deg."""
    out_l=[]; out_b=[]
    for i in range(len(l_list)-1):
        l1,b1 = l_list[i], b_list[i]
        l2,b2 = l_list[i+1], b_list[i+1]
        d = angdist_deg(l1,b1,l2,b2)
        nseg = max(1, int(math.ceil(d/max_step_deg)))
        for k in range(nseg):
            t = k/float(nseg)
            out_l.append(wrap_l(l1 + (l2-l1)*t))
            out_b.append(b1 + (b2-b1)*t)
    out_l.append(l_list[-1]); out_b.append(b_list[-1])
    return np.array(out_l), np.array(out_b)

# --------------------- loaders ---------------------

def load_basins_centroids(path):
    df = pd.read_csv(path)
    return df[["l_deg","b_deg"]].astype(float)

def load_geojson_polylines(path):
    obj = json.loads(Path(path).read_text(encoding="utf-8"))
    lines = []
    feats = obj.get("features", [])
    for f in feats:
        g = f.get("geometry", {})
        t = g.get("type","")
        coords = g.get("coordinates", [])
        if t == "LineString":
            ls = [(float(l)%360.0, float(b)) for (l,b) in coords]
            lines.append(ls)
        elif t == "MultiLineString":
            for seg in coords:
                ls = [(float(l)%360.0, float(b)) for (l,b) in seg]
                lines.append(ls)
    return lines

def load_geojson_polygons(path):
    obj = json.loads(Path(path).read_text(encoding="utf-8"))
    polys = []
    feats = obj.get("features", [])
    for f in feats:
        g = f.get("geometry", {})
        t = g.get("type","")
        coords = g.get("coordinates", [])
        if t == "Polygon":
            ring = coords[0]
            polys.append([(float(l)%360.0, float(b)) for (l,b) in ring])
        elif t == "MultiPolygon":
            for poly in coords:
                ring = poly[0]
                polys.append([(float(l)%360.0, float(b)) for (l,b) in ring])
    return polys

def load_arms_csv(path):
    df = pd.read_csv(path)
    if not {"arm_id","l_deg","b_deg"}.issubset(set(c.lower() for c in df.columns)):
        # try case-sensitive
        pass
    cols = {c.lower(): c for c in df.columns}
    arm_col = cols["arm_id"]; lcol=cols["l_deg"]; bcol=cols["b_deg"]
    lines = []
    for aid, grp in df.groupby(arm_col):
        lines.append(list(zip(grp[lcol].astype(float)%360.0, grp[bcol].astype(float))))
    return lines

def load_gmcs_csv(path):
    df = pd.read_csv(path)
    cols = {c.lower(): c for c in df.columns}
    lcol = cols["l_deg"]; bcol = cols["b_deg"]; rcol = cols.get("r_deg") or cols.get("radius_deg")
    if rcol is None:
        raise ValueError("gmc CSV needs a radius column r_deg or radius_deg.")
    return df[lcol].astype(float).values%360.0, df[bcol].astype(float).values, df[rcol].astype(float).values

# --------------------- distances ---------------------

def distances_to_ridges(lc, bc, polylines, max_step_deg=0.2, rot_deg=0.0):
    """Min angular distance (deg) from each centroid to any ridge (polyline list).
       rot_deg shifts ridges in longitude (for nulls)."""
    allL=[]; allB=[]
    for line in polylines:
        L = np.array([p[0] for p in line]); B = np.array([p[1] for p in line])
        L = wrap_l(L + rot_deg)
        Ld,Bd = densify_line(L,B,max_step_deg=max_step_deg)
        allL.append(Ld); allB.append(Bd)
    if not allL:
        return np.array([])
    Lcat = np.concatenate(allL); Bcat = np.concatenate(allB)
    # compute min distance per centroid
    dmin = np.full(len(lc), np.inf)
    for i,(l0,b0) in enumerate(zip(lc,bc)):
        d = angdist_deg(l0, b0, Lcat, Bcat)
        dmin[i] = float(np.min(d))
    return dmin

def distances_to_gmcs(lc, bc, gmcs_polys=None, gmcs_circles=None, rot_deg=0.0):
    """
    Distance to GMC masks:
      - gmcs_polys: list of polygon rings [(l,b),...]
      - gmcs_circles: tuple (L,B,R) with centers and radii in deg
      Rotates in longitude by rot_deg for nulls.
    Returns min distance (deg), 0 if inside any mask.
    """
    dmin = np.full(len(lc), np.inf)
    have_any = False
    if gmcs_polys:
        have_any = True
        for poly in gmcs_polys:
            L = wrap_l(np.array([p[0] for p in poly]) + rot_deg)
            B = np.array([p[1] for p in poly])
            # quick inside test via flat projection around poly mean
            x,y,l0,b0 = project_flat(L,B)
            poly_xy = list(zip(x,y))
            for i,(l0c,b0c) in enumerate(zip(lc,bc)):
                xc,yc,_,_ = project_flat(np.array([l0c]), np.array([b0c]), l0, b0)
                inside = point_in_poly(float(xc[0]), float(yc[0]), poly_xy)
                if inside:
                    dmin[i] = 0.0
                else:
                    # distance to vertices (approx); could be improved by densifying edges
                    d = angdist_deg(l0c, b0c, L, B)
                    dmin[i] = min(dmin[i], float(np.min(d)))
    if gmcs_circles is not None:
        have_any = True
        Lc,Bc,Rc = gmcs_circles
        Lc = wrap_l(Lc + rot_deg)
        for i,(l0c,b0c) in enumerate(zip(lc,bc)):
            d = angdist_deg(l0c, b0c, Lc, Bc)
            dmin[i] = min(dmin[i], float(np.max([0.0, np.min(d - Rc)])))
    if not have_any:
        return np.array([])
    return dmin

# --------------------- enrichment via Monte Carlo ---------------------

def monte_carlo_area_fraction(basin_polys, tmpl_mask, mc=4000):
    """
    Estimate R = (area(basin∩tmpl)/area(basin)) / (area(tmpl)/area(patch)).
    - basin_polys: list of polygon rings [(l,b),...]
    - tmpl_mask: function (l,b)-> bool inside-template?
    Uses flat projection around patch center.
    """
    # gather all vertices to set projection center & patch bbox
    Lall=[]; Ball=[]
    for poly in basin_polys:
        for l,b in poly: Lall.append(l); Ball.append(b)
    Lall = np.array(Lall); Ball = np.array(Ball)
    _,_,l0,b0 = project_flat(Lall,Ball)
    # patch bbox in projected xy
    xall,yall,_,_ = project_flat(Lall,Ball,l0,b0)
    xmin,xmax = np.min(xall), np.max(xall)
    ymin,ymax = np.min(yall), np.max(yall)

    # preproject basins
    bas_xy = []
    for poly in basin_polys:
        L = np.array([p[0] for p in poly]); B = np.array([p[1] for p in poly])
        x,y,_,_ = project_flat(L,B,l0,b0)
        bas_xy.append(list(zip(x,y)))

    # area(template)/area(patch) via MC over patch bbox
    rng = np.random.default_rng(123)
    Xp = rng.uniform(xmin, xmax, size=mc)
    Yp = rng.uniform(ymin, ymax, size=mc)
    # map (x,y)->(l,b) inverse approx
    def xy_to_lb(x,y):
        l = wrap_l(x/np.cos(np.deg2rad(b0)) + l0); b = y + b0
        return l,b
    Lp,Bp = xy_to_lb(Xp,Yp)
    inside_tmpl_patch = tmpl_mask(Lp,Bp)
    frac_tmpl = float(np.mean(inside_tmpl_patch))

    # per-basin intersection fraction
    frac_list = []
    for poly_xy in bas_xy:
        # sample uniformly in basin bbox
        xs = np.array([p[0] for p in poly_xy]); ys = np.array([p[1] for p in poly_xy])
        bxmin,bxmax = np.min(xs), np.max(xs)
        bymin,bymax = np.min(ys), np.max(ys)
        # rejection inside polygon
        X = rng.uniform(bxmin, bxmax, size=mc)
        Y = rng.uniform(bymin, bymax, size=mc)
        mask_in = np.array([point_in_poly(x,y,poly_xy) for x,y in zip(X,Y)])
        Xin = X[mask_in]; Yin = Y[mask_in]
        Lin,Bin = xy_to_lb(Xin,Yin)
        mask_t = tmpl_mask(Lin,Bin)
        if np.sum(mask_in)==0:
            frac_list.append(0.0)
        else:
            frac_list.append(float(np.mean(mask_t)))
    # average over basins
    num = float(np.mean(frac_list))
    R = num / (frac_tmpl + 1e-12)
    return R, num, frac_tmpl

# --------------------- template masks (callables) ---------------------

def make_arm_mask(polylines, width_deg):
    """Return callable mask(l,b)->bool: inside corridor within width_deg from any ridge."""
    def mask(L,B):
        L = np.asarray(L); B = np.asarray(B)
        # compute min distance to densified union
        dmin = np.full(L.shape, np.inf)
        allL=[]; allB=[]
        for line in polylines:
            Ls = np.array([p[0] for p in line]); Bs = np.array([p[1] for p in line])
            Ld,Bd = densify_line(Ls,Bs,max_step_deg=0.2)
            allL.append(Ld); allB.append(Bd)
        Lcat = np.concatenate(allL); Bcat = np.concatenate(allB)
        for i in range(L.size):
            d = angdist_deg(L[i], B[i], Lcat, Bcat)
            dmin[i] = np.min(d)
        return dmin <= width_deg
    return mask

def make_gmc_mask_from_polys(polys):
    """Return callable mask(l,b)->bool for polygon union (flat-sky approx)."""
    # choose projection center
    Lall=np.concatenate([np.array([p[0] for p in poly]) for poly in polys])
    Ball=np.concatenate([np.array([p[1] for p in poly]) for poly in polys])
    _,_,l0,b0 = project_flat(Lall,Ball)
    polys_xy = []
    for poly in polys:
        L = np.array([p[0] for p in poly]); B = np.array([p[1] for p in poly])
        x,y,_,_ = project_flat(L,B,l0,b0)
        polys_xy.append(list(zip(x,y)))
    def mask(L,B):
        x,y,_,_ = project_flat(np.asarray(L), np.asarray(B), l0,b0)
        res = np.zeros_like(x, dtype=bool)
        for poly_xy in polys_xy:
            res |= np.array([point_in_poly(xi,yi,poly_xy) for xi,yi in zip(x,y)])
        return res
    return mask

def make_gmc_mask_from_circles(Lc,Bc,Rc):
    def mask(L,B):
        L=np.asarray(L); B=np.asarray(B)
        res = np.zeros_like(L, dtype=bool)
        for l0,b0,r0 in zip(Lc,Bc,Rc):
            d = angdist_deg(L,B,l0,b0)
            res |= (d <= r0)
        return res
    return mask

# --------------------- main ---------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=str, default=".", help="working folder")
    ap.add_argument("--arms", type=str, default=None, help="arms template (GeoJSON lines)")
    ap.add_argument("--arms-csv", type=str, default=None, help="arms CSV with arm_id,l_deg,b_deg")
    ap.add_argument("--gmcs", type=str, default=None, help="GMCs template (GeoJSON polygons)")
    ap.add_argument("--gmc-csv", type=str, default=None, help="GMC CSV l_deg,b_deg,r_deg")
    ap.add_argument("--arm-width-deg", type=float, default=0.5, help="corridor half-width for arm mask (deg)")
    ap.add_argument("--B", type=int, default=999, help="null rotations")
    ap.add_argument("--mc", type=int, default=4000, help="MC samples per polygon")
    ap.add_argument("--make-fig", action="store_true", help="emit PDFs and LaTeX snippet")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    os.chdir(root)

    # data
    basins = load_basins_centroids(root/"basins_min_centroids.csv")
    lc = basins["l_deg"].values; bc = basins["b_deg"].values
    N = len(basins)

    # templates
    arm_lines = []
    if args.arms and Path(args.arms).exists():
        arm_lines = load_geojson_polylines(Path(args.arms))
    elif args.arms_csv and Path(args.arms_csv).exists():
        arm_lines = load_arms_csv(Path(args.arms_csv))

    gmc_polys = []
    gmc_circles = None
    if args.gmcs and Path(args.gmcs).exists():
        gmc_polys = load_geojson_polygons(Path(args.gmcs))
    elif args.gmc_csv and Path(args.gmc_csv).exists():
        gmc_circles = load_gmcs_csv(Path(args.gmc_csv))

    if (len(arm_lines)==0) and (len(gmc_polys)==0) and (gmc_circles is None):
        print("[FATAL] Provide at least one template for ARMS or GMCs.")
        sys.exit(2)

    # distances (data)
    d_arm = distances_to_ridges(lc, bc, arm_lines) if len(arm_lines)>0 else np.array([])
    d_gmc = distances_to_gmcs(lc, bc, gmc_polys, gmc_circles) if (len(gmc_polys)>0 or gmc_circles is not None) else np.array([])

    # null bands via rotations (longitude shifts)
    rng = np.random.default_rng(42)
    x_grid = np.linspace(0, np.pi/2, 61)  # in radians for ECDF of distances (deg converted)
    def ecdf(v):
        xs = np.sort(v); n=len(v); y = np.arange(1,n+1)/n
        return xs, y

    def null_band_distances(kind):
        ecdfs=[]
        for _ in range(args.B):
            rot = rng.uniform(0,360.0)
            if kind=="arm":
                d = distances_to_ridges(lc, bc, arm_lines, rot_deg=rot)
            else:
                d = distances_to_gmcs(lc, bc, gmc_polys, gmc_circles, rot_deg=rot)
            if d.size==0: 
                continue
            xs, ys = ecdf(np.radians(d))
            t = np.linspace(0, xs[-1], 61) if xs.size>0 else x_grid
            y_interp = np.interp(t, xs, ys, left=0.0, right=1.0)
            ecdfs.append(y_interp)
        if len(ecdfs)==0:
            return None
        arr = np.vstack(ecdfs)
        return t, np.percentile(arr, 50, axis=0), np.percentile(arr, 2.5, axis=0), np.percentile(arr, 97.5, axis=0)

    out_rows=[]
    if d_arm.size>0:
        pd.DataFrame({"d_deg": d_arm}).to_csv("distances_arms.csv", index=False)
        nb_arm = null_band_distances("arm")
    else:
        nb_arm=None
    if d_gmc.size>0:
        pd.DataFrame({"d_deg": d_gmc}).to_csv("distances_gmcs.csv", index=False)
        nb_gmc = null_band_distances("gmc")
    else:
        nb_gmc=None

    # enrichment R
    R_rows=[]
    # load basins polygons if present
    basin_polys = []
    if Path("topo_basins_patch.geojson").exists():
        basin_polys = load_geojson_polygons(Path("topo_basins_patch.geojson"))

    # ARM mask (corridor) for enrichment, only if we have arm_lines and basin_polys
    if basin_polys and len(arm_lines)>0:
        arm_mask = make_arm_mask(arm_lines, args.arm_width_deg)
        R_arm, num_arm, den_arm = monte_carlo_area_fraction(basin_polys, arm_mask, mc=args.mc)
        # bootstrap CI by resampling basins
        rng = np.random.default_rng(123)
        R_boot=[]
        for _ in range(500):
            idx = rng.integers(0, len(basin_polys), size=len(basin_polys))
            subset = [basin_polys[i] for i in idx]
            r,_n,_d = monte_carlo_area_fraction(subset, arm_mask, mc=max(1000, args.mc//2))
            R_boot.append(r)
        lo,hi = np.percentile(R_boot, [2.5,97.5])
        R_rows.append({"template":"Arms","R":R_arm,"ci_lo":lo,"ci_hi":hi})
    # GMC mask
    if basin_polys and (len(gmc_polys)>0 or gmc_circles is not None):
        if len(gmc_polys)>0:
            gmc_mask = make_gmc_mask_from_polys(gmc_polys)
        else:
            gmc_mask = make_gmc_mask_from_circles(*gmc_circles)
        R_gmc, num_gmc, den_gmc = monte_carlo_area_fraction(basin_polys, gmc_mask, mc=args.mc)
        rng = np.random.default_rng(124)
        R_boot=[]
        for _ in range(500):
            idx = rng.integers(0, len(basin_polys), size=len(basin_polys))
            subset = [basin_polys[i] for i in idx]
            r,_n,_d = monte_carlo_area_fraction(subset, gmc_mask, mc=max(1000, args.mc//2))
            R_boot.append(r)
        lo,hi = np.percentile(R_boot, [2.5,97.5])
        R_rows.append({"template":"GMCs","R":R_gmc,"ci_lo":lo,"ci_hi":hi})

    if R_rows:
        dfR = pd.DataFrame(R_rows)
        dfR.to_csv("fig67_enrichment.csv", index=False)

    # Save distances combined
    out = {"d_arm_deg": d_arm if d_arm.size>0 else np.array([]),
           "d_gmc_deg": d_gmc if d_gmc.size>0 else np.array([])}
    # left panel
    if args.make_fig:
        # Plot ECDF(s) with null bands
        fig, ax = plt.subplots(figsize=(5.0,3.2))
        if d_arm.size>0:
            xs,ys = ecdf(np.radians(d_arm))
            ax.plot(np.degrees(xs), ys, lw=2, label="Arms (data)")
            if nb_arm:
                t,med,lo,hi = nb_arm
                ax.fill_between(np.degrees(t), lo, hi, alpha=0.20, linewidth=0)
                ax.plot(np.degrees(t), med, ls="--", lw=1.2, label="Arms (null median)")
        if d_gmc.size>0:
            xs,ys = ecdf(np.radians(d_gmc))
            ax.plot(np.degrees(xs), ys, lw=2, label="GMCs (data)")
            if nb_gmc:
                t,med,lo,hi = nb_gmc
                ax.fill_between(np.degrees(t), lo, hi, alpha=0.20, linewidth=0)
                ax.plot(np.degrees(t), med, ls="--", lw=1.2, label="GMCs (null median)")
        ax.set_xlabel("Nearest-ridge distance $d$ [deg]")
        ax.set_ylabel("ECDF")
        ax.set_xlim(0, max(1.0, ax.get_xlim()[1]))
        ax.set_ylim(0,1)
        ax.legend(frameon=False, loc="lower right")
        fig.tight_layout()
        fig.savefig("fig67_left_distance.pdf", bbox_inches="tight")
        fig.savefig("fig67_left_distance.png", dpi=300, bbox_inches="tight")
        plt.close(fig)

        # Right panel: enrichment bars
        if R_rows:
            fig2, ax2 = plt.subplots(figsize=(3.0,3.2))
            xs = np.arange(len(R_rows))+1
            vals = [r["R"] for r in R_rows]
            lo = [r["ci_lo"] for r in R_rows]
            hi = [r["ci_hi"] for r in R_rows]
            ax2.bar(xs, vals, width=0.6)
            ax2.errorbar(xs, vals, yerr=[np.array(vals)-np.array(lo), np.array(hi)-np.array(vals)],
                         fmt="none", lw=1.2, capsize=3)
            ax2.set_xticks(xs, [r["template"] for r in R_rows])
            ax2.set_ylabel("Enrichment $R$")
            fig2.tight_layout()
            fig2.savefig("fig67_right_enrichment.pdf", bbox_inches="tight")
            fig2.savefig("fig67_right_enrichment.png", dpi=300, bbox_inches="tight")
            plt.close(fig2)

        # emit LaTeX snippet
        latex = r"""
% --- Fig. 67 (generated from Python) ---
\begin{figure}[t]
\centering
\begin{minipage}{0.68\linewidth}
  \centering
  \includegraphics[width=\linewidth]{fig67_left_distance.pdf}
\end{minipage}\hfill
\begin{minipage}{0.28\linewidth}
  \centering
  \includegraphics[width=\linewidth]{fig67_right_enrichment.pdf}
\end{minipage}
\caption{Nearest-ridge distance $d$ for min-basin centroids versus selection-preserving null bands (left; ECDFs), and areal enrichment $R$ with 95\% bootstrap confidence intervals for each structural template (right).}
\label{fig:arm_gmc_distance_enrichment}
\end{figure}
""".strip()
        Path("fig67_latex.txt").write_text(latex, encoding="utf-8")
        print(latex)

if __name__ == "__main__":
    main()
