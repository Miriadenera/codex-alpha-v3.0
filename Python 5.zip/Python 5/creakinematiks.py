import pandas as pd
import numpy as np

# Carica il dataset filtrato
df = pd.read_csv("gaia_codex_filtered_density.csv")

# Calcola il moto proprio totale in mas/yr
df['mu_total'] = np.sqrt(df['pmra']**2 + df['pmdec']**2)

# Calcola la velocità tangenziale in km/s
df['v_t_kms'] = 4.74 * df['mu_total'] * df['distance_pc'] / 1000

# Salva il nuovo file con i dati cinematici inclusi
df.to_csv("gaia_codex_with_kinematics.csv", index=False)

print("✅ File creato correttamente: gaia_codex_with_kinematics.csv")
