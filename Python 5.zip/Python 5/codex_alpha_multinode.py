from manim import *

class CodexAlphaMultiNode(ThreeDScene):
    def construct(self):
        self.set_camera_orientation(phi=60 * DEGREES, theta=45 * DEGREES)
        self.begin_ambient_camera_rotation(rate=0.05)

        def get_color_from_density(density):
            if density > 0.8:
                return RED
            elif density > 0.5:
                return ORANGE
            elif density > 0.2:
                return BLUE
            else:
                return TEAL

        def create_node(pos, color=BLUE, density=0.5):
            density_color = get_color_from_density(density)
            node = Sphere(radius=0.25, color=density_color).move_to(pos)

            # Vettori informazionali
            arrows = VGroup(*[
                Arrow3D(start=pos, end=pos + RIGHT * 0.7, color=WHITE, stroke_width=1.5),
                Arrow3D(start=pos, end=pos + UP * 0.7, color=WHITE, stroke_width=1.5)
            ])
            return node, arrows

        def create_wave_rings(pos, color=WHITE):
            rings = VGroup(*[
                Circle(radius=0.5 + i * 0.3, color=color, stroke_opacity=0.3).move_to(pos).rotate(PI / 2, axis=RIGHT)
                for i in range(4)
            ])
            return rings

        def animate_wave_rings(rings):
            return [ring.animate.scale(1.05).set_stroke(opacity=0.7) for ring in rings]

        # Crea i due nodi
        pos1 = LEFT * 2
        pos2 = RIGHT * 2
        node1, arrows1 = create_node(pos1, BLUE, density=0.7)
        node2, arrows2 = create_node(pos2, PURPLE, density=0.9)

        self.play(GrowFromCenter(node1), Create(arrows1), run_time=2)
        self.play(GrowFromCenter(node2), Create(arrows2), run_time=2)

        # Entanglement
        connection = ArcBetweenPoints(pos1, pos2, angle=PI/3, color=YELLOW).set_stroke(width=1.2)
        self.play(Create(connection), run_time=2)

        # Appare la pulsazione ∇𝒦 (solo ora)
        waves1 = create_wave_rings(pos1)
        waves2 = create_wave_rings(pos2)
        self.play(Create(waves1), Create(waves2), run_time=2)
        self.play(*animate_wave_rings(waves1), *animate_wave_rings(waves2), run_time=2)

        # Campo di flusso informazionale
        stream_lines = StreamLines(
            lambda p: np.array([-p[1], p[0], 0]),
            x_range=[-5, 5],
            y_range=[-3, 3],
            padding=1,
            stroke_width=1.2,
            max_anchors_per_line=25,
            color=WHITE
        )
        self.add(stream_lines)
        self.play(stream_lines.animate().shift(UP * 0.1), run_time=3)

        # Formula fissata alla camera
        formula = MathTex(
            r"\mathcal{G}_{\mu\nu} + \Lambda g_{\mu\nu} = \frac{8 \pi G}{c^4} \left\langle \hat{T}_{\mu\nu} \right\rangle_{\nabla \mathcal{K}}"
        ).scale(0.8).set_color(WHITE).to_edge(UP).shift(DOWN * 0.2)
        self.add_fixed_in_frame_mobjects(formula)
        self.play(Write(formula), run_time=3)

        # Testo descrittivo (dritto, no sfondo)
        label = Text("Informational Node ∇𝒦", font="Arial", color=WHITE).scale(0.4).next_to(node1, DOWN)
        self.add_fixed_orientation_mobjects(label)
        self.play(FadeIn(label), run_time=2)
        self.wait(1)
        self.play(FadeOut(label))

        # Motore nodale: traiettoria e movimento
        path = CubicBezier(pos1, pos1 + UP + RIGHT, pos2 + UP + LEFT, pos2)
        motor = Dot3D(pos1, radius=0.1, color=GOLD)
        self.add(motor)
        self.play(MoveAlongPath(motor, path), run_time=4)

        self.wait(2)
