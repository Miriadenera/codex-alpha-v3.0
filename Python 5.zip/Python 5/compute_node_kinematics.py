import numpy as np
import pandas as pd
from astropy.coordinates import SkyCoord
import astropy.units as u

# === file richiesti ===
NODES_CSV   = 'telascura_nodes_refined_min10_k6.csv'
MEMBERS_CSV = 'star_memberships_refined_min10_k6.csv'
GAIA_CSV    = 'gaia_codex_with_kinematics.csv'
OUT_CSV     = 'telascura_nodes_kin_coherence_min10_k6.csv'

# --- carica nodi ---
nodes = pd.read_csv(NODES_CSV)
nodes['s_n'] = np.sign(nodes['mean_gradK']).replace(0, 1)

# --- carica membership e gaia ---
memb = pd.read_csv(MEMBERS_CSV)
gaia = pd.read_csv(GAIA_CSV)

# === prepara i moti propri in galattiche ===
if {'mu_l_star','mu_b'}.issubset(gaia.columns):
    mu_lstar, mu_b = 'mu_l_star', 'mu_b'
elif {'pmra','pmdec','ra','dec'}.issubset(gaia.columns):
    # trasformo i moti propri a galattiche
    c_eq = SkyCoord(ra=gaia['ra'].values*u.deg, dec=gaia['dec'].values*u.deg,
                    pm_ra_cosdec=gaia['pmra'].values*u.mas/u.yr,
                    pm_dec=gaia['pmdec'].values*u.mas/u.yr, frame='icrs')
    c_gal = c_eq.galactic
    gaia['mu_l_star'] = c_gal.pm_l_cosb.to_value(u.mas/u.yr)
    gaia['mu_b']      = c_gal.pm_b.to_value(u.mas/u.yr)
    mu_lstar, mu_b = 'mu_l_star', 'mu_b'
else:
    raise ValueError("Servono (mu_l_star,mu_b) oppure (pmra,pmdec,ra,dec).")

# === merge robusto ===
if 'source_id' in memb.columns and 'source_id' in gaia.columns:
    # su source_id NON chiediamo l,b da gaia: usiamo quelli di membership
    mg = memb.merge(gaia[['source_id', mu_lstar, mu_b]], on='source_id', how='inner')
else:
    # fallback: allineamento su coordinate (l,b) arrotondate
    # membership ha già l,b; per gaia li creo se mancano
    if not {'l','b'}.issubset(gaia.columns):
        if {'ra','dec'}.issubset(gaia.columns):
            c_eq = SkyCoord(ra=gaia['ra'].values*u.deg, dec=gaia['dec'].values*u.deg, frame='icrs')
            gaia['l'] = c_eq.galactic.l.deg
            gaia['b'] = c_eq.galactic.b.deg
        else:
            raise ValueError("Fallback su (l,b): gaia deve avere ra,dec per calcolare l,b.")
    memb['l_r'], memb['b_r'] = memb['l'].round(6), memb['b'].round(6)
    gaia['l_r'], gaia['b_r'] = gaia['l'].round(6), gaia['b'].round(6)
    mg = memb.merge(gaia[['l_r','b_r', mu_lstar, mu_b]], on=['l_r','b_r'], how='inner')

# === metriche per nodo ===
rows = []
for _, nd in nodes.iterrows():
    cid   = nd['cluster']
    l_n   = nd['l_mean']
    b_n   = nd['b_mean']
    s_n   = nd['s_n']

    sub = mg[mg['cluster'] == cid].copy()
    N   = len(sub)
    if N < 3:
        rows.append([nd['ID_Node'], l_n, b_n, nd['mean_gradK'], N, np.nan, np.nan, np.nan, np.nan])
        continue

    # geometria locale (uso l,b dalla membership)
    dl = (sub['l'].values - l_n) * np.cos(np.deg2rad(b_n))
    db =  sub['b'].values - b_n
    r  = np.hypot(dl, db)
    rhat_l = np.divide(dl, r, out=np.zeros_like(dl), where=r>0)
    rhat_b = np.divide(db, r, out=np.zeros_like(db), where=r>0)

    mu_l  = sub[mu_lstar].values
    mu_bv = sub[mu_b].values
    mu    = np.hypot(mu_l, mu_bv)

    mu_r   = (mu_l*rhat_l + mu_bv*rhat_b)              # componente radiale
    dot    = (mu_l*(s_n*rhat_l) + mu_bv*(s_n*rhat_b))  # verso atteso (s_n rhat)
    cos_th = np.divide(dot, mu, out=np.zeros_like(dot), where=mu>0)
    cos_th = np.clip(cos_th, -1.0, 1.0)

    Phi = np.nanmean(np.divide(mu_r, mu, out=np.zeros_like(mu_r), where=mu>0))
    C   = np.nanmean(cos_th)

    theta = np.arccos(cos_th)
    z = np.exp(1j*theta)
    R = np.abs(np.mean(z))
    Z = N*(R**2)
    p = np.exp(-Z) * (1 + (2*Z - Z**2)/(4*N)
                        - (24*Z -132*Z**2 +76*Z**3 -9*Z**4)/(288*N**2))

    rows.append([nd['ID_Node'], l_n, b_n, nd['mean_gradK'], N, Phi, C, Z, p])

out = pd.DataFrame(rows, columns=[
    'ID_Node','l_mean','b_mean','mean_gradK','num_members','Phi','C','Z_Rayleigh','p_Rayleigh'
])
out.to_csv(OUT_CSV, index=False)
print("✅ Salvato:", OUT_CSV)
