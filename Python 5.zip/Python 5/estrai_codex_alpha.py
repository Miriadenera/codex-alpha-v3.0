import json
from datetime import datetime
import csv

# --- CONFIGURAZIONE ---
input_file = "conversations.json"
output_file = "codex_alpha_chatlog.csv"
parole_chiave = ["Codex Alpha", "Teoria Unificata", "Telascura", "Fase", "Motore Nodale"]

# --- FUNZIONE PER CONVERSIONE UNIX ---
def unix_to_datetime(timestamp):
    return datetime.utcfromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')

# --- LOGICA ---
with open(input_file, "r", encoding="utf-8") as f:
    data = json.load(f)

output_rows = []

for conv in data:
    title = conv.get("title", "")
    if any(kw.lower() in title.lower() for kw in parole_chiave):
        create_time = conv.get("create_time")
        readable_time = unix_to_datetime(create_time) if create_time else "N/A"
        output_rows.append([title, readable_time])

# --- SCRITTURA CSV ---
with open(output_file, "w", newline='', encoding="utf-8") as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(["Titolo Conversazione", "Data Creazione"])
    writer.writerows(output_rows)

print(f"\n✅ Estrazione completata! Salvato in: {output_file}")
