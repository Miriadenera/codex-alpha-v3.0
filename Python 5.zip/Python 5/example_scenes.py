from manim import *

class CatenoidSurface(ThreeDScene):
    def construct(self):
        # Imposta la fotocamera 3D
        self.set_camera_orientation(phi=70 * DEGREES, theta=45 * DEGREES)

        # Crea la superficie parametricamente
        surface = Surface(
            lambda u, v: np.array([
                np.cosh(u) * np.cos(v),
                np.cosh(u) * np.sin(v),
                u
            ]),
            u_range=[-2, 2],
            v_range=[0, TAU],
            resolution=(100, 100),
            fill_opacity=0.9,
            checkerboard_colors=[BLUE_D, WHITE]
        )

        axes = ThreeDAxes()

        self.add(axes)
        self.play(Create(surface), run_time=3)
        self.wait(1)
        self.begin_ambient_camera_rotation(rate=0.1)
        self.wait(5)
        self.stop_ambient_camera_rotation()
        self.play(FadeOut(surface), FadeOut(axes))
