import numpy as np
from astropy.io import fits
import matplotlib.pyplot as plt

# Caricamento mappa FITS (esempio: Planck HFI 143 GHz)
hdul = fits.open("HFI_SkyMap_143_2048_R3.00_full.fits")
cmb_data = hdul[1].data  # slice simulato per visualizzazione
hdul.close()

# Estrazione di una regione 100x100 pixel
cmb_slice = cmb_data[1000:1100, 1000:1100]

# Calcolo del gradiente informazionale
grad_y, grad_x = np.gradient(cmb_slice)

# Visualizzazione del campo vettoriale ∇𝒦
plt.figure(figsize=(8,6))
plt.quiver(grad_x, grad_y, color='navy', scale=5e-6)
plt.title("Campo ∇𝒦 estratto da mappa CMB Planck (slice)")
plt.xlabel("Pixel X")
plt.ylabel("Pixel Y")
plt.tight_layout()
plt.grid(True)
plt.savefig("campo_gradiente_planck_slice.png", dpi=300)
plt.show()
