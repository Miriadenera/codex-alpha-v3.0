from astropy.io.votable import parse_single_table
table = parse_single_table("1748519392555O-result.vot").to_table()
table.write("output.csv", format="csv", overwrite=True)
