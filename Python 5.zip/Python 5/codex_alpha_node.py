from manim import *

class CodexAlphaNode(ThreeDScene):
    def construct(self):
        # Setup camera 3D
        self.set_camera_orientation(phi=65 * DEGREES, theta=30 * DEGREES)

        # Nodo informazionale centrale
        node = Sphere(radius=0.4, resolution=(32, 64), fill_color=BLUE_E, fill_opacity=1)
        self.play(FadeIn(node, scale=0.5))

        # Onde ∇𝒦: Torus concentrici
        wave_surfaces = VGroup()
        for r in np.linspace(0.6, 3.0, 8):
            ring = Torus(
                major_radius=r,
                minor_radius=0.02,
                fill_opacity=0.15,
                fill_color=TEAL,
                stroke_color=WHITE,
                stroke_opacity=0.3,
            ).rotate(PI/2, axis=RIGHT)  # ruota il toro per allinearlo al piano XY
            wave_surfaces.add(ring)

        self.play(Create(wave_surfaces), run_time=3)
        self.wait(1)

        # Effetto ∇𝒦 dinamico: onde che si amplificano
        self.begin_ambient_camera_rotation(rate=0.15)
        self.play(
            wave_surfaces.animate.scale(1.1).set_opacity(0.2),
            node.animate.set_color(PURPLE_E).scale(1.1),
            run_time=3,
            rate_func=there_and_back
        )
        self.wait(2)
        self.stop_ambient_camera_rotation()

        # Dissolvi
        self.play(FadeOut(wave_surfaces), FadeOut(node))
