#!/usr/bin/env python3
import argparse, re, numpy as np, pandas as pd
from pathlib import Path

def try_read_csv(p):
    p = Path(p)
    if p.exists():
        try:
            return pd.read_csv(p)
        except Exception:
            return None
    return None

def pick(df, names, default=None):
    """Trova la prima colonna disponibile tra names (case-insensitive)."""
    if df is None: return default
    lowmap = {c.lower(): c for c in df.columns}
    for n in names:
        if n.lower() in lowmap:
            return df[lowmap[n.lower()]]
    return default

def add_row(rows, metric, label, value, null_med, null_lo, null_hi, p_raw="--", p_fdr="--"):
    def fmt(x):
        if x is None or (isinstance(x,float) and not np.isfinite(x)): return "--"
        try:
            return f"{float(x):.6g}"
        except Exception:
            return str(x)
    rows.append({
        "metric": metric,
        "label": label,
        "value": fmt(value),
        "null_med": fmt(null_med),
        "null_lo": fmt(null_lo),
        "null_hi": fmt(null_hi),
        "p_raw": str(p_raw) if p_raw is not None else "--",
        "p_fdr": str(p_fdr) if p_fdr is not None else "--",
    })

# ---- Fig. 71 quick recompute (light) if needed ----
def proj_flat(l,b):
    l0, b0 = np.nanmedian(l), np.nanmedian(b)
    x = (l - l0)*np.cos(np.deg2rad(b0)); y = (b - b0)
    return x, y

def plane_fit(x,y,w=None,dx=1.0):
    # binning semplice su griglia e fit Z ~ c + ax X + ay Y con pesi
    xmin,xmax = x.min(), x.max(); ymin,ymax = y.min(), y.max()
    nx = max(1,int(np.ceil((xmax-xmin)/dx))); ny = max(1,int(np.ceil((ymax-ymin)/dx)))
    xb = xmin + dx*(np.arange(nx)+0.5); yb = ymin + dx*(np.arange(ny)+0.5)
    N = np.zeros((ny,nx)); W = np.zeros_like(N)
    ix = np.clip(((x-xmin)/dx).astype(int),0,nx-1)
    iy = np.clip(((y-ymin)/dx).astype(int),0,ny-1)
    for i,j in zip(iy,ix):
        N[i,j]+=1
        W[i,j]+=(1.0 if w is None else w[iy==i][0])
    Z = N/(W+1e-9)
    YY, XX = np.meshgrid(yb, xb, indexing="ij")
    m = (W>0)
    Xv, Yv, Zv, Wv = XX[m].ravel(), YY[m].ravel(), Z[m].ravel(), W[m].ravel()
    A = np.c_[np.ones_like(Xv), Xv, Yv]
    Wd = np.diag(Wv/np.maximum(Wv.mean(),1e-12))
    beta = np.linalg.lstsq(A.T@Wd@A, A.T@Wd@Zv, rcond=None)[0]
    c, ax, ay = beta
    Aamp = float(np.hypot(ax,ay))
    return Aamp

def quick_dipole_A(centroids_csv, sel_csv=None, colL=("l_deg_aligned","l_deg","l"),
                    colB=("b_deg","b"), grid=1.0, B=200, seed=7):
    C = pd.read_csv(centroids_csv)
    cL = [c for c in C.columns if c.lower() in [x.lower() for x in colL]]
    cB = [c for c in C.columns if c.lower() in [x.lower() for x in colB]]
    if not cL or not cB: return None
    l = pd.to_numeric(C[cL[0]], errors="coerce").values
    b = pd.to_numeric(C[cB[0]], errors="coerce").values
    m = np.isfinite(l)&np.isfinite(b); l,b = l[m],b[m]
    x,y = proj_flat(l,b)
    # pesi S(l,b) opzionali via nearest
    w = np.ones_like(x)
    if sel_csv and Path(sel_csv).exists():
        S = pd.read_csv(sel_csv)
        cLS = [c for c in S.columns if c.lower() in ("l_deg_aligned","l_deg","l","lon","longitude")]
        cBS = [c for c in S.columns if c.lower() in ("b_deg","b","lat","latitude")]
        cSS = [c for c in S.columns if c.lower().startswith("s")]
        if cLS and cBS and cSS:
            LS = pd.to_numeric(S[cLS[0]], errors="coerce").values
            BS = pd.to_numeric(S[cBS[0]], errors="coerce").values
            SS = pd.to_numeric(S[cSS[0]], errors="coerce").values
            xS,yS = proj_flat(LS,BS)
            idx = np.argmin((x[:,None]-xS[None,:])**2+(y[:,None]-yS[None,:])**2, axis=1)
            w = np.maximum(SS[idx], 1e-6)
            w = w/np.nanmedian(w)
    A = plane_fit(x,y,w,dx=grid)
    rng = np.random.RandomState(seed)
    A_null=[]
    for th in rng.uniform(0,360,size=B):
        t = np.deg2rad(th)
        xr = x*np.cos(t)-y*np.sin(t)
        yr = x*np.sin(t)+y*np.cos(t)
        A_null.append( plane_fit(xr,yr,w,dx=grid) )
    A_null = np.array(A_null)
    med = np.nanmedian(A_null)
    lo,hi = np.nanpercentile(A_null,[2.5,97.5])
    return A, med, lo, hi

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-csv", default="fig73_spider_metrics.csv")
    ap.add_argument("--also-tab12", action="store_true")
    ap.add_argument("--out-tex", default="tab12_summary.tex")
    # percorsi attesi (modifica se hai nomi diversi)
    ap.add_argument("--fig66", default="fig66_metrics.csv")
    ap.add_argument("--fig67_enr", default="fig67_enrichment.csv")
    ap.add_argument("--dist_arms", default="distances_arms.csv")
    ap.add_argument("--dist_gmcs", default="distances_gmcs.csv")
    ap.add_argument("--fig68", default="fig68_betas_auc.csv")
    ap.add_argument("--fig69", default="fig69_stats.csv")
    ap.add_argument("--fig70_all", default="fig70_metrics.csv")
    ap.add_argument("--fig70_w", default="fig70_wtheta_stats.csv")
    ap.add_argument("--fig70_align", default="fig70_align_stats.csv")
    ap.add_argument("--fig71_metrics", default="fig71_metrics.csv")
    ap.add_argument("--centroids", default="basins_min_centroids.csv")
    ap.add_argument("--selection", default="selection_map_aligned.csv")
    args = ap.parse_args()

    rows = []

    # ---- Fig. 66 ----
    df66 = try_read_csv(args.fig66)
    if df66 is not None:
        # value: Δmed(sin|b|)
        val = pick(df66, ["delta_med_sinb","dmed_sinb","value"])
        nmed = pick(df66, ["null_med","sinb_null_med"])
        nlo  = pick(df66, ["null_lo","sinb_null_lo","ci_lo"])
        nhi  = pick(df66, ["null_hi","sinb_null_hi","ci_hi"])
        pval = pick(df66, ["p_kuiper","p_watson","p_value"])
        if val is not None and nmed is not None and nlo is not None and nhi is not None:
            add_row(rows, "plane_ecdf", "Plane ECDF (sin|b|)",
                    float(val.iloc[0]), float(nmed.iloc[0]), float(nlo.iloc[0]), float(nhi.iloc[0]),
                    p_raw=(pval.iloc[0] if pval is not None else "--"))

    # ---- Fig. 67 enrichment ----
    df67e = try_read_csv(args.fig67_enr)
    if df67e is not None and len(df67e):
        # tenta colonne generiche
        tmpl_col = pick(df67e, ["template","name","type"], default=pd.Series(["?"]*len(df67e)))
        obs  = pick(df67e, ["R_obs","obs","value"])
        nmed = pick(df67e, ["null_med","R_null_med","null_median"])
        nlo  = pick(df67e, ["null_lo","R_null_lo"])
        nhi  = pick(df67e, ["null_hi","R_null_hi"])
        pval = pick(df67e, ["p","p_value"])
        for i in range(len(df67e)):
            lbl = str(tmpl_col.iloc[i]).strip().lower()
            nice = "arms" if "arm" in lbl else ("GMCs" if "gmc" in lbl else lbl)
            if obs is not None and nmed is not None and nlo is not None and nhi is not None:
                add_row(rows, f"enrich_{nice}",
                        f"Area enrichment R ({nice})",
                        float(obs.iloc[i]), float(nmed.iloc[i]), float(nlo.iloc[i]), float(nhi.iloc[i]),
                        p_raw=(pval.iloc[i] if pval is not None else "--"))

    # ---- Fig. 67 distance KS (opzionale) ----
    for tag, path in [("arms","dist_arms"), ("gmcs","dist_gmcs")]:
        dfd = try_read_csv(getattr(args, path))
        if dfd is not None:
            Dval = pick(dfd, ["ks_D","ksd","D","value"])
            nmed = pick(dfd, ["null_med"])
            nlo  = pick(dfd, ["null_lo"])
            nhi  = pick(dfd, ["null_hi"])
            pval = pick(dfd, ["p","p_value"])
            if Dval is not None and nmed is not None and nlo is not None and nhi is not None:
                add_row(rows, f"{tag}_dist",
                        f"Dist. to {tag} (KS D)",
                        float(Dval.iloc[0]), float(nmed.iloc[0]), float(nlo.iloc[0]), float(nhi.iloc[0]),
                        p_raw=(pval.iloc[0] if pval is not None else "--"))

    # ---- Fig. 68 betas ----
    df68 = try_read_csv(args.fig68)
    if df68 is not None and len(df68):
        name_map = {
          "beta_abs_b": ("beta_b", "Logit β(|b|)"),
          "beta_Sigma_star": ("beta_sigma", "Logit β(Σ*)"),
          "beta_Sel": ("beta_S", "Logit β(S)")
        }
        beta_col = pick(df68, ["beta"])
        hat  = pick(df68, ["hat","beta_hat","coef"])
        lo   = pick(df68, ["ci_lo","lo","lower"])
        hi   = pick(df68, ["ci_hi","hi","upper"])
        if beta_col is not None and hat is not None and lo is not None and hi is not None:
            for i in range(len(df68)):
                bname = str(beta_col.iloc[i])
                key = name_map.get(bname, (None,None))
                if key[0] is None:  # prova match per contenuto
                    if "|b|" in bname: key=("beta_b","Logit β(|b|)")
                    elif "sigma" in bname.lower(): key=("beta_sigma","Logit β(Σ*)")
                    elif "sel" in bname.lower(): key=("beta_S","Logit β(S)")
                if key[0]:
                    se = (float(hi.iloc[i]) - float(lo.iloc[i]))/3.92 if np.isfinite(float(hi.iloc[i])) and np.isfinite(float(lo.iloc[i])) else np.nan
                    add_row(rows, key[0], key[1],
                            float(hat.iloc[i]),
                            0.0, -1.96*se if np.isfinite(se) else None, +1.96*se if np.isfinite(se) else None)

    # ---- Fig. 69 stats ----
    df69 = try_read_csv(args.fig69)
    if df69 is not None and len(df69):
        # Rayleigh Z
        Zhat = pick(df69, ["Z_hat","rayleigh_Z","Z"])
        Zlo  = pick(df69, ["Z_lo","null_lo_Z","null_Z_lo"])
        Zhi  = pick(df69, ["Z_hi","null_hi_Z","null_Z_hi"])
        Zmed = pick(df69, ["Z_null_med","null_med_Z","null_Z_med"])
        if Zhat is not None and (Zlo is not None and Zhi is not None):
            add_row(rows, "rayleighZ","Rayleigh Z (nearby gals)",
                    float(Zhat.iloc[0]),
                    float(Zmed.iloc[0]) if Zmed is not None else 0.0,
                    float(Zlo.iloc[0]), float(Zhi.iloc[0]))
        # <|cosΔθ|>-0.5
        C_hat = pick(df69, ["cos_mean","mean_cos","mean_abs_cos"])
        C_lo  = pick(df69, ["cos_null_lo","null_lo_cos","null_lo"])
        C_hi  = pick(df69, ["cos_null_hi","null_hi_cos","null_hi"])
        C_med = pick(df69, ["cos_null_med","null_med_cos","null_med"])
        if C_hat is not None and C_lo is not None and C_hi is not None:
            add_row(rows, "cos_dtheta","<|cos Δθ|>-0.5",
                    float(C_hat.iloc[0])-0.5,
                    0.0,
                    float(C_lo.iloc[0])-0.5, float(C_hi.iloc[0])-0.5)

    # ---- Fig. 70 (se disponibile) ----
    # prova file unico
    df70 = try_read_csv(args.fig70_all)
    if df70 is not None and len(df70):
        # w(theta)
        Wval = pick(df70, ["w_amp","wtheta_amp","value_w"])
        Wmed = pick(df70, ["w_null_med"])
        Wlo  = pick(df70, ["w_null_lo"])
        Whi  = pick(df70, ["w_null_hi"])
        if Wval is not None and Wmed is not None and Wlo is not None and Whi is not None:
            add_row(rows, "wtheta_amp","w(θ) amplitude",
                    float(Wval.iloc[0]), float(Wmed.iloc[0]), float(Wlo.iloc[0]), float(Whi.iloc[0]))
        # local align
        Aval = pick(df70, ["align_val","align_mean","cos_align"])  # già centrato?
        Alo  = pick(df70, ["align_null_lo"])
        Ahi  = pick(df70, ["align_null_hi"])
        Amed = pick(df70, ["align_null_med"])
        if Aval is not None and Alo is not None and Ahi is not None:
            # se è una media di |cos|, centra a -0.5 (assumo)
            add_row(rows, "local_align","Local align <|cos(θ-φ)|>-0.5",
                    float(Aval.iloc[0]) - 0.5,
                    0.0,
                    float(Alo.iloc[0]) - 0.5, float(Ahi.iloc[0]) - 0.5)

    # prova file separati
    if df70 is None:
        df70w = try_read_csv(args.fig70_w)
        if df70w is not None and len(df70w):
            add_row(rows, "wtheta_amp","w(θ) amplitude",
                    float(pick(df70w,["value","w_amp"]).iloc[0]),
                    float(pick(df70w,["null_med","w_null_med"]).iloc[0]),
                    float(pick(df70w,["null_lo","w_null_lo"]).iloc[0]),
                    float(pick(df70w,["null_hi","w_null_hi"]).iloc[0]))
        df70a = try_read_csv(args.fig70_align)
        if df70a is not None and len(df70a):
            add_row(rows, "local_align","Local align <|cos(θ-φ)|>-0.5",
                    float(pick(df70a,["value","align_mean"]).iloc[0]) - 0.5,
                    0.0,
                    float(pick(df70a,["null_lo","align_null_lo"]).iloc[0]) - 0.5,
                    float(pick(df70a,["null_hi","align_null_hi"]).iloc[0]) - 0.5)

    # ---- Fig. 71: prova a leggere metrics, altrimenti ricalcolo light ----
    df71 = try_read_csv(args.fig71_metrics)
    if df71 is not None and len(df71):
        Aval = pick(df71, ["A","amp","value"]).iloc[0]
        nmed = pick(df71, ["null_med","A_null_med"]).iloc[0]
        nlo  = pick(df71, ["null_lo","A_null_lo"]).iloc[0]
        nhi  = pick(df71, ["null_hi","A_null_hi"]).iloc[0]
        add_row(rows, "dipole_A","Dipole amplitude A", float(Aval), float(nmed), float(nlo), float(nhi))
    else:
        # quick recompute da centroidi (B=200)
        if Path(args.centroids).exists():
            try:
                A, med, lo, hi = quick_dipole_A(args.centroids, sel_csv=args.selection, grid=1.0, B=200)
                add_row(rows, "dipole_A","Dipole amplitude A", A, med, lo, hi)
            except Exception:
                pass

    # ---- scrivi CSV ----
    out = pd.DataFrame(rows, columns=["metric","label","value","null_med","null_lo","null_hi","p_raw","p_fdr"])
    out.to_csv(args.out_csv, index=False)
    print(f"[WRITE] {args.out_csv} ({len(out)} rows)")

    if args.also_tab12:
        # Tabella LaTeX di riepilogo (puoi \input{})
        def ci_row(r):
            try:
                lo = float(r["null_lo"]); hi = float(r["null_hi"])
                return f"[{lo:.3g},{hi:.3g}]"
            except Exception:
                return "--"
        lines = []
        lines.append("\\begin{table}[t]")
        lines.append("\\centering")
        lines.append("\\caption{Summary of effect sizes and significance across cross-correlation tests (Section~2.3). Units, $N$, method, and BH--FDR are reported per metric.}")
        lines.append("\\label{tab:quant_summary}")
        lines.append("\\small")
        lines.append("\\begin{tabular}{lcccccl}")
        lines.append("\\toprule")
        lines.append("\\textbf{Metric} & \\textbf{Effect size} & \\textbf{95\\% CI} & \\textbf{$p$ (raw)} & \\textbf{$p$ (FDR)} & \\textbf{$z$} & \\textbf{Notes} \\\\")
        lines.append("\\midrule")
        # z-proxy
        def zproxy(r):
            try:
                med = float(r["null_med"]); lo = float(r["null_lo"]); hi = float(r["null_hi"]); val=float(r["value"])
                sigma = (hi-lo)/(2*1.96)
                if sigma<=0 or not np.isfinite(sigma): return "--"
                return f"{(val-med)/sigma:.2f}"
            except Exception:
                return "--"
        for _,r in out.iterrows():
            lines.append(f"{r['label']} & {r['value']} & {ci_row(r)} & {r['p_raw']} & {r['p_fdr']} & {zproxy(r)} & \\\\")
        lines.append("\\bottomrule")
        lines.append("\\end{tabular}")
        lines.append("\\end{table}")
        Path(args.out_tex).write_text("\n".join(lines), encoding="utf-8")
        print(f"[WRITE] {args.out_tex}")

if __name__ == "__main__":
    main()
