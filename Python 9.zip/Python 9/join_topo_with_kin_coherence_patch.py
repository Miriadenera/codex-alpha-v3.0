#!/usr/bin/env python3
# Join topo nodes with kinematic coherence and update the graph.
# Robust ID handling, optional nearest-neighbour fallback, and QC logging.
# ASCII-only and Windows-safe.

import argparse, json, re
import numpy as np
import pandas as pd

METRICS = ["Phi", "C", "Z_Rayleigh", "p_Rayleigh"]

# ---------- CLI ----------
def parse_args():
    p = argparse.ArgumentParser(
        description="Join topo nodes with kinematic coherence (ID first; optional NN fallback) and update graph."
    )
    p.add_argument("--topo", required=True, help="topo_nodes_patch.csv")
    p.add_argument("--kin",  required=True, help="kinematic coherence per-node CSV")
    p.add_argument("--graph", required=True, help="telascura_topo_graph_v1_patch.json")
    p.add_argument("--out-nodes", default="telascura_nodes_v1.csv")
    p.add_argument("--out-graph", default="telascura_topo_graph_v1p1.json")
    p.add_argument("--qc", default="join_qc_report.csv", help="QC table (match source and separations)")
    p.add_argument("--max-sep-deg", type=float, default=0.10, help="Max sep (deg) for NN fallback")
    p.add_argument("--nn", action="store_true", help="Enable nearest-neighbour fallback")
    p.add_argument("--tiebreak", choices=["low_p","high_C"], default="low_p",
                   help="If kinematic file has duplicate IDs, choose row with lowest p or highest C")
    p.add_argument("--p-max", type=float, default=None,
                   help="Optional: only keep matches with p_Rayleigh <= p-max")
    return p.parse_args()

# ---------- helpers ----------
_ID_RX = re.compile(r"(\d+)")

def normalize_id(x: str) -> str:
    """Return canonical 'T-Topo-####' if any digits are present; else stripped original."""
    if x is None:
        return ""
    s = str(x).strip()
    m = _ID_RX.search(s)
    if not m:
        return s
    num = int(m.group(1))
    return f"T-Topo-{num:04d}"

def pick_col(df, candidates):
    for c in candidates:
        if c and c in df.columns:
            return c
    return None

def standardize_kin_columns(kin: pd.DataFrame) -> pd.DataFrame:
    # ID
    kin_id_col = pick_col(kin, ["ID","ID_Node","NodeID","node_id","Node ID"])
    if kin_id_col is None:
        kin["ID"] = ""  # will be empty; we will rely on NN fallback
    elif kin_id_col != "ID":
        kin = kin.rename(columns={kin_id_col: "ID"})
    kin["ID"] = kin["ID"].map(normalize_id)

    # Try to standardize coordinate column names
    lcol = pick_col(kin, ["l_mean","l","l_deg","l_mean_deg"])
    bcol = pick_col(kin, ["b_mean","b","b_deg","b_mean_deg"])
    if lcol and lcol != "l_mean": kin = kin.rename(columns={lcol:"l_mean"})
    if bcol and bcol != "b_mean": kin = kin.rename(columns={bcol:"b_mean"})

    # Metrics (permissive with variants)
    ren = {}
    if "Phi" not in kin.columns:        ren[pick_col(kin, ["Phi_n","phi_n","phi","PHI"])] = "Phi"
    if "C" not in kin.columns:          ren[pick_col(kin, ["C_n","coherence","Coh","c"])] = "C"
    if "Z_Rayleigh" not in kin.columns: ren[pick_col(kin, ["Z","Zrayleigh","Z_rayleigh"])] = "Z_Rayleigh"
    if "p_Rayleigh" not in kin.columns: ren[pick_col(kin, ["p","p_value","pRayleigh"])] = "p_Rayleigh"
    ren = {k:v for k,v in ren.items() if k is not None}
    if ren:
        kin = kin.rename(columns=ren)

    # Cast numerico
    for m in METRICS:
        if m in kin.columns:
            kin[m] = pd.to_numeric(kin[m], errors="coerce")
    for c in ["l_mean","b_mean"]:
        if c in kin.columns:
            kin[c] = pd.to_numeric(kin[c], errors="coerce")

    return kin

def dedup_kin_by_id(kin: pd.DataFrame, tiebreak: str) -> pd.DataFrame:
    """If multiple rows share the same ID, pick the best according to tiebreak."""
    if "ID" not in kin.columns:
        return kin
    if tiebreak == "low_p" and "p_Rayleigh" in kin.columns:
        k = kin.copy()
        k["__ord"] = k["p_Rayleigh"].fillna(np.inf)
        k = k.sort_values(["ID","__ord"], kind="mergesort").drop_duplicates("ID", keep="first").drop(columns="__ord")
        return k
    if tiebreak == "high_C" and "C" in kin.columns:
        k = kin.copy()
        k["__ord"] = -k["C"].fillna(-np.inf)
        k = k.sort_values(["ID","__ord"], kind="mergesort").drop_duplicates("ID", keep="first").drop(columns="__ord")
        return k
    # fallback: first occurrence
    return kin.drop_duplicates("ID", keep="first")

def small_angle_sep_deg(l1, b1, l2, b2):
    """Small-angle distance in degrees with cos(b) correction."""
    bmean = 0.5*(b1 + b2)
    dl = (l1 - l2) * np.cos(np.deg2rad(bmean))
    db = (b1 - b2)
    return float(np.hypot(dl, db))

def nearest_fill(topo_sub: pd.DataFrame, kin_pos: pd.DataFrame, max_sep_deg: float) -> pd.DataFrame:
    """
    Return rows: ID (from topo_sub), match_source, sep_deg, and METRICS from kin_pos via NN in (l,b).
    kin_pos must contain l_mean, b_mean + METRICS.
    """
    if kin_pos is None or not {"l_mean","b_mean"}.issubset(kin_pos.columns):
        return pd.DataFrame(columns=["ID","match_source","sep_deg"] + METRICS)

    tl = topo_sub["l_mean"].to_numpy()
    tb = topo_sub["b_mean"].to_numpy()
    kl = kin_pos["l_mean"].to_numpy()
    kb = kin_pos["b_mean"].to_numpy()

    out = []
    for i in range(len(topo_sub)):
        bl = 0.5*(tb[i] + kb)
        dl = (tl[i] - kl) * np.cos(np.deg2rad(bl))
        db = (tb[i] - kb)
        d  = np.hypot(dl, db)
        j  = int(np.argmin(d))
        if d[j] <= max_sep_deg:
            row = {"ID": topo_sub.iloc[i]["ID"], "match_source":"nn", "sep_deg": float(d[j])}
            for m in METRICS:
                row[m] = kin_pos.iloc[j][m] if m in kin_pos.columns else np.nan
            out.append(row)
    return pd.DataFrame(out)

# ---------- main ----------
def main():
    a = parse_args()

    # Load topo
    topo = pd.read_csv(a.topo)
    if "ID" not in topo.columns:
        raise SystemExit("ERROR: topo CSV must contain 'ID'.")
    for c in ("l_mean","b_mean"):
        if c not in topo.columns:
            raise SystemExit("ERROR: topo CSV must contain l_mean and b_mean.")
    topo["ID"] = topo["ID"].map(normalize_id)

    # Load & standardize kin
    kin = pd.read_csv(a.kin)
    kin = standardize_kin_columns(kin)
    kin = dedup_kin_by_id(kin, a.tiebreak)

    # Prepare kinematic slice
    kin_metrics = kin[["ID"] + [m for m in METRICS if m in kin.columns]].copy()

    # ---- ID join
    merged = topo.merge(kin_metrics, on="ID", how="left", suffixes=("",""))
    id_hits = int(merged[METRICS[0]].notna().sum()) if METRICS[0] in merged.columns else 0
    print(f"ID join matched: {id_hits} rows")

    # QC vector we’ll fill
    qc = merged[["ID","l_mean","b_mean"]].copy()
    qc["match_source"] = np.where(merged[METRICS[0]].notna(), "id", "none")
    qc["sep_deg"] = np.nan

    # ---- Nearest-neighbour fallback (optional)
    if a.nn:
        need_mask = merged[METRICS[0]].isna() if METRICS[0] in merged.columns else pd.Series(False, index=merged.index)
        if need_mask.any():
            kin_pos = kin[["l_mean","b_mean"] + [m for m in METRICS if m in kin.columns]].copy() \
                      if {"l_mean","b_mean"}.issubset(kin.columns) else None
            if kin_pos is None:
                print("Nearest fallback skipped (kin file lacks l_mean/b_mean).")
            else:
                topo_need = merged.loc[need_mask, ["ID","l_mean","b_mean"]].copy()
                nn_df = nearest_fill(topo_need, kin_pos, a.max_sep_deg)
                if not nn_df.empty:
                    merged = merged.merge(nn_df.drop(columns=["match_source","sep_deg"]),
                                          on="ID", how="left", suffixes=("","_nn"))
                    # fill metrics from nn where NaN
                    for m in METRICS:
                        if m in merged.columns and (m + "_nn") in merged.columns:
                            merged[m] = merged[m].fillna(merged[m + "_nn"])
                            merged.drop(columns=[m + "_nn"], inplace=True)
                    # update QC
                    qc = qc.merge(nn_df[["ID","match_source","sep_deg"]], on="ID", how="left", suffixes=("","_new"))
                    take_nn = qc["match_source_new"].eq("nn") & qc["match_source"].eq("none")
                    qc.loc[take_nn, "match_source"] = "nn"
                    qc.loc[take_nn, "sep_deg"] = qc.loc[take_nn, "sep_deg_new"]
                    qc = qc.drop(columns=["match_source_new","sep_deg_new"])
                    nn_hits = int(take_nn.sum())
                    print(f"Nearest-neighbour fallback filled: {nn_hits} rows (<= {a.max_sep_deg:.3f} deg)")
                else:
                    print("Nearest-neighbour fallback: no matches within threshold.")

    # ---- Optional p-value filter
    if a.p_max is not None and "p_Rayleigh" in merged.columns:
        before = int(merged[METRICS[0]].notna().sum())
        # Where p > p_max, blank out the metrics (keeps the node but marks metrics as missing)
        bad = merged["p_Rayleigh"] > a.p_max
        merged.loc[bad, METRICS] = np.nan
        after = int(merged[METRICS[0]].notna().sum())
        print(f"Applied p-threshold (p <= {a.p_max:g}): {before} -> {after} retained")

    # ---- Save QC
    qc.to_csv(a.qc, index=False)
    print("Saved QC:", a.qc)

    # ---- Save nodes
    merged.to_csv(a.out_nodes, index=False)
    print("Saved nodes:", a.out_nodes)

    # ---- Update graph JSON
    with open(a.graph, "r", encoding="utf-8") as f:
        G = json.load(f)

    got_cols = [m for m in METRICS if m in merged.columns]
    kmap = merged.set_index("ID")[got_cols].to_dict(orient="index")

    n_upd = 0
    for n in G.get("nodes", []):
        nid = normalize_id(n.get("id",""))
        if nid in kmap:
            for m in got_cols:
                v = kmap[nid].get(m, np.nan)
                if pd.notna(v):
                    n[m] = float(v)
            n_upd += 1

    with open(a.out_graph, "w", encoding="utf-8") as f:
        json.dump(G, f, indent=2)
    print("Graph nodes updated with kinematics:", n_upd)
    print("Saved graph:", a.out_graph)

if __name__ == "__main__":
    main()
