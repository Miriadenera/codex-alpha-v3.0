import pandas as pd

# === STEP 1: Lettura grezza del file ===
raw_path = "output.csv"  # cambia qui se il nome è diverso

with open(raw_path, 'r') as f:
    lines = f.readlines()

# === STEP 2: Pulizia manuale ===
parsed_rows = []
for line in lines:
    # Elimina spazi, newline
    clean_line = line.strip()
    # Ignora righe vuote o righe troppo corte
    if len(clean_line) < 10 or clean_line.startswith('SOURCE_ID'):
        continue
    # Divide con split su virgole
    fields = clean_line.split(',')
    if len(fields) == 7:
        parsed_rows.append(fields)

# === STEP 3: Creazione DataFrame ===
columns = ['SOURCE_ID', 'ra', 'dec', 'parallax', 'pmra', 'pmdec', 'phot_g_mean_mag']
df = pd.DataFrame(parsed_rows, columns=columns)

# === STEP 4: Conversione dei tipi numerici ===
numeric_cols = ['ra', 'dec', 'parallax', 'pmra', 'pmdec', 'phot_g_mean_mag']
for col in numeric_cols:
    df[col] = pd.to_numeric(df[col], errors='coerce')

# === STEP 5: Calcolo informazionale ===
df['K'] = (df['pmra']**2 + df['pmdec']**2)**0.5

# === STEP 6: Salvataggio file pulito ===
df.to_csv("output_cleaned.csv", index=False)
print("✅ File pulito salvato come 'output_cleaned.csv'")
