#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make_fig66_inputs.py
Crea:
  - basins_min_centroids.csv  (l_deg,b_deg) dai tuoi file (nodes/basins)
  - selection_map.csv         (l_deg,b_deg,S) da gaia_codex_filter_density.csv (S normalizzata a <S>=1)
Opzionale:
  - fig66_metrics.csv + fig66.tex  (ECDF sin|b| con null che preserva S + inset dip/quadr)
"""

import argparse, os, sys, json, math, pathlib
from pathlib import Path
import numpy as np
import pandas as pd

# ------------------------ utils ------------------------

def ang_norm_lon_deg(l):
    return float(l) % 360.0

def to_float(x):
    return float(str(x).strip())

def sinabsb_deg(b_deg):
    return np.sin(np.deg2rad(np.abs(b_deg)))

def spherical_centroid_deg(l_list_deg, b_list_deg):
    """centroide robusto su sfera da punti (l,b) in gradi"""
    x=y=z=0.0
    n=0
    for l_deg, b_deg in zip(l_list_deg, b_list_deg):
        l = np.deg2rad(l_deg); b = np.deg2rad(b_deg)
        x += np.cos(b)*np.cos(l)
        y += np.cos(b)*np.sin(l)
        z += np.sin(b); n += 1
    if n==0: return None, None
    x/=n; y/=n; z/=n
    r = np.sqrt(x*x+y*y+z*z)
    if r==0: return np.nan, np.nan
    x/=r; y/=r; z/=r
    b = np.rad2deg(np.arcsin(z))
    l = np.rad2deg(np.arctan2(y,x)) % 360.0
    return l, b

# ------------------------ detection of input files ------------------------

CAND_NODES_CSV = [
    "topo_nodes_patch.csv", "topo_nodes.csv",
    "telascura_nodes_clean_min10_k6.csv",
    "telascura_nodes_refined_min10_k6.csv",
    "telascura_nodes_fast_min10.csv",
    "telascura_nodes_v1.csv",
]

CAND_BASINS_GEOJSON = [
    "topo_basins_patch.geojson", "topo_basins.geojson",
]

DENSITY_SOURCES = [
    "gaia_codex_filter_density.csv",   # visto nello screenshot
    "gaia_high_grad_zones.csv",
]

def load_min_centroids_from_nodes_csv(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    cols = {c.lower(): c for c in df.columns}

    # trova colonne lon/lat
    lcol = cols.get("l_mean") or cols.get("l_deg") or cols.get("l") or cols.get("lon") or cols.get("longitude")
    bcol = cols.get("b_mean") or cols.get("b_deg") or cols.get("b") or cols.get("lat") or cols.get("latitude")
    if not lcol or not bcol:
        raise ValueError(f"{path.name}: colonne per lon/lat non trovate (es. l_mean/l_deg e b_mean/b_deg)")

    # filtra "min" se presente un tipo
    typecol = None
    for key in ["node_type","type","class","kind"]:
        if key in cols:
            typecol = cols[key]; break
    if typecol:
        mask_min = df[typecol].astype(str).str.lower().str.contains("min")
        if mask_min.any():
            df = df[mask_min]
        else:
            print(f"[ATTENZIONE] {path.name}: nessuna riga con node_type~'min'; uso tutte le righe (fallback).")

    out = pd.DataFrame({
        "l_deg": np.mod(df[lcol].astype(float), 360.0),
        "b_deg": df[bcol].astype(float)
    })
    if out.empty:
        raise ValueError(f"{path.name}: nessuna riga utile per i centroidi.")
    return out

def load_min_centroids_from_geojson(path: Path) -> pd.DataFrame:
    gj = json.loads(Path(path).read_text(encoding="utf-8"))
    feats = gj.get("features", [])
    rows = []
    for f in feats:
        props = f.get("properties", {})
        # preferisci centroidi già pronti
        if "l_mean" in props and "b_mean" in props:
            rows.append((ang_norm_lon_deg(props["l_mean"]), float(props["b_mean"])))
            continue
        if "l_deg" in props and "b_deg" in props:
            rows.append((ang_norm_lon_deg(props["l_deg"]), float(props["b_deg"])))
            continue
        # altrimenti centroidi geometrici del poligono principale
        geom = f.get("geometry", {})
        gtype = geom.get("type","")
        coords = geom.get("coordinates",[])
        l_list=[]; b_list=[]
        if gtype=="Polygon" and coords:
            ring = coords[0]
            for lon,lat in ring:
                l_list.append(ang_norm_lon_deg(lon)); b_list.append(float(lat))
        elif gtype=="MultiPolygon" and coords:
            # prendi il poligono più ricco di punti
            ring = max((poly[0] for poly in coords if poly and poly[0]), key=lambda r: len(r), default=[])
            for lon,lat in ring:
                l_list.append(ang_norm_lon_deg(lon)); b_list.append(float(lat))
        elif gtype=="Point" and coords:
            lon,lat = coords
            l_list.append(ang_norm_lon_deg(lon)); b_list.append(float(lat))
        if l_list:
            l,b = spherical_centroid_deg(l_list,b_list)
            rows.append((l,b))
    if not rows:
        raise ValueError(f"{path.name}: non trovo centroidi.")
    return pd.DataFrame(rows, columns=["l_deg","b_deg"])

def build_selection_from_density(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    cols = {c.lower(): c for c in df.columns}
    lcol = cols.get("l_deg") or cols.get("l") or cols.get("lon") or cols.get("longitude")
    bcol = cols.get("b_deg") or cols.get("b") or cols.get("lat") or cols.get("latitude")
    # per la "densità": prova colonne comuni
    scol = cols.get("s") or cols.get("weight") or cols.get("sel") or cols.get("selection") \
        or cols.get("density") or cols.get("n") or cols.get("n_stars") or cols.get("count")
    if not (lcol and bcol and scol):
        raise ValueError(f"{path.name}: attese colonne l_deg,b_deg e una tra (S/weight/sel/selection/density/n/n_stars/count).")
    out = pd.DataFrame({
        "l_deg": np.mod(df[lcol].astype(float), 360.0),
        "b_deg": df[bcol].astype(float),
        "S": df[scol].astype(float)
    })
    # normalizza S a <S>=1
    m = out["S"].mean()
    if m>0: out["S"] /= m
    return out

# ------------------------ ECDF + null (opzionale) ------------------------

def ecdf(x):
    xs = np.sort(np.asarray(x))
    n = len(xs)
    y = np.arange(1, n+1)/n
    return xs, y

def make_null_band_from_S(basins_df, Smap_df, nb=20000, nboots=999):
    """costruisce banda null 95% per ECDF di sin|b| preservando S(l,b).
       Campiona posizioni da Smap (importance sampling) con N=numero di centroidi reali."""
    rng = np.random.default_rng(42)
    N = len(basins_df)
    # prob proporzionale a S
    w = np.clip(Smap_df["S"].values, 0, None)
    if not np.any(w>0):
        raise ValueError("Tutte le S<=0 nella selection_map.")
    p = w / w.sum()
    sinb_null = []
    for _ in range(nboots):
        idx = rng.choice(len(Smap_df), size=N, replace=True, p=p)
        b = Smap_df.iloc[idx]["b_deg"].values
        sinb_null.append(sinabsb_deg(b))
    sinb_null = np.stack(sinb_null, axis=0)  # (nboots, N)
    # costruiamo griglia x e banda 2.5-97.5 percentile
    x_grid = np.linspace(0,1,61)
    ecdfs = []
    for i in range(nboots):
        xs, ys = ecdf(sinb_null[i])
        # interpola su x_grid
        ecdfs.append(np.interp(x_grid, xs, ys, left=0.0, right=1.0))
    ecdfs = np.stack(ecdfs, axis=0)
    lower = np.percentile(ecdfs, 2.5, axis=0)
    upper = np.percentile(ecdfs, 97.5, axis=0)
    median = np.percentile(ecdfs, 50.0, axis=0)
    return x_grid, median, lower, upper

def flat_sky_moments(l_deg, b_deg):
    """stima ampiezze dipolo/quadrupolo su flat-sky (approssimazione locale)"""
    # coord piane: x ~ l*cos(b0), y ~ b (in gradi) rispetto al baricentro
    l0, b0 = np.mean(l_deg), np.mean(b_deg)
    x = (l_deg - l0) * np.cos(np.deg2rad(b0))
    y = (b_deg - b0)
    # normalizza a unit variance per stabilità
    x = (x - np.mean(x)) / (np.std(x)+1e-9)
    y = (y - np.mean(y)) / (np.std(y)+1e-9)
    # dipolo: regressione lineare su [x,y]
    A = np.vstack([x, y]).T
    w = np.ones_like(x)
    coeff, _, _, _ = np.linalg.lstsq(A, np.ones_like(x), rcond=None)  # fit 1 ~ a x + b y
    ax, ay = coeff
    Adip = float(np.sqrt(ax*ax + ay*ay))
    # quadrupolo semplice: momenti di secondo ordine
    Qxx = float(np.mean(x*x)); Qyy = float(np.mean(y*y)); Qxy = float(np.mean(x*y))
    Aquad = float(np.sqrt((Qxx-Qyy)**2 + 4*Qxy*Qxy))
    return Adip, Aquad

def write_fig66_tex(outdir: Path, xs, data_ecdf, null_med, null_lo, null_hi, Adip, Aquad):
    """scrive un TikZ pronto alla compilazione (Fig. 66)"""
    tex = f"""
% --- Fig.66: ECDF sin|b| + inset dipole/quadrupole ---
\\begin{figure}[t]
\\centering
\\begin{{minipage}}{{0.68\\linewidth}}
\\begin{{tikzpicture}}
\\begin{{axis}}[
  width=\\linewidth, height=5cm,
  xlabel={{$\\sin|b|$}}, ylabel={{ECDF}},
  xmin=0, xmax=1, ymin=0, ymax=1,
  ticklabel style={{font=\\footnotesize}},
  label style={{font=\\footnotesize}},
  legend style={{draw=none, fill=none, font=\\footnotesize, at={{(0.02,0.98)}}, anchor=north west}},
  clip=false,
]
% null band (95%) from selection-preserving null
\\addplot [name path=upper, draw=none] coordinates {list(zip(xs, null_hi))};
\\addplot [name path=lower, draw=none] coordinates {list(zip(xs, null_lo))};
\\addplot [fill=black!12, draw=none] fill between[of=upper and lower];
% median null
\\addplot [densely dashed] coordinates {list(zip(xs, null_med))};
% data ECDF
\\addplot [very thick] coordinates {list(zip(xs, data_ecdf))};
\\addlegendentry{{Data}}
\\addlegendentry{{Null band (95\\%)}}
\\end{{axis}}
\\end{{tikzpicture}}
\\end{{minipage}}\\hfill
\\begin{{minipage}}{{0.28\\linewidth}}
\\begin{{tikzpicture}}
\\begin{{axis}}[
  width=\\linewidth, height=5cm,
  ybar, bar width=7pt,
  xmin=0.5, xmax=2.5, ymin=0, ymax={{max(0.08, {max(Adip,Aquad):.3f}*1.6):.2f}},
  xtick={{1,2}}, xticklabels={{Dipole,Quadrupole}},
  ylabel={{Amplitude}}, ticklabel style={{font=\\footnotesize}},
  label style={{font=\\footnotesize}}
]
\\addplot[fill=black!40] coordinates {{(1,{Adip:.3f}) (2,{Aquad:.3f})}};
\\end{{axis}}
\\end{{tikzpicture}}
\\end{{minipage}}
\\caption{{ECDF of $\\sin|b|$ for min-basin centroids (data) versus the selection-preserving null (median and 95\\% envelope). Inset: flat-sky moment amplitudes (dipole, quadrupole).}}
\\label{{fig:gp_ecdf_dipquad}}
\\end{figure}
"""
    (outdir / "fig66.tex").write_text(tex, encoding="utf-8")

# ------------------------ main ------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=str, default=".", help="cartella con i file")
    ap.add_argument("--make-fig66", action="store_true", help="calcola anche ECDF+null e genera fig66.tex")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    os.chdir(root)

    # 1) basins_min_centroids.csv
    basins_df = None
    for fname in CAND_NODES_CSV:
        p = root / fname
        if p.exists():
            try:
                basins_df = load_min_centroids_from_nodes_csv(p)
                print(f"[OK] Centroidi da {p.name} -> {len(basins_df)} righe")
                break
            except Exception as e:
                print(f"[WARN] {p.name}: {e}")
    if basins_df is None:
        for fname in CAND_BASINS_GEOJSON:
            p = root / fname
            if p.exists():
                try:
                    basins_df = load_min_centroids_from_geojson(p)
                    print(f"[OK] Centroidi da {p.name} (GeoJSON) -> {len(basins_df)} righe")
                    break
                except Exception as e:
                    print(f"[WARN] {p.name}: {e}")
    if basins_df is None:
        print("[FATAL] Non trovo centroidi min-basin nei file attesi.")
        print("        Cerca uno dei seguenti: ", CAND_NODES_CSV + CAND_BASINS_GEOJSON)
        sys.exit(2)

    basins_out = root / "basins_min_centroids.csv"
    basins_df[["l_deg","b_deg"]].to_csv(basins_out, index=False)
    print(f"[WRITE] {basins_out.name} ({len(basins_df)} righe)")

    # 2) selection_map.csv da gaia_codex_filter_density.csv
    sel_df = None
    for fname in DENSITY_SOURCES:
        p = root / fname
        if p.exists():
            try:
                sel_df = build_selection_from_density(p)
                print(f"[OK] Selezione da {p.name} -> {len(sel_df)} righe (normalizzata a <S>=1)")
                break
            except Exception as e:
                print(f"[WARN] {p.name}: {e}")
    if sel_df is None:
        print("[FATAL] Non trovo una mappa di selezione/densità (es. gaia_codex_filter_density.csv).")
        print("        Carica/fornisci un CSV con (l_deg,b_deg,S) o densità da usare come S.")
        sys.exit(3)

    sel_out = root / "selection_map.csv"
    sel_df.to_csv(sel_out, index=False)
    print(f"[WRITE] {sel_out.name} ({len(sel_df)} righe, <S>=1)")

    if not args.make_fig66:
        return

    # 3) Fig.66 (opzionale): ECDF sin|b| + null che preserva S
    #    - ECDF dati
    x_data, y_data = ecdf(sinabsb_deg(basins_df["b_deg"].values))
    #    - null (percentili su griglia)
    xs, med, lo, hi = make_null_band_from_S(basins_df, sel_df, nboots=999)
    #    - mappa ECDF dati su xs per confronto pulito
    y_data_interp = np.interp(xs, x_data, y_data, left=0.0, right=1.0)
    #    - momenti flat-sky (dip/quadr)
    Adip, Aquad = flat_sky_moments(basins_df["l_deg"].values, basins_df["b_deg"].values)

    # 4) salvataggi
    metrics = pd.DataFrame({
        "xs": xs, "ecdf_data": y_data_interp, "null_median": med, "null_lo": lo, "null_hi": hi
    })
    metrics.to_csv(root/"fig66_metrics.csv", index=False)
    print("[WRITE] fig66_metrics.csv")
    write_fig66_tex(root, xs, y_data_interp, med, lo, hi, Adip, Aquad)
    print("[WRITE] fig66.tex (TikZ pronto)")

if __name__ == "__main__":
    main()
