#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Make Fig. 69 (Nearby galaxies: axial alignment)
# Opzioni:
#  A) --edges + --gals  (preferita, galaxies reali)
#  B) --edges + --use-arms (proxy per test veloce)
#  C) --angles (se hai già Δθ) -> plot e statistiche
#
# Output:
#   fig69_angles.csv, fig69_stats.csv,
#   fig69_left_rose.pdf, fig69_right_cos.pdf, fig69_combined.pdf,
#   fig69_latex.txt
import argparse, json, sys
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from pathlib import Path
try:
    from shapely.geometry import shape, LineString
except Exception:
    print("[FATAL] Shapely è richiesto. Installa con:  pip install shapely", file=sys.stderr)
    raise

def wrap_axial(theta):  # rad -> [0,pi)
    return np.mod(theta, np.pi)

def lb_to_xy_tangent(l_deg, b_deg, l0_deg, b0_deg):
    l, b = np.deg2rad(l_deg), np.deg2rad(b_deg)
    l0, b0 = np.deg2rad(l0_deg), np.deg2rad(b0_deg)
    dl = (l - l0)
    x = dl * np.cos(b0)
    y = (b - b0)
    return x, y

def xy_angle(dx, dy):  # [0,2pi)
    return np.mod(np.arctan2(dy, dx), 2*np.pi)

def read_edges_geojson(path):
    gj = json.loads(Path(path).read_text(encoding="utf-8"))
    feats = gj["features"] if "features" in gj else [gj]
    Lm, Bm, Phi = [], [], []
    for ft in feats:
        geom = ft.get("geometry", None)
        if geom is None: 
            continue
        try:
            g = shape(geom)
        except Exception:
            continue
        line = None
        if isinstance(g, LineString):
            line = g
        elif g.geom_type == "MultiLineString" and len(g.geoms)>0:
            line = max(g.geoms, key=lambda s: s.length)
        else:
            continue
        coords = np.array(line.coords, float)
        if coords.shape[0] < 2:
            continue
        mid = coords[coords.shape[0]//2]
        lm, bm = float(mid[0]), float(mid[1])
        x, y = lb_to_xy_tangent(coords[:,0], coords[:,1], lm, bm)
        dx, dy = x[-1]-x[0], y[-1]-y[0]
        phi = wrap_axial(xy_angle(dx, dy))
        # override da proprietà 'phi_deg' se presente
        try:
            phip = ft.get("properties", {}).get("phi_deg", None)
            if phip is not None:
                phi = wrap_axial(np.deg2rad(float(phip)))
        except Exception:
            pass
        Lm.append(lm); Bm.append(bm); Phi.append(phi)
    if not Lm:
        raise RuntimeError("Nessun edge valido nel geojson.")
    return np.array(Lm), np.array(Bm), np.array(Phi)

def read_points_csv_or_geo(path):
    p = Path(path)
    if p.suffix.lower() in (".geojson",".json"):
        gj = json.loads(p.read_text(encoding="utf-8"))
        feats = gj["features"] if "features" in gj else [gj]
        L,B = [],[]
        for ft in feats:
            try:
                g = shape(ft["geometry"])
                if g.geom_type=="Point":
                    L.append(g.x); B.append(g.y)
            except Exception:
                continue
        return np.array(L), np.array(B)
    else:
        df = pd.read_csv(p, low_memory=False)
        candL = [c for c in df.columns if c.lower() in ("l_deg_aligned","l_deg","l","lon","longitude")]
        candB = [c for c in df.columns if c.lower() in ("b_deg","b","lat","latitude")]
        if not candL or not candB:
            raise RuntimeError(f"{path}: non trovo colonne l/b.")
        L = pd.to_numeric(df[candL[0]], errors="coerce").values
        B = pd.to_numeric(df[candB[0]], errors="coerce").values
        return L, B

def sample_points_along_curves_csv(path, step=0.5):
    # arms_ridge CSV con colonne l_deg,b_deg
    df = pd.read_csv(path, low_memory=False)
    for c in ("l_deg","b_deg"):
        if c not in df.columns:
            raise RuntimeError(f"{path}: mancano colonne l_deg/b_deg.")
    ll = df["l_deg"].values; bb = df["b_deg"].values
    if len(ll)<2:
        return ll, bb
    dls = np.abs(np.diff(ll)); dbs = np.abs(np.diff(bb))
    med = np.median(np.hypot(dls, dbs))
    k = max(1, int(round(step/med))) if med>0 else 10
    idx = np.arange(len(ll))[::k]
    return ll[idx], bb[idx]

def compute_angles(edges_geo, gals_csv=None, arms_csv=None, block_deg=2.0, Bnull=600):
    Lm, Bm, Phi = read_edges_geojson(edges_geo)
    l0, b0 = float(np.median(Lm)), float(np.median(Bm))
    Ex, Ey = lb_to_xy_tangent(Lm, Bm, l0, b0)

    if gals_csv:
        Gl, Gb = read_points_csv_or_geo(gals_csv)
    elif arms_csv:
        Gl, Gb = sample_points_along_curves_csv(arms_csv, step=0.5)
    else:
        raise RuntimeError("Passa --gals (preferito) oppure --use-arms (solo test).")

    Gx, Gy = lb_to_xy_tangent(Gl, Gb, l0, b0)
    d2 = (Ex[:,None]-Gx[None,:])**2 + (Ey[:,None]-Gy[None,:])**2
    nn = np.argmin(d2, axis=1)
    dx, dy = Gx[nn]-Ex, Gy[nn]-Ey
    Phi_g = xy_angle(dx, dy)
    dphi = np.abs(Phi - Phi_g)
    dphi = np.mod(dphi, np.pi)
    dphi = np.minimum(dphi, np.pi - dphi)  # [0,pi/2]

    # block bootstrap IDs (griglia l,b)
    bid_l = np.floor((Lm - l0)/block_deg).astype(int)
    bid_b = np.floor((Bm - b0)/block_deg).astype(int)
    block_ids = bid_l*10000 + bid_b

    # Rayleigh (assiale): Z = N*R^2, R = |mean e^{i2θ}|
    R = np.abs(np.mean(np.exp(1j*2.0*dphi)))
    Z = len(dphi) * (R**2)

    # CI(Z) via block bootstrap
    rng = np.random.default_rng(123)
    uniq = np.unique(block_ids)
    B = min(800, max(300, 50*len(uniq)))
    Zs = np.zeros(B)
    for b in range(B):
        sel_blocks = rng.choice(uniq, size=len(uniq), replace=True)
        m = np.isin(block_ids, sel_blocks)
        if m.sum()<5:
            Zs[b] = np.nan; continue
        Rb = np.abs(np.mean(np.exp(1j*2.0*dphi[m])))
        Zs[b] = m.sum() * (Rb**2)
    Z_lo, Z_hi = np.nanpercentile(Zs, [2.5,97.5])

    cosabs = np.abs(np.cos(dphi))
    m_cos = float(np.mean(cosabs))

    # null band per <|cos|>: shuffle assegnazione galaxies
    Bn = Bnull
    mnull = np.zeros(Bn)
    for b in range(Bn):
        nn_sh = rng.permutation(nn)
        dx, dy = Gx[nn_sh]-Ex, Gy[nn_sh]-Ey
        Phi_g_sh = xy_angle(dx, dy)
        dph = np.abs(Phi - Phi_g_sh)
        dph = np.mod(dph, np.pi)
        dph = np.minimum(dph, np.pi - dph)
        mnull[b] = float(np.mean(np.abs(np.cos(dph))))
    m_lo, m_hi = np.percentile(mnull, [2.5,97.5])

    out_angles = pd.DataFrame({
        "l_deg": Lm, "b_deg": Bm,
        "delta_deg": np.rad2deg(dphi),
        "cosabs": cosabs
    })
    return out_angles, (Z, Z_lo, Z_hi), (m_cos, m_lo, m_hi)

def rose_hist(ax, angles_deg, nbins=18):
    th = np.deg2rad(angles_deg)
    bins = np.linspace(0, np.pi/2, nbins+1)
    counts, edges = np.histogram(th, bins=bins)
    widths = np.diff(edges)
    centers = edges[:-1] + widths/2.0
    r = counts.astype(float)
    r = r/r.max() if r.max()>0 else r
    ax.bar(centers, r, width=widths, align="center", edgecolor="none", alpha=0.85)
    ax.set_theta_zero_location("E"); ax.set_theta_direction(-1)
    ax.set_thetamin(0); ax.set_thetamax(90)
    ax.set_yticklabels([])
    ax.set_xticks(np.deg2rad([0,30,60,90])); ax.set_xticklabels(["0°","30°","60°","90°"])

def plot_fig(angle_df, Z_tuple, m_tuple, out_left, out_right, out_both):
    Z, Z_lo, Z_hi = Z_tuple
    m, m_lo, m_hi = m_tuple

    fig1 = plt.figure(figsize=(3.8,3.4))
    ax = fig1.add_subplot(111, projection="polar")
    rose_hist(ax, angle_df["delta_deg"].values, nbins=18)
    ax.set_title("Rose of Δθ (axial)", fontsize=10)
    ax.text(0.02, 0.98, f"Rayleigh Z = {Z:.2f}\n95% CI [{Z_lo:.2f}, {Z_hi:.2f}]",
            transform=ax.transAxes, ha="left", va="top", fontsize=8)
    fig1.savefig(out_left, bbox_inches="tight")

    fig2, ax2 = plt.subplots(figsize=(2.4,3.4))
    ax2.bar([0],[m], width=0.5)
    ax2.vlines([0], [m_lo], [m_hi], lw=3, alpha=0.6, color="tab:orange")
    ax2.set_xticks([0]); ax2.set_xticklabels([r"$\langle|\cos\Delta\theta|\rangle$"])
    ax2.set_ylim(0.0, 1.0); ax2.set_ylabel(r"$\langle|\cos\Delta\theta|\rangle$")
    fig2.savefig(out_right, bbox_inches="tight")

    fig = plt.figure(figsize=(6.3,3.4))
    axL = fig.add_axes([0.06,0.18,0.48,0.74], projection="polar")
    rose_hist(axL, angle_df["delta_deg"].values, nbins=18)
    axL.set_title("Rose of Δθ (axial)", fontsize=10)
    axL.text(0.02, 0.98, f"Rayleigh Z = {Z:.2f}\n95% CI [{Z_lo:.2f}, {Z_hi:.2f}]",
             transform=axL.transAxes, ha="left", va="top", fontsize=8)
    axR = fig.add_axes([0.66,0.18,0.30,0.74])
    axR.bar([0],[m], width=0.5)
    axR.vlines([0], [m_lo], [m_hi], lw=3, alpha=0.6, color="tab:orange")
    axR.set_xticks([0]); axR.set_xticklabels([r"$\langle|\cos\Delta\theta|\rangle$"])
    axR.set_ylim(0.0, 1.0); axR.set_ylabel(r"$\langle|\cos\Delta\theta|\rangle$")
    fig.savefig(out_both, bbox_inches="tight")

def main():
    ap = argparse.ArgumentParser(description="Fig. 69: axial alignment with nearby galaxies")
    ap.add_argument("--edges", help="edges geojson (LineString/MultiLineString)")
    ap.add_argument("--gals", default=None, help="nearby galaxies (csv l_deg,b_deg o geojson di Point)")
    ap.add_argument("--use-arms", default=None, help="usa arms_ridge CSV come proxy (solo test)")
    ap.add_argument("--angles", default=None, help="se fornito, CSV con colonna delta_deg (deg): salta la geometria")
    ap.add_argument("--block-deg", type=float, default=2.0, help="ampiezza blocchi [deg] per block-bootstrap di Z")
    ap.add_argument("--Bnull", type=int, default=600, help="shuffle per banda null di <|cosΔθ|>")
    ap.add_argument("--out-prefix", default="fig69_", help="prefisso output")
    args = ap.parse_args()

    out_angles_csv = f"{args.out_prefix}angles.csv"
    out_stats_csv  = f"{args.out_prefix}stats.csv"
    out_left  = f"{args.out_prefix}left_rose.pdf"
    out_right = f"{args.out_prefix}right_cos.pdf"
    out_both  = f"{args.out_prefix}combined.pdf"

    if args.angles is not None:
        df = pd.read_csv(args.angles)
        if "delta_deg" not in df.columns:
            raise RuntimeError(f"{args.angles}: serve colonna 'delta_deg'.")
        th = np.deg2rad(df["delta_deg"].values)
        R = np.abs(np.mean(np.exp(1j*2.0*th)))
        Z = len(th) * (R**2)
        rng = np.random.default_rng(123)
        B = 600
        Zs = np.zeros(B)
        for b in range(B):
            idx = rng.integers(0, len(th), size=len(th))
            Rb = np.abs(np.mean(np.exp(1j*2.0*th[idx])))
            Zs[b] = len(idx)*(Rb**2)
        Z_lo, Z_hi = np.percentile(Zs, [2.5,97.5])
        m = float(np.mean(np.abs(np.cos(th))))
        mnull = [float(np.mean(np.abs(np.cos(th[np.random.permutation(len(th))])))) for _ in range(B)]
        m_lo, m_hi = np.percentile(mnull, [2.5,97.5])
        angle_df = pd.DataFrame({"delta_deg": df["delta_deg"].values, "cosabs": np.abs(np.cos(th))})
    else:
        angle_df, (Z, Z_lo, Z_hi), (m, m_lo, m_hi) = compute_angles(
            args.edges, gals_csv=args.gals, arms_csv=args.use_arms,
            block_deg=args.block_deg, Bnull=args.Bnull
        )
        angle_df.to_csv(out_angles_csv, index=False)
        print(f"[WRITE] {out_angles_csv} (n={len(angle_df)})")

    # se siamo nel ramo --angles, definisci Z/m (già calcolati più sopra)
    if args.angles is not None:
        pass
    else:
        pass

    pd.DataFrame([{"Z": Z, "Z_lo": Z_lo, "Z_hi": Z_hi,
                   "mean_cosabs": m, "null_lo": m_lo, "null_hi": m_hi}]).to_csv(out_stats_csv, index=False)
    print(f"[WRITE] {out_stats_csv}")

    plot_fig(angle_df, (Z, Z_lo, Z_hi), (m, m_lo, m_hi), out_left, out_right, out_both)
    print(f"[WRITE] {out_left}\n[WRITE] {out_right}\n[WRITE] {out_both}")

    tex = (
    "%% Fig. 69 auto-generata\n"
    "\\begin{figure}[t]\n"
    "  \\centering\n"
    "  \\begin{minipage}[t]{0.60\\textwidth}\n"
    "    \\centering\n"
    f"    \\includegraphics[width=\\linewidth]{{{out_left}}}\n"
    "  \\end{minipage}\\hfill\n"
    "  \\begin{minipage}[t]{0.36\\textwidth}\n"
    "    \\centering\n"
    f"    \\includegraphics[width=\\linewidth]{{{out_right}}}\n"
    "  \\end{minipage}\n"
    f"  \\caption{{Rose plot di $\\Delta\\theta$ con Rayleigh $Z={Z:.2f}$ (95\\% CI [{Z_lo:.2f},{Z_hi:.2f}]); a destra: $\\langle|\\cos\\Delta\\theta|\\rangle={m:.3f}$ con banda null (95\\%).}}\n"
    "  \\label{fig:fig69}\n"
    "\\end{figure}\n"
)
with open(f"{args.out_prefix}latex.txt","w",encoding="utf-8") as f:
    f.write(tex)
print(f"[WRITE] {args.out_prefix}latex.txt")

    with open(f"{args.out_prefix}latex.txt","w",encoding="utf-8") as f:
        f.write(tex)
    print(f"[WRITE] {args.out_prefix}latex.txt")

if __name__ == "__main__":
    main()
