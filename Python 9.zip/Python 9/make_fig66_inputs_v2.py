#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make_fig66_inputs_v2.py
--------------------------------
Creates inputs for Fig.66 and (optionally) Fig.66 itself:
  - basins_min_centroids.csv  (l_deg,b_deg) extracted from your nodes/basins files
  - selection_map.csv         (l_deg,b_deg,S) from a selection/density catalog or by gridding a star catalog
  - (optional) fig66_metrics.csv + fig66.tex (TikZ) with *real coordinates*

Key improvements:
  * Accepts explicit selection file via --sel-file (e.g., gaia_codex_filtered_density.csv)
  * Detects RA/Dec and converts to Galactic (l,b) using IAU 2000 constants
  * Builds a gridded selection map from star-level data (ra/dec or l/b) with --grid-deg (default 0.25)
  * More flexible detection of node files (telascura_nodes_*.csv, topo_nodes_*.csv, GeoJSON basins)
  * No "fabrication": if selection file is given, values come from your data only; otherwise uniform-in-mask (not recommended)

Usage examples:
  python make_fig66_inputs_v2.py --root . --sel-file gaia_codex_filtered_density.csv --sel-col local_density --make-fig66
  python make_fig66_inputs_v2.py --root . --sel-file gaia_codex_filtered_density.csv --grid-deg 0.25 --make-fig66
"""

import argparse, os, sys, json, math, pathlib
from pathlib import Path
import numpy as np
import pandas as pd

# ------------------------ astro transforms ------------------------

def radec_to_gal(ra_deg, dec_deg):
    """
    Convert Equatorial (RA,Dec) J2000 to Galactic (l,b) in degrees.
    IAU 2000 constants:
      alpha_gp = 192.85948 deg
      delta_gp = 27.12825 deg
      l_omega  = 32.93191857 deg
    """
    alpha_gp = math.radians(192.85948)
    delta_gp = math.radians(27.12825)
    l_omega  = math.radians(32.93191857)

    ra = np.radians(ra_deg)
    dec = np.radians(dec_deg)

    sinb = np.sin(dec)*np.sin(delta_gp) + np.cos(dec)*np.cos(delta_gp)*np.cos(ra - alpha_gp)
    b = np.degrees(np.arcsin(np.clip(sinb, -1.0, 1.0)))

    y = np.cos(dec) * np.sin(ra - alpha_gp)
    x = np.sin(dec)*np.cos(delta_gp) - np.cos(dec)*np.sin(delta_gp)*np.cos(ra - alpha_gp)
    l = np.degrees(np.arctan2(y, x)) + np.degrees(l_omega)
    l = np.mod(l, 360.0)
    return l, b

def sinabsb_deg(b_deg):
    return np.sin(np.deg2rad(np.abs(b_deg)))

# ------------------------ centroid helpers ------------------------

def spherical_centroid_deg(l_list_deg, b_list_deg):
    """Robust spherical centroid from (l,b) in degrees."""
    x=y=z=0.0
    n=0
    for l_deg, b_deg in zip(l_list_deg, b_list_deg):
        l = np.deg2rad(l_deg); b = np.deg2rad(b_deg)
        x += np.cos(b)*np.cos(l)
        y += np.cos(b)*np.sin(l)
        z += np.sin(b); n += 1
    if n==0: return None, None
    x/=n; y/=n; z/=n
    r = np.sqrt(x*x+y*y+z*z)
    if r==0: return np.nan, np.nan
    x/=r; y/=r; z/=r
    b = np.rad2deg(np.arcsin(z))
    l = np.rad2deg(np.arctan2(y,x)) % 360.0
    return l, b

# ------------------------ I/O detection ------------------------

CAND_NODES_CSV = [
    "telascura_nodes_clean_min10_k6.csv",
    "telascura_nodes_refined_min10_k6.csv",
    "telascura_nodes_fast_min10.csv",
    "telascura_nodes_v1.csv",
    "topo_nodes_patch.csv",
    "topo_nodes.csv"
]

CAND_BASINS_GEOJSON = [
    "topo_basins_patch.geojson", "topo_basins.geojson",
]

def load_min_centroids_from_nodes_csv(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    cols = {c.lower(): c for c in df.columns}

    # find lon/lat columns
    lcol = cols.get("l_mean") or cols.get("l_deg") or cols.get("l") or cols.get("lon") or cols.get("longitude")
    bcol = cols.get("b_mean") or cols.get("b_deg") or cols.get("b") or cols.get("lat") or cols.get("latitude")
    if not lcol or not bcol:
        raise ValueError(f"{path.name}: columns for lon/lat not found (e.g. l_mean/l_deg and b_mean/b_deg)")

    # filter "min" if a node type exists
    typecol = None
    for key in ["node_type","type","class","kind"]:
        if key in cols:
            typecol = cols[key]; break
    if typecol:
        mask_min = df[typecol].astype(str).str.lower().str.contains("min")
        if mask_min.any():
            df = df[mask_min]
        else:
            print(f"[WARN] {path.name}: no rows with node_type~'min'; using all rows (fallback).")

    out = pd.DataFrame({
        "l_deg": np.mod(df[lcol].astype(float), 360.0),
        "b_deg": df[bcol].astype(float)
    })
    if out.empty:
        raise ValueError(f"{path.name}: empty result for centroids.")
    return out

def load_min_centroids_from_geojson(path: Path) -> pd.DataFrame:
    gj = json.loads(Path(path).read_text(encoding="utf-8"))
    feats = gj.get("features", [])
    rows = []
    for f in feats:
        props = f.get("properties", {})
        if "l_mean" in props and "b_mean" in props:
            rows.append((float(props["l_mean"])%360.0, float(props["b_mean"])))
            continue
        if "l_deg" in props and "b_deg" in props:
            rows.append((float(props["l_deg"])%360.0, float(props["b_deg"])))
            continue
        geom = f.get("geometry", {})
        gtype = geom.get("type","")
        coords = geom.get("coordinates",[])
        l_list=[]; b_list=[]
        if gtype=="Polygon" and coords:
            ring = coords[0]
            for lon,lat in ring:
                l_list.append(float(lon)%360.0); b_list.append(float(lat))
        elif gtype=="MultiPolygon" and coords:
            ring = max((poly[0] for poly in coords if poly and poly[0]), key=lambda r: len(r), default=[])
            for lon,lat in ring:
                l_list.append(float(lon)%360.0); b_list.append(float(lat))
        elif gtype=="Point" and coords:
            lon,lat = coords
            l_list.append(float(lon)%360.0); b_list.append(float(lat))
        if l_list:
            l,b = spherical_centroid_deg(l_list,b_list)
            rows.append((l,b))
    if not rows:
        raise ValueError(f"{path.name}: could not extract min-basin centroids.")
    return pd.DataFrame(rows, columns=["l_deg","b_deg"])

# ------------------------ selection map builders ------------------------

def build_selection_from_catalog(path: Path, sel_col: str=None, grid_deg: float=0.25) -> pd.DataFrame:
    """
    Build a *gridded* selection map from a star-level catalog.
    The file may have (ra,dec) or (l_deg,b_deg). If (ra,dec), they are converted to (l,b).
    If sel_col is provided (e.g., 'local_density'), we aggregate its mean per grid cell;
    otherwise we use counts per cell as S.
    Output: DataFrame(l_deg, b_deg, S) with S normalized to <S>=1.
    """
    df = pd.read_csv(path)
    cols = {c.lower(): c for c in df.columns}

    # detect coord columns
    has_radec = ("ra" in cols) and ("dec" in cols)
    has_lb    = ("l_deg" in cols or "l" in cols or "lon" in cols) and ("b_deg" in cols or "b" in cols or "lat" in cols)

    if has_radec:
        ra = df[cols["ra"]].astype(float).values
        dec = df[cols["dec"]].astype(float).values
        l, b = radec_to_gal(ra, dec)
    elif has_lb:
        lcol = cols.get("l_deg") or cols.get("l") or cols.get("lon")
        bcol = cols.get("b_deg") or cols.get("b") or cols.get("lat")
        l = np.mod(df[lcol].astype(float).values, 360.0)
        b = df[bcol].astype(float).values
    else:
        raise ValueError(f"{path.name}: need either (ra,dec) or (l_deg,b_deg).")

    # define grid
    if grid_deg <= 0:
        raise ValueError("--grid-deg must be > 0")
    lmin, lmax = np.min(l), np.max(l)
    bmin, bmax = np.min(b), np.max(b)
    # expand tiny bit
    lmin -= 1e-6; bmin -= 1e-6; lmax += 1e-6; bmax += 1e-6
    l_edges = np.arange(lmin, lmax + grid_deg, grid_deg)
    b_edges = np.arange(bmin, bmax + grid_deg, grid_deg)

    # binning
    Li = np.clip(np.digitize(l, l_edges) - 1, 0, len(l_edges)-2)
    Bi = np.clip(np.digitize(b, b_edges) - 1, 0, len(b_edges)-2)
    nb_l = len(l_edges)-1; nb_b = len(b_edges)-1

    if sel_col and (sel_col.lower() in cols):
        vals = df[cols[sel_col.lower()]].astype(float).values
        # aggregate mean per cell
        sumv = np.zeros((nb_l, nb_b), dtype=float)
        cnt  = np.zeros((nb_l, nb_b), dtype=int)
        for li,bi,v in zip(Li, Bi, vals):
            sumv[li,bi] += v
            cnt[li,bi]  += 1
        with np.errstate(invalid='ignore', divide='ignore'):
            Sgrid = np.where(cnt>0, sumv/cnt, np.nan)
    else:
        # counts as selection
        Sgrid = np.zeros((nb_l, nb_b), dtype=float)
        for li,bi in zip(Li, Bi):
            Sgrid[li,bi] += 1.0
        # set NaN to empty cells to ignore them
        Sgrid[Sgrid==0] = np.nan

    # renormalize to <S>=1 over valid cells
    valid = np.isfinite(Sgrid)
    meanS = np.nanmean(Sgrid) if np.any(valid) else np.nan
    if not np.isfinite(meanS) or meanS<=0:
        raise ValueError("Selection grid mean is invalid (all-empty?). Check inputs or grid size.")
    Sgrid = Sgrid / meanS

    # build centers
    l_cent = 0.5*(l_edges[:-1]+l_edges[1:])
    b_cent = 0.5*(b_edges[:-1]+b_edges[1:])
    rows = []
    for li in range(nb_l):
        for bi in range(nb_b):
            if np.isfinite(Sgrid[li,bi]):
                rows.append((float(l_cent[li]%360.0), float(b_cent[bi]), float(Sgrid[li,bi])))
    out = pd.DataFrame(rows, columns=["l_deg","b_deg","S"])
    return out

# ------------------------ ECDF + null ------------------------

def ecdf(x):
    xs = np.sort(np.asarray(x))
    n = len(xs)
    y = np.arange(1, n+1)/n
    return xs, y

def make_null_band_from_S(basins_df, Smap_df, nboots=999, rng_seed=42):
    """
    Build 95% null band for ECDF of sin|b| preserving S(l,b) by *importance sampling*
    from the gridded selection map.
    For each bootstrap, sample N positions with prob proportional to S and compute ECDF(sin|b|).
    """
    rng = np.random.default_rng(rng_seed)
    N = len(basins_df)
    # probabilities proportional to S
    w = np.clip(Smap_df["S"].values, 0, None)
    if not np.any(w>0):
        raise ValueError("All S<=0 in selection_map.")
    p = w / w.sum()

    # sample b from the grid centers
    b_vals = Smap_df["b_deg"].values
    ecdfs = []
    x_grid = np.linspace(0,1,61)
    for _ in range(nboots):
        idx = rng.choice(len(Smap_df), size=N, replace=True, p=p)
        sinb = sinabsb_deg(b_vals[idx])
        xs, ys = ecdf(sinb)
        ecdfs.append(np.interp(x_grid, xs, ys, left=0.0, right=1.0))
    ecdfs = np.stack(ecdfs, axis=0)
    lower = np.percentile(ecdfs, 2.5, axis=0)
    upper = np.percentile(ecdfs, 97.5, axis=0)
    median = np.percentile(ecdfs, 50.0, axis=0)
    return x_grid, median, lower, upper

def flat_sky_moments(l_deg, b_deg):
    """Flat-sky dipole/quadrupole proxy from centroid positions."""
    l0, b0 = np.mean(l_deg), np.mean(b_deg)
    x = (l_deg - l0) * np.cos(np.deg2rad(b0))
    y = (b_deg - b0)
    # standardize
    x = (x - np.mean(x)) / (np.std(x)+1e-9)
    y = (y - np.mean(y)) / (np.std(y)+1e-9)
    # dipole via least squares: fit 1 ~ ax x + ay y
    A = np.vstack([x, y]).T
    coeff, _, _, _ = np.linalg.lstsq(A, np.ones_like(x), rcond=None)
    ax, ay = coeff
    Adip = float(np.sqrt(ax*ax + ay*ay))
    # quadrupole proxy via second moments
    Qxx = float(np.mean(x*x)); Qyy = float(np.mean(y*y)); Qxy = float(np.mean(x*y))
    Aquad = float(np.sqrt((Qxx-Qyy)**2 + 4*Qxy*Qxy))
    return Adip, Aquad

def write_fig66_tex(outdir: Path, xs, data_ecdf, null_med, null_lo, null_hi, Adip, Aquad):
    tex = f"""
% --- Fig.66: ECDF sin|b| + inset dipole/quadrupole ---
\\begin{{figure}}[t]
\\centering
\\begin{{minipage}}{{0.68\\linewidth}}
\\begin{{tikzpicture}}
\\begin{{axis}}[
  width=\\linewidth, height=5cm,
  xlabel={{$\\sin|b|$}}, ylabel={{ECDF}},
  xmin=0, xmax=1, ymin=0, ymax=1,
  ticklabel style={{font=\\footnotesize}},
  label style={{font=\\footnotesize}},
  legend style={{draw=none, fill=none, font=\\footnotesize, at={{(0.02,0.98)}}, anchor=north west}},
  clip=false,
]
% null band (95%) from selection-preserving null
\\addplot [name path=upper, draw=none] coordinates {list(zip(xs, null_hi))};
\\addplot [name path=lower, draw=none] coordinates {list(zip(xs, null_lo))};
\\addplot [fill=black!12, draw=none] fill between[of=upper and lower];
% median null
\\addplot [densely dashed] coordinates {list(zip(xs, null_med))};
% data ECDF
\\addplot [very thick] coordinates {list(zip(xs, data_ecdf))};
\\addlegendentry{{Data}}
\\addlegendentry{{Null band (95\\%)}}
\\end{{axis}}
\\end{{tikzpicture}}
\\end{{minipage}}\\hfill
\\begin{{minipage}}{{0.28\\linewidth}}
\\begin{{tikzpicture}}
\\begin{{axis}}[
  width=\\linewidth, height=5cm,
  ybar, bar width=7pt,
  xmin=0.5, xmax=2.5, ymin=0, ymax={{max(0.08, {max(Adip,Aquad):.3f}*1.6):.2f}},
  xtick={{1,2}}, xticklabels={{Dipole,Quadrupole}},
  ylabel={{Amplitude}}, ticklabel style={{font=\\footnotesize}},
  label style={{font=\\footnotesize}}
]
\\addplot[fill=black!40] coordinates {{(1,{Adip:.3f}) (2,{Aquad:.3f})}};
\\end{{axis}}
\\end{{tikzpicture}}
\\end{{minipage}}
\\caption{{ECDF of $\\sin|b|$ for min-basin centroids (data) versus the selection-preserving null (median and 95\\% envelope). Inset: flat-sky moment amplitudes (dipole, quadrupole).}}
\\label{{fig:gp_ecdf_dipquad}}
\\end{{figure}}
"""
    (outdir / "fig66.tex").write_text(tex, encoding="utf-8")

# ------------------------ main ------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=str, default=".", help="folder with files")
    ap.add_argument("--sel-file", type=str, default=None, help="selection/density file (CSV) e.g. gaia_codex_filtered_density.csv")
    ap.add_argument("--sel-col", type=str, default=None, help="column to use as selection S (e.g. local_density). If omitted: counts per grid cell")
    ap.add_argument("--grid-deg", type=float, default=0.25, help="grid size in degrees when building a selection map from star catalogs")
    ap.add_argument("--make-fig66", action="store_true", help="compute ECDF+null and emit fig66.tex")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    os.chdir(root)

    # 1) basins_min_centroids.csv
    basins_df = None
    for fname in CAND_NODES_CSV:
        p = root / fname
        if p.exists():
            try:
                basins_df = load_min_centroids_from_nodes_csv(p)
                print(f"[OK] Centroids from {p.name} -> {len(basins_df)} rows")
                break
            except Exception as e:
                print(f"[WARN] {p.name}: {e}")
    if basins_df is None:
        for fname in CAND_BASINS_GEOJSON:
            p = root / fname
            if p.exists():
                try:
                    basins_df = load_min_centroids_from_geojson(p)
                    print(f"[OK] Centroids from {p.name} (GeoJSON) -> {len(basins_df)} rows")
                    break
                except Exception as e:
                    print(f"[WARN] {p.name}: {e}")
    if basins_df is None:
        print("[FATAL] No min-basin centroids found. Provide one of:", CAND_NODES_CSV + CAND_BASINS_GEOJSON)
        sys.exit(2)

    basins_out = root / "basins_min_centroids.csv"
    basins_df[["l_deg","b_deg"]].to_csv(basins_out, index=False)
    print(f"[WRITE] {basins_out.name} ({len(basins_df)} rows)")

    # 2) selection_map.csv
    sel_df = None
    if args.sel_file:
        p = root / args.sel_file
        if not p.exists():
            print(f"[FATAL] Selection file {args.sel_file} not found in {root}")
            sys.exit(3)
        try:
            sel_df = build_selection_from_catalog(p, sel_col=args.sel_col, grid_deg=args.grid_deg)
            print(f"[OK] Built gridded selection from {p.name} ({len(sel_df)} cells, <S>=1)")
        except Exception as e:
            print(f"[FATAL] Could not build selection from {p.name}: {e}")
            sys.exit(4)
    else:
        print("[FATAL] --sel-file is required to build a selection-preserving null (recommended).")
        print("        Alternatively, supply a mask polygon to build uniform S=1 inside the true patch (not recommended for Fig.66).")
        sys.exit(5)

    sel_out = root / "selection_map.csv"
    sel_df.to_csv(sel_out, index=False)
    print(f"[WRITE] {sel_out.name} ({len(sel_df)} rows)")

    if not args.make_fig66:
        return

    # 3) Fig.66: ECDF + null band + moments
    xs_data, ys_data = ecdf(sinabsb_deg(basins_df["b_deg"].values))
    xs, med, lo, hi = make_null_band_from_S(basins_df, sel_df, nboots=999, rng_seed=42)
    y_data_interp = np.interp(xs, xs_data, ys_data, left=0.0, right=1.0)
    Adip, Aquad = flat_sky_moments(basins_df["l_deg"].values, basins_df["b_deg"].values)

    # 4) write outputs
    metrics = pd.DataFrame({
        "xs": xs, "ecdf_data": y_data_interp, "null_median": med, "null_lo": lo, "null_hi": hi
    })
    metrics.to_csv(root/"fig66_metrics.csv", index=False)
    print("[WRITE] fig66_metrics.csv")
    write_fig66_tex(root, xs, y_data_interp, med, lo, hi, Adip, Aquad)
    print("[WRITE] fig66.tex (TikZ)")

if __name__ == "__main__":
    main()
