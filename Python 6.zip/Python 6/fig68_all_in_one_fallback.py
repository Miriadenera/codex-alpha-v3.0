#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse, json, numpy as np, pandas as pd, matplotlib.pyplot as plt
from shapely.geometry import shape, Point
from shapely.strtree import STRtree
try:
    from shapely.validation import make_valid
except Exception:
    make_valid = None

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

# ----------------- utilità colonne -----------------
def _find_cols(df, need_sel=False):
    low = {c.lower(): c for c in df.columns}
    # l,b
    candL = [k for k in low if k in ("l_deg_aligned","l_deg","l","lon","longitude")]
    candB = [k for k in low if k in ("b_deg","b","lat","latitude")]
    if not candL or not candB:
        raise RuntimeError("Non trovo colonne l/b nel CSV.")
    colL, colB = low[candL[0]], low[candB[0]]
    # S(l,b)
    colS = None
    if need_sel:
        candS = [k for k in low if (k=="s" or k.startswith("s_") or k.startswith("sel") or k=="local_density")]
        if not candS:
            raise RuntimeError("selection CSV: non trovo una colonna tipo S*.")
        colS = low[candS[0]]
    return colL, colB, colS

# ----------------- geometrie robuste -----------------
def _iter_polys_from_geojson(path):
    with open(path, "r", encoding="utf-8") as f:
        gj = json.load(f)
    feats = gj["features"] if "features" in gj else [gj]
    for ft in feats:
        g = shape(ft.get("geometry", {})) if ft.get("geometry") else None
        if g is None: continue
        if make_valid is not None: g = make_valid(g)
        if not g.is_valid: g = g.buffer(0)
        if g.is_empty:     continue
        if g.geom_type == "Polygon":
            yield g
        elif g.geom_type == "MultiPolygon":
            for p in g.geoms:
                if make_valid is not None: p = make_valid(p)
                if not p.is_valid: p = p.buffer(0)
                if not p.is_empty: yield p

def _build_poly_index(geojson_path):
    polys = [p for p in _iter_polys_from_geojson(geojson_path)]
    if not polys:
        return [], None
    return polys, STRtree(polys)

def _point_in_any(polys, tree, l_deg, b_deg):
    if not polys: return False
    pt = Point(float(l_deg), float(b_deg))
    for cand in tree.query(pt):
        try:
            if cand.contains(pt): return True
        except Exception:
            c = make_valid(cand) if make_valid is not None else cand.buffer(0)
            if c.contains(pt): return True
    return False

# ------------- distanza sferica piccol-angolo -------------
def _ang_sep_deg(l1, b1, l2, b2):
    # wrap longitudini in [-180,180] w.r.t l2
    dl = ((l1 - l2 + 180.0) % 360.0) - 180.0
    cb = np.cos(np.deg2rad(b1))
    return np.hypot(dl * cb, b1 - b2)

# ----------------- costruzione dataset -----------------
def make_points(basins_geo, centroids_csv, dens_csv, col_l, col_b, col_sigma,
                selection_csv, sample, r_deg, out_points_csv):
    # densità
    df = pd.read_csv(dens_csv, low_memory=False)
    if col_l not in df.columns or col_b not in df.columns:
        col_l, col_b, _ = _find_cols(df, need_sel=False)
    L = pd.to_numeric(df[col_l], errors="coerce").to_numpy()
    B = pd.to_numeric(df[col_b], errors="coerce").to_numpy()
    Sg = pd.to_numeric(df[col_sigma], errors="coerce").to_numpy()
    keep = np.isfinite(L) & np.isfinite(B) & np.isfinite(Sg)
    L, B, Sg = L[keep], B[keep], Sg[keep]
    if L.size == 0:
        raise RuntimeError("Catalogo densità vuoto dopo il filtraggio.")

    # 1) tentativo con poligoni
    polys, tree = _build_poly_index(basins_geo) if basins_geo else ([], None)
    inside = None
    if polys:
        inside = np.fromiter((_point_in_any(polys, tree, l, b) for l, b in zip(L, B)),
                             dtype=bool, count=L.size)
    # 2) fallback con centroidi + raggio
    if inside is None or inside.sum() == 0:
        if not centroids_csv:
            raise RuntimeError("pos=0 dentro poligoni e nessun centroids CSV passato per il fallback.")
        C = pd.read_csv(centroids_csv)
        cLcol, cBcol, _ = _find_cols(C, need_sel=False)
        CL = pd.to_numeric(C[cLcol], errors="coerce").dropna().to_numpy()
        CB = pd.to_numeric(C[cBcol], errors="coerce").dropna().to_numpy()
        if CL.size == 0:
            raise RuntimeError("Centroidi non validi nel CSV.")
        # distanza minima a un centroide
        dmin = np.full(L.shape, np.inf)
        for chunk in np.array_split(np.arange(CL.size), max(1, CL.size//5000)):
            dl = _ang_sep_deg(L[:,None], B[:,None], CL[chunk][None,:], CB[chunk][None,:])
            dmin = np.minimum(dmin, dl.min(axis=1))
        inside = dmin <= float(r_deg)

    n_pos, n_neg = int(inside.sum()), int((~inside).sum())
    if n_pos == 0 or n_neg == 0:
        raise RuntimeError(f"Nessun bilanciamento possibile (pos={n_pos}, neg={n_neg}).")

    # campionamento bilanciato
    rng = np.random.RandomState(7)
    n_each = int(min(sample//2, n_pos, n_neg))
    n_each = max(n_each, 50)  # almeno 50 per classe
    pos_idx = rng.choice(np.where(inside)[0], size=n_each, replace=False)
    neg_idx = rng.choice(np.where(~inside)[0], size=n_each, replace=False)
    idx = np.r_[pos_idx, neg_idx]

    Ls, Bs, Sigmas = L[idx], B[idx], Sg[idx]
    ys = np.r_[np.ones(n_each, dtype=int), np.zeros(n_each, dtype=int)]

    # S(l,b) se fornita
    if selection_csv:
        sel = pd.read_csv(selection_csv, low_memory=False)
        selL, selB, selS = _find_cols(sel, need_sel=True)
        SL, SB, SS = sel[selL].to_numpy(float), sel[selB].to_numpy(float), sel[selS].to_numpy(float)
        jj = np.argmin((Ls[:,None]-SL[None,:])**2 + (Bs[:,None]-SB[None,:])**2, axis=1)
        Selw = SS[jj]
    else:
        Selw = np.ones_like(Ls)

    T = pd.DataFrame({"y": ys, "abs_b": np.abs(Bs), "Sigma_star": Sigmas, "Sel": Selw,
                      "l": Ls, "b": Bs})
    T.to_csv(out_points_csv, index=False)
    return T

# ----------------- fit + plot -----------------
def fit_and_plot(T, Bboot, out_pdf, out_csv):
    X = T[["abs_b","Sigma_star","Sel"]].to_numpy(float)
    y = T["y"].to_numpy(int)
    m, s = X.mean(0), X.std(0); s[s==0] = 1.0
    Xs = (X - m) / s
    lr = LogisticRegression(solver="liblinear")
    lr.fit(Xs, y)
    beta_hat = lr.coef_.ravel()
    auc_hat  = roc_auc_score(y, lr.predict_proba(Xs)[:,1])

    rng = np.random.RandomState(42)
    betas = np.full((Bboot,3), np.nan); aucs = np.full(Bboot, np.nan)
    n = len(y)
    for b in range(Bboot):
        ii = rng.randint(0, n, size=n)
        Xb, yb = Xs[ii], y[ii]
        if len(np.unique(yb)) < 2: continue
        lrb = LogisticRegression(solver="liblinear")
        lrb.fit(Xb, yb)
        betas[b,:] = lrb.coef_.ravel()
        aucs[b]    = roc_auc_score(yb, lrb.predict_proba(Xb)[:,1])

    q = lambda v: np.nanpercentile(v, [2.5, 97.5])
    ci_beta = np.vstack([q(betas[:,0]), q(betas[:,1]), q(betas[:,2])])
    ci_auc  = q(aucs)

    pd.DataFrame({
        "beta": ["beta_abs_b","beta_Sigma_star","beta_Sel"],
        "hat": beta_hat, "ci_lo": ci_beta[:,0], "ci_hi": ci_beta[:,1]
    }).to_csv(out_csv, index=False)

    fig = plt.figure(figsize=(6.2,3.4))
    ax = fig.add_axes([0.11,0.18,0.58,0.74])
    names = [r"$\beta_1$ (|b|)", r"$\beta_2$ ($\Sigma_\star$)", r"$\beta_3$ ($S$)"]
    ypos  = np.arange(3)[::-1] + 1
    ax.axvline(0, lw=0.8, ls="--", alpha=0.6)
    xerr = np.vstack([beta_hat - ci_beta[:,0], ci_beta[:,1] - beta_hat]).T
    ax.errorbar(beta_hat, ypos, xerr=xerr.T, fmt="s", capsize=3)
    ax.set_yticks(ypos); ax.set_yticklabels(names)
    ax.set_xlabel("Logit coefficient"); ax.set_ylim(0.4, 3.6)

    ax2 = fig.add_axes([0.74,0.28,0.22,0.6])
    ax2.bar([0],[auc_hat], width=0.35)
    ax2.vlines([0], [ci_auc[0]], [ci_auc[1]], lw=2)
    ax2.set_xticks([0]); ax2.set_xticklabels(["AUC"])
    ax2.set_ylim(0.45,1.00)

    fig.savefig(out_pdf, bbox_inches="tight")
    print(f"[WRITE] {out_pdf} ; AUC={auc_hat:.3f} (95% CI {ci_auc[0]:.3f}–{ci_auc[1]:.3f})")

# ----------------- CLI -----------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--basins-geo", default=None)
    ap.add_argument("--basins-centroids", default=None)
    ap.add_argument("--density-csv", required=True)
    ap.add_argument("--selection-csv", default=None)
    ap.add_argument("--col-l", default="l_deg_aligned")
    ap.add_argument("--col-b", default="b_deg")
    ap.add_argument("--col-sigma", default="local_density")
    ap.add_argument("--sample", type=int, default=4000)
    ap.add_argument("--r-deg", type=float, default=0.6, help="raggio fallback attorno ai centroidi")
    ap.add_argument("--B", type=int, default=600)
    ap.add_argument("--out-pdf", default="fig68_forest_auc.pdf")
    ap.add_argument("--out-csv", default="fig68_betas_auc.csv")
    ap.add_argument("--out-points", default="fig68_points.csv")
    args = ap.parse_args()

    T = make_points(args.basins_geo, args.basins-centroids if hasattr(args,'basins-centroids') else args.basins_centroids,
                    args.density_csv, args.col_l, args.col_b, args.col_sigma,
                    args.selection_csv, args.sample, args.r_deg, args.out_points)
    print(f"[WRITE] {args.out_points} (n={len(T)}, pos={int(T['y'].sum())}, neg={int((1-T['y']).sum())})")
    fit_and_plot(T, args.B, args.out_pdf, args.out_csv)

if __name__ == "__main__":
    main()
