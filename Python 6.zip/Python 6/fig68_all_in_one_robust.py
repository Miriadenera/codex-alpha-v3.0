#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse, json, numpy as np, pandas as pd, matplotlib.pyplot as plt
from shapely.geometry import shape, Point
from shapely.strtree import STRtree
try:  # Shapely >= 2
    from shapely.validation import make_valid
except Exception:
    make_valid = None

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

# -------------------------
# Utilità colonne e selezione
# -------------------------
def _find_cols(df, want_l="l", want_b="b", want_s="s"):
    cols = [c.lower() for c in df.columns]
    m = {c.lower(): c for c in df.columns}

    candL = [m[c] for c in cols if c in ("l_deg_aligned","l_deg","l","lon","longitude")]
    candB = [m[c] for c in cols if c in ("b_deg","b","lat","latitude")]
    if not candL or not candB:
        raise RuntimeError("Non trovo le colonne l/b nel CSV.")
    colL, colB = candL[0], candB[0]

    # per la mappa di selezione: prendi S*, oppure qualunque colonna che inizi per 's'
    sCands = [m[c] for c in cols if (c == "s" or c.startswith("s_") or c.startswith("sel") or c == "local_density")]
    if want_s and not sCands:
        raise RuntimeError("selection CSV: non trovo colonna S* (peso).")
    colS = sCands[0] if want_s else None
    return colL, colB, colS

def _nearest_sel_for_points(L, B, sel_df):
    colL, colB, colS = _find_cols(sel_df, want_s="s")
    SL, SB, SS = sel_df[colL].to_numpy(float), sel_df[colB].to_numpy(float), sel_df[colS].to_numpy(float)
    # per N_sel piccolo è ok fare NN brute-force
    idx = np.argmin((L[:,None]-SL[None,:])**2 + (B[:,None]-SB[None,:])**2, axis=1)
    return SS[idx]

# -------------------------
# Geometrie robuste (niente unary_union)
# -------------------------
def _iter_polys_from_geojson(path):
    with open(path, "r", encoding="utf-8") as f:
        gj = json.load(f)
    feats = gj["features"] if "features" in gj else [gj]
    for ft in feats:
        if "geometry" not in ft or ft["geometry"] is None:
            continue
        g = shape(ft["geometry"])
        if make_valid is not None:
            g = make_valid(g)
        if not g.is_valid:
            g = g.buffer(0)
        if g.is_empty:
            continue
        if g.geom_type == "Polygon":
            yield g
        elif g.geom_type == "MultiPolygon":
            for p in g.geoms:
                if make_valid is not None:
                    p = make_valid(p)
                if not p.is_valid:
                    p = p.buffer(0)
                if not p.is_empty:
                    yield p

def _build_poly_index(geojson_path):
    polys = [p for p in _iter_polys_from_geojson(geojson_path)]
    if not polys:
        raise RuntimeError("Nessun poligono valido nel geojson dei basins.")
    tree = STRtree(polys)
    return polys, tree

def _point_in_any(polys, tree, l_deg, b_deg):
    pt = Point(float(l_deg), float(b_deg))
    # query bb per candidati e poi contains
    for cand in tree.query(pt):
        try:
            if cand.contains(pt):
                return True
        except Exception:
            c = make_valid(cand) if make_valid is not None else cand.buffer(0)
            if c.contains(pt):
                return True
    return False

# -------------------------
# Costruzione dataset e modello
# -------------------------
def make_points(basins_geo, dens_csv, col_l, col_b, col_sigma, selection_csv, sample, out_points_csv):
    polys, tree = _build_poly_index(basins_geo)

    df = pd.read_csv(dens_csv, low_memory=False)
    # autodetect se col_l/col_b non esistono
    if col_l not in df.columns or col_b not in df.columns:
        col_l, col_b, _ = _find_cols(df, want_s=None)

    L = pd.to_numeric(df[col_l], errors="coerce").to_numpy()
    B = pd.to_numeric(df[col_b], errors="coerce").to_numpy()
    Sg = pd.to_numeric(df[col_sigma], errors="coerce").to_numpy()
    keep = np.isfinite(L) & np.isfinite(B) & np.isfinite(Sg)
    L, B, Sg = L[keep], B[keep], Sg[keep]
    if L.size == 0:
        raise RuntimeError("Catalogo densità vuoto dopo il filtraggio.")

    # inside: point-in-polygon con STRtree
    inside = np.fromiter((_point_in_any(polys, tree, l, b) for l, b in zip(L, B)), dtype=bool, count=L.size)
    n_pos, n_neg = int(inside.sum()), int((~inside).sum())
    if n_pos == 0 or n_neg == 0:
        raise RuntimeError(f"Nessun bilanciamento possibile (pos={n_pos}, neg={n_neg}). Aumenta area o verifica i basins.")

    # campionamento bilanciato
    rng = np.random.RandomState(7)
    n_each = int(min(sample//2, n_pos, n_neg))
    if n_each < 50:
        # stringi meno: prova con tutto ciò che hai, bilanciando sul minimo
        n_each = int(min(n_pos, n_neg))
        if n_each < 25:
            raise RuntimeError(f"Troppi pochi esempi (pos={n_pos}, neg={n_neg}).")

    pos_idx = rng.choice(np.where(inside)[0], size=n_each, replace=False)
    neg_idx = rng.choice(np.where(~inside)[0], size=n_each, replace=False)
    idx = np.r_[pos_idx, neg_idx]

    Ls, Bs, Sigmas = L[idx], B[idx], Sg[idx]
    ys = np.r_[np.ones(n_each, dtype=int), np.zeros(n_each, dtype=int)]

    # pesi S(l,b) se forniti
    if selection_csv:
        sel = pd.read_csv(selection_csv, low_memory=False)
        Selw = _nearest_sel_for_points(Ls, Bs, sel)
    else:
        Selw = np.ones_like(Ls)

    T = pd.DataFrame({
        "y": ys,
        "abs_b": np.abs(Bs),
        "Sigma_star": Sigmas,
        "Sel": Selw,
        "l": Ls, "b": Bs
    })
    T.to_csv(out_points_csv, index=False)
    return T

def fit_and_plot(T, Bboot, out_pdf, out_csv):
    X = T[["abs_b","Sigma_star","Sel"]].to_numpy(float)
    y = T["y"].to_numpy(int)

    # standardizza
    m, s = X.mean(0), X.std(0); s[s==0] = 1.0
    Xs = (X - m) / s

    if len(np.unique(y)) < 2:
        raise RuntimeError("Il campione ha una sola classe. Rigenera i punti.")

    lr = LogisticRegression(solver="liblinear")
    lr.fit(Xs, y)
    beta_hat = lr.coef_.ravel()
    auc_hat  = roc_auc_score(y, lr.predict_proba(Xs)[:,1])

    # bootstrap IID
    rng = np.random.RandomState(42)
    betas = np.zeros((Bboot,3)); betas[:] = np.nan
    aucs  = np.zeros(Bboot);     aucs[:]  = np.nan
    n = len(y)
    for b in range(Bboot):
        idx = rng.randint(0, n, size=n)
        Xb, yb = Xs[idx], y[idx]
        if len(np.unique(yb)) < 2:
            continue
        lrb = LogisticRegression(solver="liblinear")
        lrb.fit(Xb, yb)
        betas[b,:] = lrb.coef_.ravel()
        aucs[b]    = roc_auc_score(yb, lrb.predict_proba(Xb)[:,1])

    def q95(v):
        return np.nanpercentile(v, [2.5, 97.5])

    ci_beta = np.vstack([q95(betas[:,0]), q95(betas[:,1]), q95(betas[:,2])])
    ci_auc  = q95(aucs)

    out = pd.DataFrame({
        "beta": ["beta_abs_b","beta_Sigma_star","beta_Sel"],
        "hat": beta_hat,
        "ci_lo": ci_beta[:,0],
        "ci_hi": ci_beta[:,1]
    })
    out.to_csv(out_csv, index=False)

    # --- plot forest + inset AUC (stile simile a quello che hai già in 2.3)
    fig = plt.figure(figsize=(6.2,3.4))
    ax = fig.add_axes([0.11,0.18,0.58,0.74])
    names = [r"$\beta_1$ (|b|)", r"$\beta_2$ ($\Sigma_\star$)", r"$\beta_3$ ($S$)"]
    ypos  = np.arange(3)[::-1] + 1
    ax.axvline(0, lw=0.8, ls="--", alpha=0.6)
    xerr = np.vstack([beta_hat - ci_beta[:,0], ci_beta[:,1] - beta_hat]).T
    ax.errorbar(beta_hat, ypos, xerr=xerr.T, fmt="s", capsize=3)
    ax.set_yticks(ypos); ax.set_yticklabels(names)
    ax.set_xlabel("Logit coefficient")
    ax.set_ylim(0.4, 3.6)

    ax2 = fig.add_axes([0.74,0.28,0.22,0.6])
    ax2.bar([0],[auc_hat], width=0.35)
    ax2.vlines([0], [ci_auc[0]], [ci_auc[1]], lw=2)
    ax2.set_xticks([0]); ax2.set_xticklabels(["AUC"])
    ax2.set_ylim(0.45, 1.00)

    fig.savefig(out_pdf, bbox_inches="tight")
    print(f"[WRITE] {out_pdf} ; AUC={auc_hat:.3f}  (95% CI {ci_auc[0]:.3f}–{ci_auc[1]:.3f})")

# -------------------------
# CLI
# -------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--basins-geo", required=True)
    ap.add_argument("--density-csv", required=True)
    ap.add_argument("--selection-csv", default=None)
    ap.add_argument("--col-l", default="l_deg_aligned")
    ap.add_argument("--col-b", default="b_deg")
    ap.add_argument("--col-sigma", default="local_density")
    ap.add_argument("--sample", type=int, default=4000)
    ap.add_argument("--B", type=int, default=600)
    ap.add_argument("--out-pdf", default="fig68_forest_auc.pdf")
    ap.add_argument("--out-csv", default="fig68_betas_auc.csv")
    ap.add_argument("--out-points", default="fig68_points.csv")
    args = ap.parse_args()

    T = make_points(args.basins_geo, args.density_csv, args.col_l, args.col_b,
                    args.col_sigma, args.selection_csv, args.sample, args.out_points)
    print(f"[WRITE] {args.out_points} (n={len(T)}, pos={int(T['y'].sum())}, neg={int((1-T['y']).sum())})")
    fit_and_plot(T, args.B, args.out_pdf, args.out_csv)

if __name__ == "__main__":
    main()
