# fig70_allinone.py
import argparse, json, numpy as np, pandas as pd, matplotlib.pyplot as plt
from shapely.geometry import shape, LineString, Point
from shapely.ops import unary_union
from math import cos, sin, atan2, radians, degrees

# ----------------- geo/ang helpers -----------------
def angsep_deg(l1, b1, l2, b2):
    L1, B1, L2, B2 = map(np.deg2rad, [l1, b1, l2, b2])
    d = np.arctan2(np.sqrt((np.cos(B2)*np.sin(L2-L1))**2 +
                           (np.cos(B1)*np.sin(B2) - np.sin(B1)*np.cos(B2)*np.cos(L2-L1))**2),
                   np.sin(B1)*np.sin(B2) + np.cos(B1)*np.cos(B2)*np.cos(L2-L1))
    return np.rad2deg(d)

def wrap_l(l): 
    x = np.asarray(l)
    x = np.where(x<0, x+360, x)
    return np.where(x>=360, x-360, x)

def rotate_longitude(l, dlon):
    return wrap_l(l + dlon)

def line_azimuth_deg(xy):
    # azimut modulo pi (assiale) della polilinea (direzione media dei segmenti)
    ths, w = [], []
    for (x1,y1),(x2,y2) in zip(xy[:-1], xy[1:]):
        dx, dy = np.deg2rad(x2-x1), np.deg2rad(y2-y1)
        th = atan2(dy, dx)
        ths.append(th); w.append(np.hypot(dx,dy))
    if not ths: 
        return 0.0
    th = np.arctan2(np.sum(np.sin(2*np.array(ths))*w),
                    np.sum(np.cos(2*np.array(ths))*w))/2.0
    return (degrees(th) % 180.0)

def resample_polyline(ls:LineString, step_deg=0.1):
    # ritorna punti equispaziati (~step_deg) e tangenti (mod pi)
    coords = np.array(ls.coords, float)
    if len(coords)<2: return [], []
    # lunghezze cumulative in gradi euclidei (flat-sky sufficiente per scale piccole)
    seg = np.hypot(np.diff(coords[:,0]), np.diff(coords[:,1]))
    L = np.r_[0, np.cumsum(seg)]
    if L[-1]==0: return [], []
    n = max(2, int(np.ceil(L[-1]/step_deg)))
    s = np.linspace(0, L[-1], n)
    px = np.interp(s, L, coords[:,0])
    py = np.interp(s, L, coords[:,1])
    # tangente locale
    t = []
    for i in range(n):
        i1 = max(0, i-1); i2 = min(n-1, i+1)
        t.append(line_azimuth_deg(np.c_[px[i1:i2+1], py[i1:i2+1]]))
    return np.c_[px,py], np.array(t)

def load_union_polys(geo_path):
    with open(geo_path,"r",encoding="utf-8") as f:
        gj = json.load(f)
    feats = gj["features"] if "features" in gj else [gj]
    geoms=[]
    for ft in feats:
        try: geoms.append(shape(ft["geometry"]))
        except: pass
    if not geoms: raise RuntimeError("Nessuna geometria valida in geojson.")
    return unary_union(geoms)

def read_edges_geo(geo_path):
    with open(geo_path,"r",encoding="utf-8") as f:
        gj = json.load(f)
    feats = gj["features"] if "features" in gj else [gj]
    out=[]
    for ft in feats:
        try:
            geom = shape(ft["geometry"])
            if isinstance(geom, LineString):
                out.append(np.array(geom.coords, float))
        except: pass
    return out

# ----------------- selection-weighted randoms -----------------
def sample_from_selection(sel_csv, n, colL="l_deg_aligned", colB="b_deg", colS_like="S"):
    df = pd.read_csv(sel_csv)
    candS = [c for c in df.columns if c.lower().startswith(colS_like.lower())]
    if not candS: 
        # se non c'è S, usa densità come peso ~ ok
        candS = [c for c in df.columns if "density" in c.lower()]
    if not candS:
        candS = [df.columns[-1]]
    colS = candS[0]
    L, B, W = df[colL].to_numpy(), df[colB].to_numpy(), df[colS].to_numpy()
    W = np.clip(np.nan_to_num(W, nan=0.0, posinf=0.0, neginf=0.0), 0, None)
    if W.sum()==0: W = np.ones_like(W)
    idx = np.random.RandomState(17).choice(len(L), size=n, replace=True, p=W/W.sum())
    return L[idx], B[idx]

# ----------------- Landy–Szalay cross w(theta) -----------------
def pair_hist(lA,bA,lB,bB,bins_deg):
    # istogramma separazioni
    h = np.zeros(len(bins_deg)-1, float)
    # per velocità: campionamento a blocchi
    A = np.c_[lA,bA]; B = np.c_[lB,bB]
    for a in A:
        d = angsep_deg(a[0],a[1], B[:,0],B[:,1])
        h += np.histogram(d, bins=bins_deg)[0]
    return h

def landy_szalay_wtheta(lA,bA,lB,bB,lAr,bAr,lBr,bBr,bins_deg):
    DD = pair_hist(lA,bA,lB,bB,bins_deg)
    DR = pair_hist(lA,bA,lBr,bBr,bins_deg)
    RD = pair_hist(lAr,bAr,lB,bB,bins_deg)
    RR = pair_hist(lAr,bAr,lBr,bBr,bins_deg) + 1e-9
    return (DD - DR - RD + RR)/RR

# ----------------- allineamento locale |cos(Δφ)| -----------------
def nearest_with_tangent(L, B, P, T):
    # Restituisce i tangenti del punto P più vicino
    # P: (N,2) punti filamento; T: (N,) tangenti
    # naive O(N) per semplicità (N di solito è ~ qualche 1e4)
    out=[]
    for l,b in zip(L,B):
        d = (P[:,0]-l)**2 + (P[:,1]-b)**2
        j = d.argmin()
        out.append(T[j])
    return np.array(out)

def axial_cosdiff(th_edge, th_fil):
    # assiale: angoli in gradi modulo 180
    de = np.deg2rad((th_edge - th_fil + 90.) % 180. - 90.)
    return np.abs(np.cos(de))

# ----------------- main -----------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--centroids", required=True)                 # basins_min_centroids.csv (l_deg_aligned,b_deg)
    ap.add_argument("--filaments-geo", default=None)              # GeoJSON di polilinee filamenti
    ap.add_argument("--filaments-csv", default=None)              # CSV con colonne: fid,l_deg,b_deg (polilinee per fid)
    ap.add_argument("--edges-geo", required=True)                 # topo_edges_patch.geojson (LineString)
    ap.add_argument("--selection-csv", required=True)             # selection_map_aligned.csv (l_deg_aligned,b_deg,S*)
    ap.add_argument("--step-arcmin", type=float, default=6.0)     # campionamento filamenti (minuti d'arco)
    ap.add_argument("--theta-max-deg", type=float, default=6.0)   # range w(theta)
    ap.add_argument("--nbins", type=int, default=12)
    ap.add_argument("--B", type=int, default=600)                 # null replicates
    ap.add_argument("--out-prefix", default="fig70_")
    args = ap.parse_args()

    # --- carica centroidi (DA)
    dcent = pd.read_csv(args.centroids)
    colL = "l_deg" if "l_deg" in dcent.columns else "l_deg_aligned"
    LA, BA = dcent[colL].to_numpy(), dcent["b_deg"].to_numpy()

    # --- carica filamenti e campiona punti + tangenti (DB)
    fil_segments=[]
    if args.filaments_geo:
        with open(args.filaments_geo,"r",encoding="utf-8") as f:
            gj = json.load(f)
        feats = gj["features"] if "features" in gj else [gj]
        for ft in feats:
            geom = shape(ft["geometry"])
            if isinstance(geom, LineString):
                fil_segments.append(np.array(geom.coords,float))
    elif args.filaments_csv:
        df = pd.read_csv(args.filaments_csv)
        fid = df.columns[0] if "fid" not in df.columns else "fid"
        for k,gg in df.groupby(fid):
            fil_segments.append(gg[["l_deg","b_deg"]].to_numpy())
    else:
        raise RuntimeError("Fornisci --filaments-geo oppure --filaments-csv.")

    step_deg = args.step_arcmin/60.0
    P_list=[]; T_list=[]
    for seg in fil_segments:
        ls = LineString(seg)
        P,T = resample_polyline(ls, step_deg=step_deg)
        if len(P):
            P_list.append(P); T_list.append(T)
    P = np.vstack(P_list); Tfil = np.hstack(T_list)   # punti filamento + tangenti
    LB, BB = P[:,0], P[:,1]

    # --- edges e loro orientazioni
    E = read_edges_geo(args.edges_geo)
    edges_mid = np.array([e.mean(axis=0) for e in E]) if len(E) else np.zeros((0,2))
    edges_th  = np.array([line_azimuth_deg(e) for e in E]) if len(E) else np.zeros(0)

    # --- randoms RA dalla selection S(l,b)
    LrA, BrA = sample_from_selection(args.selection_csv, n=len(LA))

    # --- bins θ
    bins = np.linspace(0, args.theta_max_deg, args.nbins+1)
    theta = 0.5*(bins[:-1]+bins[1:])

    # --- w(theta): dato + null (ruotando i filamenti in longitudine)
    # RB per ogni replica = punti filamento ruotati; RA = come sopra (fisso) per stabilità
    W_data = landy_szalay_wtheta(LA,BA, LB,BB, LrA,BrA, LB,BB, bins)
    W_null = []
    rng = np.random.RandomState(123)
    for b in range(args.B):
        dlon = rng.uniform(0,180.0)   # rotazione longitudine per preservare latitudini
        LBn = rotate_longitude(LB, dlon)
        W_null.append( landy_szalay_wtheta(LA,BA, LBn,BB, LrA,BrA, LBn,BB, bins) )
    W_null = np.array(W_null)
    W_med  = np.nanmedian(W_null, axis=0)
    W_lo   = np.nanpercentile(W_null, 2.5, axis=0)
    W_hi   = np.nanpercentile(W_null,97.5, axis=0)

    # --- allineamento locale |cos(Δφ)| (dato + null)
    # tangente filamento più vicino al midpoint del bordo
    if len(edges_mid):
        Tnear = nearest_with_tangent(edges_mid[:,0], edges_mid[:,1], P, Tfil)
        cos_data = axial_cosdiff(edges_th, Tnear)
        # null ruotando i filamenti
        cos_null = []
        for b in range(args.B):
            dlon = rng.uniform(0,180.0)
            Pn = P.copy(); Pn[:,0] = rotate_longitude(Pn[:,0], dlon)
            Tn = Tfil      # la tangente non cambia con shift in l
            Tnear_n = nearest_with_tangent(edges_mid[:,0], edges_mid[:,1], Pn, Tn)
            cos_null.append( axial_cosdiff(edges_th, Tnear_n) )
        cos_null = np.concatenate(cos_null)
    else:
        cos_data = np.array([0.5])   # fallback sicuro
        cos_null = np.full(100, 0.5)

    # ---------------- plot: sinistra w(theta) ----------------
    figL = plt.figure(figsize=(7.2,4.2))
    ax = figL.add_axes([0.12,0.16,0.83,0.78])
    ax.fill_between(theta, W_lo, W_hi, alpha=0.2, label="Null band (95%)")
    ax.plot(theta, W_med, ls="--", label="Null median")
    ax.plot(theta, W_data, lw=2, label="Data")
    ax.set_xlabel(r"$\theta\,[\mathrm{deg}]$")
    ax.set_ylabel(r"$w(\theta)$")
    ax.legend(loc="best", frameon=False)
    figL.savefig(f"{args.out_prefix}left_wtheta.pdf", bbox_inches="tight")

    # ---------------- plot: destra |cos(Δφ)| ----------------
    figR = plt.figure(figsize=(3.1,4.2))
    ax2 = figR.add_axes([0.25,0.12,0.72,0.82])
    parts = ax2.violinplot([cos_data, cos_null], showmeans=True, showextrema=False)
    ax2.set_xticks([1,2]); ax2.set_xticklabels(["Data","Null"])
    ax2.set_ylabel(r"$|\cos(\theta-\phi)|$")
    ax2.set_ylim(0,1)
    figR.savefig(f"{args.out_prefix}right_align.pdf", bbox_inches="tight")

    # ---------------- pannello combinato + snippet LaTeX ---------------
    figC = plt.figure(figsize=(8.6,4.2))
    axc1 = figC.add_axes([0.08,0.16,0.62,0.78])
    axc1.fill_between(theta, W_lo, W_hi, alpha=0.2)
    axc1.plot(theta, W_med, ls="--")
    axc1.plot(theta, W_data, lw=2)
    axc1.set_xlabel(r"$\theta\,[\mathrm{deg}]$")
    axc1.set_ylabel(r"$w(\theta)$")
    axc2 = figC.add_axes([0.75,0.16,0.22,0.78])
    ax2 = axc2
    ax2.violinplot([cos_data, cos_null], showmeans=True, showextrema=False)
    ax2.set_xticks([1,2]); ax2.set_xticklabels(["Data","Null"])
    ax2.set_ylabel(r"$|\cos(\theta-\phi)|$")
    ax2.set_ylim(0,1)
    figC.savefig(f"{args.out_prefix}combined.pdf", bbox_inches="tight")

    # LateX snippet
    with open(f"{args.out_prefix}latex.txt","w",encoding="utf-8") as f:
        f.write(r"""\begin{figure}[t]
\centering
\begin{subfigure}{0.68\textwidth}
  \centering
  \includegraphics[width=\linewidth]{fig70_left_wtheta.pdf}
\end{subfigure}%
\begin{subfigure}{0.30\textwidth}
  \centering
  \includegraphics[width=\linewidth]{fig70_right_align.pdf}
\end{subfigure}
\caption{Left: two-point cross-correlation $w(\theta)$ (Landy--Szalay) between min--basin centroids and filament templates, with null median and 95\% envelope (filament longitudes randomly rotated within the patch while preserving $S(l,b)$). Right: violin plot of $|\cos(\theta-\phi)|$ for the orientation of graph edges against the tangent to the nearest filament, compared to the pooled null.}
\label{fig:wtheta_align}
\end{figure}
""")
    print("[WRITE] fig70_left_wtheta.pdf, fig70_right_align.pdf, fig70_combined.pdf, fig70_latex.txt")

if __name__ == "__main__":
    main()
