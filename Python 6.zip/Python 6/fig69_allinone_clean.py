# fig69_allinone_clean.py
import json, argparse, math, numpy as np, pandas as pd, matplotlib.pyplot as plt
from shapely.geometry import shape, LineString
from sklearn.neighbors import NearestNeighbors

def read_lines_geojson(path):
    with open(path, "r", encoding="utf-8") as f:
        gj = json.load(f)
    feats = gj["features"] if "features" in gj else [gj]
    lines = []
    for ft in feats:
        try:
            g = shape(ft["geometry"])
            if isinstance(g, LineString):
                lines.append(np.asarray(g.coords))
        except Exception:
            pass
    if not len(lines):
        raise RuntimeError("No LineString geometries in edges geojson.")
    return lines

def line_mid_and_angle_xy(coords):
    # coords in (l,b) degrees; treat as Cartesian on small patch (flat-sky)
    x = np.deg2rad(coords[:,0]); y = np.deg2rad(coords[:,1])
    # end-to-end vector (principal orientation)
    dx = x[-1] - x[0]; dy = y[-1] - y[0]
    # wrap dx into [-pi,pi]
    dx = (dx + np.pi) % (2*np.pi) - np.pi
    phi = math.atan2(dy, dx)  # [-pi,pi]
    phi = (phi + np.pi) % np.pi  # axial: [0,pi)
    xm = (x.mean()); ym = (y.mean())
    return np.rad2deg(xm), np.rad2deg(ym), phi

def load_targets_csv(csv_path):
    df = pd.read_csv(csv_path, low_memory=False)
    candL = [c for c in df.columns if c.lower() in ("l_deg_aligned","l_deg","l","lon","longitude")]
    candB = [c for c in df.columns if c.lower() in ("b_deg","b","lat","latitude")]
    if not candL or not candB:
        raise RuntimeError(f"{csv_path}: non trovo colonne l/b.")
    L = pd.to_numeric(df[candL[0]], errors="coerce").values
    B = pd.to_numeric(df[candB[0]], errors="coerce").values
    m = np.isfinite(L) & np.isfinite(B)
    return np.c_[L[m], B[m]]

def axial_delta(phi_edge, phi_vec):
    d = abs(phi_edge - phi_vec)
    d = d % np.pi
    d = np.where(d > np.pi/2, np.pi - d, d)  # [0,pi/2]
    return d

def block_ids(L, B, block_deg=5.0):
    i = np.floor((L - L.min())/block_deg).astype(int)
    j = np.floor((B - B.min())/block_deg).astype(int)
    return (i,j)

def rayleigh_axial_Z(dtheta):
    # axial test on 2*theta
    z = np.exp(1j*2.0*dtheta)
    R = abs(z.mean())
    return len(dtheta) * (R**2)

def make_null_cosmean(n, reps=1200):
    # null for <|cos Δθ|> with random relative orientation
    # known expectation is 0.5; we estimate its sampling band
    rng = np.random.RandomState(7)
    means = rng.rand(reps, n)  # cos^2(u) trick would work, but simpler: |cos| with u~Uniform[0,pi]
    # Correct way: sample u uniform and take |cos u|
    u = rng.uniform(0.0, np.pi, size=(reps, n))
    means = np.mean(np.abs(np.cos(u)), axis=1)
    lo, hi = np.percentile(means, [2.5, 97.5])
    return lo, hi

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--edges", required=True, help="topo_edges_patch.geojson")
    ap.add_argument("--gals", default=None, help="nearby_galaxies.csv (l_deg,b_deg)")
    ap.add_argument("--use-arms", default=None, help="arms_ridge_aligned.csv (l_deg,b_deg) if no gals")
    ap.add_argument("--block-deg", type=float, default=5.0)
    ap.add_argument("--B", type=int, default=600, help="block bootstrap iters")
    ap.add_argument("--out-prefix", default="fig69_")
    args = ap.parse_args()

    # ---- Edges mid-points + orientations
    lines = read_lines_geojson(args.edges)
    mids = []
    phis = []
    for c in lines:
        xm, ym, phi = line_mid_and_angle_xy(c)
        mids.append((xm, ym)); phis.append(phi)
    mids = np.array(mids)           # [N,2] in degrees
    phi_e = np.array(phis)          # [N] in radians (axial in [0,pi))

    # ---- Targets (galaxies or arms)
    if args.gals is not None:
        T = load_targets_csv(args.gals)
    elif args.use_arms is not None:
        T = load_targets_csv(args.use_arms)
    else:
        raise RuntimeError("Serve --gals nearby_galaxies.csv oppure --use-arms arms_ridge_aligned.csv.")

    # nearest neighbor direction
    nn = NearestNeighbors(n_neighbors=1).fit(T)
    dists, idx = nn.kneighbors(mids)
    tgt = T[idx[:,0]]
    # vector mid -> target
    # convert deg to rad for small-angle vector
    x1, y1 = np.deg2rad(mids[:,0]), np.deg2rad(mids[:,1])
    x2, y2 = np.deg2rad(tgt[:,0]), np.deg2rad(tgt[:,1])
    # account for 360 wrap on longitude (choose shorter arc)
    dx = (x2 - x1 + np.pi) % (2*np.pi) - np.pi
    dy = y2 - y1
    phi_v = np.arctan2(dy, dx) % np.pi

    # Δθ (axial)
    dtheta = axial_delta(phi_e, phi_v)      # [0, pi/2]
    cosabs = np.abs(np.cos(dtheta))
    N = len(dtheta)

    # ---- Rayleigh Z + block bootstrap CI
    L, B = mids[:,0], mids[:,1]
    bid = np.array(list(zip(*block_ids(L,B,args.block_deg)))).T  # shape (2,N)
    # pack unique blocks
    blocks = {}
    for k,(i,j) in enumerate(zip(bid[0], bid[1])):
        blocks.setdefault((i,j), []).append(k)
    block_keys = list(blocks.keys())
    rng = np.random.RandomState(13)
    Zs = []
    for _ in range(args.B):
        sample_idx = []
        for _ in range(len(block_keys)):
            bi = rng.randint(0, len(block_keys))
            sample_idx.extend(blocks[block_keys[bi]])
        sample_idx = np.array(sample_idx[:N])
        Zs.append(rayleigh_axial_Z(dtheta[sample_idx]))
    Zs = np.array(Zs)
    Z_hat = rayleigh_axial_Z(dtheta)
    Z_lo, Z_hi = np.percentile(Zs, [2.5, 97.5])

    # ---- <|cos Δθ|> + null band
    m = cosabs.mean()
    m_lo, m_hi = make_null_cosmean(N, reps=1200)

    # ---- write CSVs
    angles_csv = args.out_prefix + "angles.csv"
    stats_csv  = args.out_prefix + "stats.csv"
    pd.DataFrame({"dtheta_rad": dtheta, "abs_cos": cosabs, "l_deg": L, "b_deg": B}).to_csv(angles_csv, index=False)
    pd.DataFrame([{"N": N, "Z": Z_hat, "Z_lo": Z_lo, "Z_hi": Z_hi, "cos_mean": m, "null_lo": m_lo, "null_hi": m_hi}]).to_csv(stats_csv, index=False)
    print(f"[WRITE] {angles_csv}")
    print(f"[WRITE] {stats_csv}  (Z={Z_hat:.2f} [{Z_lo:.2f},{Z_hi:.2f}]);  <|cosΔθ|>={m:.3f}  null95%[{m_lo:.3f},{m_hi:.3f}]")

    # ---- plots
    # Left: rose (Δθ in [0,pi/2])
    left_pdf = args.out_prefix + "left_rose.pdf"
    th = dtheta
    fig = plt.figure(figsize=(4.8,3.6))
    ax = plt.subplot(111, projection="polar")
    bins = np.linspace(0.0, np.pi/2, 19)
    h, be = np.histogram(th, bins=bins, density=False)
    centers = 0.5*(be[1:]+be[:-1])
    ax.bar(centers, h, width=np.diff(be), align="center", edgecolor="k", linewidth=0.4)
    ax.set_theta_zero_location("E"); ax.set_theta_direction(-1)
    ax.set_thetamin(0); ax.set_thetamax(90)
    ax.set_title("Δθ (axial) — Rose plot", va="bottom")
    fig.savefig(left_pdf, bbox_inches="tight")
    print(f"[WRITE] {left_pdf}")

    # Right: bar per <|cosΔθ|> con banda null
    right_pdf = args.out_prefix + "right_cos.pdf"
    fig2 = plt.figure(figsize=(2.8,3.2))
    ax2 = fig2.add_axes([0.22,0.18,0.72,0.76])
    ax2.bar([0],[m], width=0.5)
    ax2.vlines([0], [m_lo], [m_hi], lw=3)
    ax2.set_xticks([0]); ax2.set_xticklabels([r"$\langle|\cos\Delta\theta|\rangle$"])
    ax2.set_ylim(0.0,1.0)
    fig2.savefig(right_pdf, bbox_inches="tight")
    print(f"[WRITE] {right_pdf}")

    # Combined + LaTeX snippet
    combined_pdf = args.out_prefix + "combined.pdf"
    fig3 = plt.figure(figsize=(7.2,3.2))
    axL = fig3.add_axes([0.06,0.17,0.56,0.78], projection="polar")
    axR = fig3.add_axes([0.70,0.18,0.28,0.76])
    axL.bar(centers, h, width=np.diff(be), align="center", edgecolor="k", linewidth=0.4)
    axL.set_theta_zero_location("E"); axL.set_theta_direction(-1)
    axL.set_thetamin(0); axL.set_thetamax(90)
    axL.set_title(f"Rayleigh $Z={Z_hat:.2f}$ (95% CI [{Z_lo:.2f},{Z_hi:.2f}])", va="bottom")
    axR.bar([0],[m], width=0.5)
    axR.vlines([0], [m_lo], [m_hi], lw=3)
    axR.set_xticks([0]); axR.set_xticklabels([r"$\langle|\cos\Delta\theta|\rangle$"])
    axR.set_ylim(0.0,1.0)
    fig3.savefig(combined_pdf, bbox_inches="tight")
    print(f"[WRITE] {combined_pdf}")

    # LaTeX snippet (niente triple quotes)
    tex = (
        "%% Fig. 69 auto-generated\n"
        "\\begin{figure}[t]\n"
        "  \\centering\n"
        "  \\begin{minipage}[t]{0.60\\textwidth}\\centering\n"
        f"    \\includegraphics[width=\\linewidth]{{{left_pdf}}}\n"
        "  \\end{minipage}\\hfill\n"
        "  \\begin{minipage}[t]{0.36\\textwidth}\\centering\n"
        f"    \\includegraphics[width=\\linewidth]{{{right_pdf}}}\n"
        "  \\end{minipage}\n"
        f"  \\caption{{Rose plot di $\\Delta\\theta$ con Rayleigh $Z={Z_hat:.2f}$ (95\\% CI [{Z_lo:.2f},{Z_hi:.2f}]); "
        f"a destra: $\\langle|\\cos\\Delta\\theta|\\rangle={m:.3f}$ con banda null (95\\%).}}\n"
        "  \\label{fig:fig69}\n"
        "\\end{figure}\n"
    )
    with open(args.out_prefix+"latex.txt","w",encoding="utf-8") as f:
        f.write(tex)
    print(f"[WRITE] {args.out_prefix}latex.txt")

if __name__ == "__main__":
    main()
