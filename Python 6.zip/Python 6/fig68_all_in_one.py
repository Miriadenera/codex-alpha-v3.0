import argparse, json, numpy as np, pandas as pd, matplotlib.pyplot as plt
from shapely.geometry import shape, Point
from shapely.ops import unary_union
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

def load_union_polys(geo_path):
    with open(geo_path, "r", encoding="utf-8") as f:
        gj = json.load(f)
    feats = gj["features"] if "features" in gj else [gj]
    geoms = []
    for ft in feats:
        try:
            geoms.append(shape(ft["geometry"]))
        except Exception:
            pass
    if not geoms:
        raise RuntimeError("No valid geometries found in basins geojson.")
    return unary_union(geoms)

def nearest_sel_for_points(L, B, sel_df):
    # Trova colonne lon/lat nella selection map
    candL = [c for c in sel_df.columns if c.lower() in ("l_deg_aligned","l_deg","l","lon","longitude")]
    candB = [c for c in sel_df.columns if c.lower() in ("b_deg","b","lat","latitude")]
    if not candL or not candB:
        raise RuntimeError("selection CSV: non trovo colonne l/b.")
    colL, colB = candL[0], candB[0]
    # colonna S
    candS = [c for c in sel_df.columns if c.lower().startswith("s")]
    if not candS:
        raise RuntimeError("selection CSV: non trovo colonna S* (peso).")
    colS = candS[0]
    SL, SB, SS = sel_df[colL].values, sel_df[colB].values, sel_df[colS].values
    # nearest (dataset piccolo -> ok)
    idx = np.argmin((L[:,None]-SL[None,:])**2 + (B[:,None]-SB[None,:])**2, axis=1)
    return SS[idx]

def make_points(basins_geo, dens_csv, col_l, col_b, col_sigma, selection_csv, sample, out_points_csv):
    U = load_union_polys(basins_geo)
    df = pd.read_csv(dens_csv, low_memory=False)
    L = pd.to_numeric(df[col_l], errors="coerce").values
    B = pd.to_numeric(df[col_b], errors="coerce").values
    Sg = pd.to_numeric(df[col_sigma], errors="coerce").values
    keep = np.isfinite(L) & np.isfinite(B) & np.isfinite(Sg)
    L, B, Sg = L[keep], B[keep], Sg[keep]
    if len(L) == 0:
        raise RuntimeError("Catalogo densità vuoto dopo il filtraggio.")
    inside = np.array([U.contains(Point(l,b)) for l,b in zip(L,B)], dtype=bool)
    n_pos, n_neg = inside.sum(), (~inside).sum()
    n = int(min(sample//2, n_pos, n_neg))
    if n < 50:
        raise RuntimeError(f"Troppi pochi esempi bilanciati (pos={n_pos}, neg={n_neg}).")
    rng = np.random.RandomState(7)
    pos_idx = rng.choice(np.where(inside)[0], size=n, replace=False)
    neg_idx = rng.choice(np.where(~inside)[0], size=n, replace=False)
    idx = np.r_[pos_idx, neg_idx]
    Ls, Bs, Sigmas = L[idx], B[idx], Sg[idx]
    ys = np.r_[np.ones(n, dtype=int), np.zeros(n, dtype=int)]

    # Selection S(l,b)
    if selection_csv:
        sel = pd.read_csv(selection_csv, low_memory=False)
        Selw = nearest_sel_for_points(Ls, Bs, sel)
    else:
        Selw = np.ones_like(Ls)

    T = pd.DataFrame({
        "y": ys,
        "abs_b": np.abs(Bs),
        "Sigma_star": Sigmas,
        "Sel": Selw,
        "l": Ls, "b": Bs
    })
    T.to_csv(out_points_csv, index=False)
    return T

def fit_and_plot(T, Bboot, out_pdf, out_csv):
    X = T[["abs_b","Sigma_star","Sel"]].values.astype(float)
    y = T["y"].values.astype(int)
    # standardizza per confrontabilità
    m, s = X.mean(0), X.std(0); s[s==0] = 1.0
    Xs = (X - m) / s
    if len(np.unique(y)) < 2:
        raise RuntimeError("Il campione ha una sola classe (y). Rigenera i punti.")
    lr = LogisticRegression(solver="liblinear")
    lr.fit(Xs, y)
    beta_hat = lr.coef_.ravel()
    auc_hat  = roc_auc_score(y, lr.predict_proba(Xs)[:,1])

    # bootstrap IID sui punti
    betas = np.zeros((Bboot,3)); aucs = np.zeros(Bboot)
    rng = np.random.RandomState(42)
    for b in range(Bboot):
        idx = rng.randint(0, len(y), size=len(y))
        Xb, yb = Xs[idx], y[idx]
        if len(np.unique(yb))<2:
            betas[b,:] = np.nan; aucs[b] = np.nan; continue
        lrb = LogisticRegression(solver="liblinear")
        lrb.fit(Xb,yb)
        betas[b,:] = lrb.coef_.ravel()
        aucs[b] = roc_auc_score(yb, lrb.predict_proba(Xb)[:,1])

    q = lambda v: np.nanpercentile(v, [2.5, 97.5])
    ci_beta = np.vstack([q(betas[:,0]), q(betas[:,1]), q(betas[:,2])])
    ci_auc  = q(aucs)

    out = pd.DataFrame({
        "beta": ["beta_abs_b","beta_Sigma_star","beta_Sel"],
        "hat": beta_hat,
        "ci_lo": ci_beta[:,0],
        "ci_hi": ci_beta[:,1]
    })
    out.to_csv(out_csv, index=False)

    # forest + inset AUC
    fig = plt.figure(figsize=(6.2,3.4))
    ax = fig.add_axes([0.11,0.18,0.58,0.74])
    names = [r"$\beta_1$ (|b|)", r"$\beta_2$ ($\Sigma_\star$)", r"$\beta_3$ ($S$)"]
    ypos  = np.arange(3)[::-1] + 1
    ax.axvline(0, lw=0.8, ls="--", alpha=0.6)
    # asimmetriche: usa differenze verso il punto
    xerr = np.vstack([beta_hat - ci_beta[:,0], ci_beta[:,1] - beta_hat]).T
    ax.errorbar(beta_hat, ypos, xerr=xerr.T, fmt="s", capsize=3)
    ax.set_yticks(ypos); ax.set_yticklabels(names)
    ax.set_xlabel("Logit coefficient")
    ax.set_ylim(0.4, 3.6)

    ax2 = fig.add_axes([0.74,0.28,0.22,0.6])
    ax2.bar([0],[auc_hat], width=0.35)
    ax2.vlines([0], [ci_auc[0]], [ci_auc[1]], lw=2)
    ax2.set_xticks([0]); ax2.set_xticklabels(["AUC"])
    ax2.set_ylim(0.45,1.0)

    fig.savefig(out_pdf, bbox_inches="tight")
    print(f"[WRITE] {out_pdf} ; AUC={auc_hat:.3f}  (95% CI {ci_auc[0]:.3f}–{ci_auc[1]:.3f})")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--basins-geo", required=True)
    ap.add_argument("--density-csv", required=True)
    ap.add_argument("--selection-csv", default=None)
    ap.add_argument("--col-l", default="l_deg_aligned")
    ap.add_argument("--col-b", default="b_deg")
    ap.add_argument("--col-sigma", default="local_density")
    ap.add_argument("--sample", type=int, default=4000)
    ap.add_argument("--B", type=int, default=600)
    ap.add_argument("--out-pdf", default="fig68_forest_auc.pdf")
    ap.add_argument("--out-csv", default="fig68_betas_auc.csv")
    ap.add_argument("--out-points", default="fig68_points.csv")
    args = ap.parse_args()

    T = make_points(args.basins_geo, args.density_csv, args.col_l, args.col_b,
                    args.col_sigma, args.selection_csv, args.sample, args.out_points)
    print(f"[WRITE] {args.out_points} (n={len(T)}, pos={int(T['y'].sum())}, neg={int((1-T['y']).sum())})")
    fit_and_plot(T, args.B, args.out_pdf, args.out_csv)

if __name__ == "__main__":
    main()
