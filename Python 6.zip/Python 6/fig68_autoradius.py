#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse, numpy as np, pandas as pd, matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

def find_cols(df, need_sel=False):
    low = {c.lower(): c for c in df.columns}
    # l,b
    Lcands = [k for k in low if k in ("l_deg_aligned","l_deg","l","lon","longitude")]
    Bcands = [k for k in low if k in ("b_deg","b","lat","latitude")]
    if not Lcands or not Bcands:
        raise RuntimeError("Non trovo colonne l/b nel CSV.")
    colL, colB = low[Lcands[0]], low[Bcands[0]]
    # S(l,b)
    colS = None
    if need_sel:
        Scands = [k for k in low if (k=="s" or k.startswith("s_") or k.startswith("sel") or k=="local_density")]
        if not Scands:
            raise RuntimeError("selection CSV: non trovo colonna S*.")
        colS = low[Scands[0]]
    return colL, colB, colS

def ang_sep_deg(L, B, CL, CB):
    """Distanza angolare appross. (piccoli angoli): sqrt( (Δl cos b)^2 + (Δb)^2 ) in gradi."""
    dL = ((L[:,None] - CL[None,:] + 180.0) % 360.0) - 180.0     # wrap
    cB = np.cos(np.deg2rad(B))[:,None]
    dB = (B[:,None] - CB[None,:])
    return np.sqrt((dL*cB)**2 + dB**2)                          # [Npoints x Ncentroids]

def nearest_to_centroids(L, B, CL, CB):
    """Distanza minima di ogni punto al set dei centroidi (gradi)."""
    dmin = np.full(L.shape, np.inf)
    # chunk leggero lato centroids
    for idx in np.array_split(np.arange(CL.size), max(1, CL.size//1000)):
        d = ang_sep_deg(L, B, CL[idx], CB[idx])
        dmin = np.minimum(dmin, d.min(axis=1))
    return dmin

def build_dataset(centroids_csv, density_csv, selection_csv, col_l, col_b, col_sigma,
                  sample, r0, rmax, target_pos, thin):
    # centroids
    C = pd.read_csv(centroids_csv)
    cLcol, cBcol, _ = find_cols(C, need_sel=False)
    CL = pd.to_numeric(C[cLcol], errors="coerce").dropna().to_numpy()
    CB = pd.to_numeric(C[cBcol], errors="coerce").dropna().to_numpy()
    if CL.size == 0:
        raise RuntimeError("Centroidi non validi nel CSV.")

    # density
    DF = pd.read_csv(density_csv, low_memory=False)
    if col_l not in DF.columns or col_b not in DF.columns:
        col_l, col_b, _ = find_cols(DF, need_sel=False)
    L  = pd.to_numeric(DF[col_l], errors="coerce").to_numpy()
    B  = pd.to_numeric(DF[col_b], errors="coerce").to_numpy()
    Sg = pd.to_numeric(DF[col_sigma], errors="coerce").to_numpy()
    keep = np.isfinite(L) & np.isfinite(B) & np.isfinite(Sg)
    L, B, Sg = L[keep], B[keep], Sg[keep]
    if thin > 1:
        L, B, Sg = L[::thin], B[::thin], Sg[::thin]
    if L.size == 0:
        raise RuntimeError("Catalogo densità vuoto dopo filtraggio.")

    # distanza minima dal set dei centroidi
    dmin = nearest_to_centroids(L, B, CL, CB)

    # cerca un raggio che dia almeno target_pos positivi
    r = float(r0)
    inside = dmin <= r
    while inside.sum() < target_pos and r < rmax:
        r *= 1.5
        inside = dmin <= r

    # fallback: se ancora zero, prendi i k-nearest (garantito)
    if inside.sum() == 0:
        k = max(200, min(target_pos, L.size//200))  # prudente
        thr = np.partition(dmin, k-1)[k-1]
        inside = dmin <= thr
        r = float(thr)

    n_pos, n_neg = int(inside.sum()), int((~inside).sum())
    if n_pos == 0 or n_neg == 0:
        raise RuntimeError(f"Nessun bilanciamento possibile (pos={n_pos}, neg={n_neg}).")

    # campionamento bilanciato
    n_each = int(min(sample//2, n_pos, n_neg))
    n_each = max(n_each, 50)
    rng = np.random.RandomState(7)
    pos_idx = rng.choice(np.where(inside)[0], size=n_each, replace=False)
    neg_idx = rng.choice(np.where(~inside)[0], size=n_each, replace=False)
    idx = np.r_[pos_idx, neg_idx]
    Ls, Bs, Sigmas = L[idx], B[idx], Sg[idx]
    ys = np.r_[np.ones(n_each, dtype=int), np.zeros(n_each, dtype=int)]

    # selection S(l,b)
    if selection_csv:
        SEL = pd.read_csv(selection_csv, low_memory=False)
        selL, selB, selS = find_cols(SEL, need_sel=True)
        SL = pd.to_numeric(SEL[selL], errors="coerce").to_numpy()
        SB = pd.to_numeric(SEL[selB], errors="coerce").to_numpy()
        SS = pd.to_numeric(SEL[selS], errors="coerce").to_numpy()
        jj = np.argmin((Ls[:,None]-SL[None,:])**2 + (Bs[:,None]-SB[None,:])**2, axis=1)
        Sw = SS[jj]
    else:
        Sw = np.ones_like(Ls)

    T = pd.DataFrame({"y": ys, "abs_b": np.abs(Bs), "Sigma_star": Sigmas, "Sel": Sw,
                      "l": Ls, "b": Bs})
    meta = dict(r_deg=float(r), n_pos=int(ys.sum()), n_neg=int((1-ys).sum()))
    return T, meta

def fit_and_plot(T, Bboot, out_pdf, out_csv):
    X = T[["abs_b","Sigma_star","Sel"]].to_numpy(float)
    y = T["y"].to_numpy(int)
    m, s = X.mean(0), X.std(0); s[s==0] = 1.0
    Xs = (X - m) / s

    lr = LogisticRegression(solver="liblinear")
    lr.fit(Xs, y)
    beta_hat = lr.coef_.ravel()
    auc_hat  = roc_auc_score(y, lr.predict_proba(Xs)[:,1])

    rng = np.random.RandomState(42)
    betas = np.full((Bboot,3), np.nan); aucs = np.full(Bboot, np.nan)
    n = len(y)
    for b in range(Bboot):
        ii = rng.randint(0, n, size=n)
        Xb, yb = Xs[ii], y[ii]
        if len(np.unique(yb)) < 2: continue
        lrb = LogisticRegression(solver="liblinear")
        lrb.fit(Xb, yb)
        betas[b,:] = lrb.coef_.ravel()
        aucs[b]    = roc_auc_score(yb, lrb.predict_proba(Xb)[:,1])

    q = lambda v: np.nanpercentile(v, [2.5, 97.5])
    ci_beta = np.vstack([q(betas[:,0]), q(betas[:,1]), q(betas[:,2])])
    ci_auc  = q(aucs)

    pd.DataFrame({
        "beta":["beta_abs_b","beta_Sigma_star","beta_Sel"],
        "hat":beta_hat, "ci_lo":ci_beta[:,0], "ci_hi":ci_beta[:,1]
    }).to_csv(out_csv, index=False)

    fig = plt.figure(figsize=(6.2,3.4))
    ax = fig.add_axes([0.11,0.18,0.58,0.74])
    names = [r"$\beta_1$ (|b|)", r"$\beta_2$ ($\Sigma_\star$)", r"$\beta_3$ ($S$)"]
    ypos  = np.arange(3)[::-1] + 1
    ax.axvline(0, lw=0.8, ls="--", alpha=0.6)
    xerr = np.vstack([beta_hat - ci_beta[:,0], ci_beta[:,1] - beta_hat]).T
    ax.errorbar(beta_hat, ypos, xerr=xerr.T, fmt="s", capsize=3)
    ax.set_yticks(ypos); ax.set_yticklabels(names)
    ax.set_xlabel("Logit coefficient"); ax.set_ylim(0.4,3.6)

    ax2 = fig.add_axes([0.74,0.28,0.22,0.6])
    ax2.bar([0],[auc_hat], width=0.35)
    ax2.vlines([0],[ci_auc[0]],[ci_auc[1]], lw=2)
    ax2.set_xticks([0]); ax2.set_xticklabels(["AUC"])
    ax2.set_ylim(0.45,1.00)

    fig.savefig(out_pdf, bbox_inches="tight")
    print(f"[WRITE] {out_pdf}  AUC={auc_hat:.3f} (95% CI {ci_auc[0]:.3f}–{ci_auc[1]:.3f})")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--centroids", required=True)
    ap.add_argument("--density",   required=True)
    ap.add_argument("--selection", default=None)
    ap.add_argument("--col-l",     default="l_deg_aligned")
    ap.add_argument("--col-b",     default="b_deg")
    ap.add_argument("--col-sigma", default="local_density")
    ap.add_argument("--sample", type=int, default=4000)
    ap.add_argument("--target-pos", type=int, default=1200)
    ap.add_argument("--r0",   type=float, default=0.3)
    ap.add_argument("--rmax", type=float, default=3.0)
    ap.add_argument("--thin", type=int,   default=1, help="tieni 1 punto ogni 'thin'")
    ap.add_argument("--B",    type=int,   default=600)
    ap.add_argument("--out-pdf", default="fig68_forest_auc.pdf")
    ap.add_argument("--out-csv", default="fig68_betas_auc.csv")
    ap.add_argument("--out-points", default="fig68_points.csv")
    args = ap.parse_args()

    T, meta = build_dataset(args.centroids, args.density, args.selection,
                            args.col_l, args.col_b, args.col_sigma,
                            args.sample, args.r0, args.rmax, args.target_pos, args.thin)
    T.to_csv(args.out_points, index=False)
    print(f"[WRITE] {args.out_points}  n={len(T)}  pos={meta['n_pos']}  neg={meta['n_neg']}  r_used={meta['r_deg']:.3f} deg")
    fit_and_plot(T, args.B, args.out_pdf, args.out_csv)

if __name__ == "__main__":
    main()
