#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
quick_ranges.py
---------------
Print min/max/median for l,b to quickly diagnose wrap mismatches.

Examples:
  python quick_ranges.py --cent basins_min_centroids.csv
  python quick_ranges.py --arms arms_ridge.csv
  python quick_ranges.py --gmc gmc_catalog.csv
  python quick_ranges.py --csv gaia_codex_filtered_density_lb.csv --col-l l_deg --col-b b_deg
"""
import argparse
import numpy as np
import pandas as pd

def stats(x):
    x = np.asarray(x, float)
    return dict(min=float(np.nanmin(x)),
                max=float(np.nanmax(x)),
                median=float(np.nanmedian(x)))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cent", help="basins_min_centroids.csv (needs l_deg,b_deg)")
    ap.add_argument("--arms", help="arms_ridge.csv (arm_id,l_deg,b_deg)")
    ap.add_argument("--gmc", help="gmc_catalog.csv (l_deg,b_deg,r_deg)")
    ap.add_argument("--csv", help="generic CSV")
    ap.add_argument("--col-l", default="l_deg")
    ap.add_argument("--col-b", default="b_deg")
    args = ap.parse_args()

    if args.cent:
        df = pd.read_csv(args.cent)
        print("Centroids l:", stats(df["l_deg"]), " b:", stats(df["b_deg"]), " n=", len(df))
    if args.arms:
        df = pd.read_csv(args.arms)
        print("Arms      l:", stats(df["l_deg"]), " b:", stats(df["b_deg"]), " n=", len(df))
    if args.gmc:
        df = pd.read_csv(args.gmc)
        print("GMC       l:", stats(df["l_deg"]), " b:", stats(df["b_deg"]), " n=", len(df))
    if args.csv:
        df = pd.read_csv(args.csv)
        print("CSV       l:", stats(df[args.col_l]), " b:", stats(df[args.col_b]), " n=", len(df))

if __name__ == "__main__":
    main()
