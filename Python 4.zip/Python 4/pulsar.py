import psrqpy
import pandas as pd

# Query al catalogo ATNF: richiede i parametri principali
query = psrqpy.QueryATNF(params=["PSRJ", "RAJD", "DECJ", "F0", "F1"])
catalog = query.table

# Filtra solo pulsar millisecondo (frequenza maggiore di 100 Hz)
msps = catalog[(catalog["F0"] > 100) & (catalog["F1"] != 0)]

# Prendi le prime 50
msps50 = msps[:50]

# Converti in DataFrame e seleziona solo le colonne necessarie
df = msps50.to_pandas()[["PSRJ", "RAJD", "DECJ", "F0", "F1"]]

# Rimuove eventuali righe con valori nulli
df = df.dropna()

# Salva su CSV
df.to_csv("pulsars_50_real.csv", index=False)

print("✅ File CSV generato con successo:")
print(df.head())
