import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import hilbert, butter, filtfilt

# Parametri della rete
N = 256                 # Numero di nodi neuronali
T = 10                  # Tempo di simulazione in secondi
fs = 1000               # Frequenza di campionamento in Hz
dt = 1 / fs             # Passo temporale
t = np.arange(0, T, dt) # Vettore temporale
L = len(t)

# Frequenze delle bande theta e gamma
f_theta = 6.5
f_gamma = 40

# Topologia della rete (connettività casuale sparsa)
np.random.seed(42)
adj_matrix = (np.random.rand(N, N) < 0.05).astype(float)
np.fill_diagonal(adj_matrix, 0)

# Generazione dei segnali theta e gamma
theta_phase = np.random.rand(N, 1) * 2 * np.pi
gamma_phase = np.random.rand(N, 1) * 2 * np.pi

theta = np.sin(2 * np.pi * f_theta * t + theta_phase)
gamma = np.sin(2 * np.pi * f_gamma * t + gamma_phase)

# Accoppiamento: nodo j influenza i
theta_coupled = np.zeros((N, L))
gamma_coupled = np.zeros((N, L))

for i in range(N):
    for j in range(N):
        if adj_matrix[i, j]:
            theta_coupled[i] += 0.05 * np.sin(2 * np.pi * f_theta * t + theta_phase[j])
            gamma_coupled[i] += 0.05 * np.sin(2 * np.pi * f_gamma * t + gamma_phase[j])

# Aggiunta del segnale intrinseco
theta_signal = theta + theta_coupled
gamma_signal = gamma + gamma_coupled

# Somma totale per simulare nodo N_bio
total_signal = theta_signal + gamma_signal

# Funzione bandpass
def bandpass(data, low, high, fs, order=3):
    from scipy.signal import butter, filtfilt
    nyq = 0.5 * fs
    b, a = butter(order, [low / nyq, high / nyq], btype='band')
    return filtfilt(b, a, data, axis=-1)

# Estrazione fasi con Hilbert
theta_band = bandpass(total_signal, 4, 8, fs)
gamma_band = bandpass(total_signal, 35, 45, fs)

theta_phase = np.angle(hilbert(theta_band))
gamma_phase = np.angle(hilbert(gamma_band))

# Calcolo PLV globale θ–γ
plv_matrix = np.exp(1j * (gamma_phase - theta_phase))
global_plv = np.abs(np.mean(plv_matrix))

print(f"🌐 Global Phase Locking Value (θ–γ): {global_plv:.4f}")

# Spettro globale
from scipy.signal import welch
f, Pxx = welch(np.mean(total_signal, axis=0), fs=fs, nperseg=2048)
plt.figure(figsize=(12,5))
plt.semilogy(f, Pxx, label="Power Spectrum")
plt.axvline(40, color='r', linestyle='--', label='Gamma (40 Hz)')
plt.axvline(6.5, color='b', linestyle='--', label='Theta (6.5 Hz)')
plt.title("Global Neural Spectrum – Network of 256 Nodes")
plt.xlabel("Frequency [Hz]")
plt.ylabel("Power")
plt.legend()
plt.grid()
plt.tight_layout()
plt.show()
