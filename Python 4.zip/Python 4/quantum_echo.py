import matplotlib
matplotlib.use('Agg') # Fondamentale per il salvataggio delle immagini
import matplotlib.pyplot as plt # Importato qui per definire 'plt' prima dell'uso

# Impostazioni Matplotlib per evitare errori di codifica e migliorare la resa
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['DejaVu Sans'] # Un font che supporta più caratteri
plt.rcParams['savefig.facecolor'] = 'white' # Sfondo bianco per le immagini salvate
plt.rcParams['savefig.bbox'] = 'tight' # Per evitare bordi tagliati (opzionale, a volte può causare problemi)

# Importa le classi e le funzioni necessarie da Qiskit
from qiskit import QuantumCircuit
from qiskit.compiler import transpile
from qiskit_aer import Aer # Correzione per l'importazione di Aer
from qiskit.visualization import plot_histogram
import os # Per interagire con il sistema operativo, come creare directory

# --- Configurazione dei Percorsi di Output ---
output_dir = r"C:\Users\cadel\OneDrive\Desktop"
os.makedirs(output_dir, exist_ok=True)

circuit_img = os.path.join(output_dir, "quantum_echo_circuit.png")
histogram_img = os.path.join(output_dir, "quantum_echo_histogram.png")
counts_txt = os.path.join(output_dir, "quantum_echo_counts.txt")

# --- Parametri del Circuito Quantistico ---
n_qubits = 5
# Aumentiamo theta per avere una maggiore probabilità di cambiare lo stato dei qubit
theta = 0.8 # <<< AUMENTATO THETA PER VEDERE PIÙ CAMBIAMENTI NEGLI STATI

# --- Costruzione del Circuito Quantistico ---
qc = QuantumCircuit(n_qubits + 1) # n_qubits di dati + 1 ancilla (ultimo qubit)

# Metti il qubit ancilla (l'ultimo qubit) in superposizione (|0>+|1>)/sqrt(2)
qc.h(n_qubits) 

# Applica le porte CRY controllate dall'ancilla (n_qubits) sui qubit di dati (0 a n_qubits-1)
for i in range(n_qubits):
    qc.cry(theta, n_qubits, i)

qc.barrier() # Barriera per chiarezza

# MISURAZIONE: Misura tutti i qubit
qc.measure_all() 

# --- Salvataggio dell'Immagine del Circuito ---
try:
    fig = qc.draw(output='mpl')
    # plt.tight_layout() # Rimuovo questo perché a volte può causare problemi con 'mpl'
    plt.savefig(circuit_img)
    plt.close(fig)
    print(f"✅ Circuito quantistico salvato in: {circuit_img}")
except Exception as e:
    print(f"❌ Errore durante il salvataggio del circuito: {e}")

# --- Simulazione del Circuito Quantistico ---
backend = Aer.get_backend('qasm_simulator')
compiled_circuit = transpile(qc, backend)
job = backend.run(compiled_circuit, shots=100000)
result = job.result()
counts = result.get_counts()

# --- Debug: Stampa i conteggi raw per capire cosa sta succedendo ---
print("\n--- Conteggi Raw della Simulazione ---")
print(counts)

# --- Analisi dei Risultati della Simulazione ---
coherent_counts = {0: 0, 1: 0}
total_counts = {0: 0, 1: 0}

for bitstring, freq in counts.items():
    # L'ultimo qubit del circuito è l'ancilla (Q5). In Qiskit, la stringa di output
    # delle misurazioni è nell'ordine inverso dei qubit nel circuito:
    # AncillaQ4Q3Q2Q1Q0. Quindi, l'ancilla è il carattere all'indice 0.
    ancilla = int(bitstring[0]) 
    data_qubits = bitstring[1:] # I qubit di dati sono i caratteri dall'indice 1 in poi

    # Determina se lo stato dei qubit di dati è "coerente" (almeno 3 qubit di dati sono '1')
    is_coherent = int(data_qubits.count('1') >= 3)
    
    total_counts[ancilla] += freq
    if is_coherent:
        coherent_counts[ancilla] += freq

# --- Debug: Stampa i conteggi analizzati ---
print("\n--- Conteggi Analizzati ---")
print(f"Coherent Counts: {coherent_counts}")
print(f"Total Counts: {total_counts}")

# Calcolo delle probabilità condizionate
p_c_given_1 = coherent_counts[1] / total_counts[1] if total_counts[1] > 0 else 0
p_c_given_0 = coherent_counts[0] / total_counts[0] if total_counts[0] > 0 else 0
rho_retro = (p_c_given_1 - p_c_given_0) / (p_c_given_1 + p_c_given_0 + 1e-8)

# --- Stampa dei Risultati sulla Console ---
print("\n--- Risultati della Simulazione ---")
print(f"P(Coerenza | Ancilla=1): {p_c_given_1:.4f}")
print(f"P(Coerenza | Ancilla=0): {p_c_given_0:.4f}")
print(f"Correlazione di coerenza retrocausale (ρ_retro): {rho_retro:.4f}")

# --- Salvataggio dei Risultati in un File di Testo ---
try:
    with open(counts_txt, "w", encoding='utf-8') as f: # <<< CODIFICA UTF-8 AGGIUNTA QUI
        f.write(f"Conteggi: {counts}\n")
        f.write(f"P(Coerenza | Ancilla=1): {p_c_given_1:.4f}\n")
        f.write(f"P(Coerenza | Ancilla=0): {p_c_given_0:.4f}\n")
        f.write(f"Correlazione di coerenza retrocausale (ρ_retro): {rho_retro:.4f}\n")
    print(f"✅ Dati dei conteggi e analisi salvati in: {counts_txt}")
except Exception as e:
    print(f"❌ Errore durante il salvataggio del file dei conteggi: {e}")

# --- Salvataggio dell'Istogramma dei Risultati ---
try:
    plot_histogram(counts)
    plt.savefig(histogram_img)
    plt.close()
    print(f"✅ Istogramma salvato in: {histogram_img}")
except Exception as e:
    print(f"❌ Errore durante il salvataggio dell'istogramma: {e}")

print("\nScript completato. Controlla la tua Scrivania per i file di output! 🎉")