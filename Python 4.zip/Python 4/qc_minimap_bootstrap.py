#!/usr/bin/env python3
# -*- coding: ascii -*-
"""
QC mini-map (TikZ/pgfplots) + bootstrap stats (one shot).

Inputs
------
--nodes   : topo_nodes_patch.csv  (must have: ID, l_mean, b_mean; plus metrics)
--labels  : topo_label_grid_patch.npz  (labels, l_edges, b_edges)

Columns expected in --nodes
---------------------------
persistence     -> pers. on G   (used for pG)
persistence_K   -> pers. on K   (used for pK; optional, skipped if missing)

Outputs (with --out-prefix=qc by default)
-----------------------------------------
qc_centroids_pG.csv
qc_centroids_pG.tex           (TikZ snippet, \\input{}-ready)
qc_bootstrap_pG.csv           (median(p_G) 95% CI)

qc_centroids_pK.csv           (only if persistence_K exists)
qc_centroids_pK.tex
qc_bootstrap_pK.csv

qc_bootstrap_node_density.csv (nodes/deg^2 95% CI)
qc_bootstrap_summary.csv      (rows: median p_G, [median p_K], node density)
qc_bootstrap_summary_table.tex (pgfplotstable table, \\input{}-ready)

Notes
-----
- ASCII only. No external plotting deps needed for TeX snippets.
- For exact Poisson CI uses scipy (optional). Falls back to normal approx.
"""

import argparse, os
import numpy as np
import pandas as pd

# optional SciPy for exact Poisson CI
try:
    from scipy.stats import chi2
    _HAS_SCIPY = True
except Exception:
    _HAS_SCIPY = False

# ----------------------- helpers -----------------------

def pick_col(df, candidates):
    for c in candidates:
        if c and c in df.columns:
            return c
    return None

def write_text(path, s):
    with open(path, "w", encoding="utf-8") as f:
        f.write(s)

def gen_tikz_snippet(csv_name, meta_col, colorbar_title,
                     width="0.70\\textwidth", height="0.42\\textwidth",
                     mark_size=1.6, colormap="viridis", label="fig:centroidsMetric",
                     caption=None):
    if caption is None:
        caption = ("QC mini-map: node centroids color-coded by %s." % colorbar_title)
    return r"""
%% Auto-generated: QC mini-map from %s
\pgfplotstableread[col sep=comma]{%s}\centroidsA
\begin{figure}[htbp]
  \centering
  \begin{tikzpicture}
    \begin{axis}[
      width=%s, height=%s,
      xlabel={$l$ [deg]}, ylabel={$b$ [deg]},
      grid=both, grid style={black!10},
      enlargelimits=false,
      colormap/%s,
      colorbar, colorbar style={title={%s}},
      point meta=explicit,
    ]
      \addplot[
        only marks, mark=*, mark size=%spt,
        scatter, scatter src=explicit,
      ]
      table[x=l_mean, y=b_mean, meta=%s]{\centroidsA};
    \end{axis}
  \end{tikzpicture}
  \caption{%s}
  \label{%s}
\end{figure}
"""[1:] % (csv_name, csv_name, width, height, colormap, colorbar_title,
           mark_size, meta_col, caption, label)

def bootstrap_ci_median(x, B=10000, seed=42):
    rng = np.random.default_rng(seed)
    x = np.asarray(x, float)
    x = x[~np.isnan(x)]
    if x.size == 0:
        return np.nan, np.nan, np.nan
    med = float(np.median(x))
    boots = np.array([np.median(rng.choice(x, size=x.size, replace=True)) for _ in range(B)], float)
    lo, hi = np.quantile(boots, [0.025, 0.975])
    return med, float(lo), float(hi)

def poisson_rate_ci(N, Adeg2, alpha=0.05):
    lam_hat = (N / Adeg2) if Adeg2 > 0 else 0.0
    if _HAS_SCIPY:
        if N > 0:
            loN = 0.5 * chi2.ppf(alpha/2.0, 2*N)
        else:
            loN = 0.0
        hiN = 0.5 * chi2.ppf(1.0 - alpha/2.0, 2*(N+1))
        return lam_hat, loN/Adeg2, hiN/Adeg2
    # normal approx fallback
    se = (np.sqrt(N) / Adeg2) if Adeg2 > 0 else 0.0
    lo, hi = lam_hat - 1.96*se, lam_hat + 1.96*se
    return lam_hat, max(0.0, lo), max(0.0, hi)

def area_from_grid(npz_path):
    z = np.load(npz_path)
    labels  = z["labels"]
    l_edges = z["l_edges"]
    b_edges = z["b_edges"]
    dl = np.diff(l_edges)      # deg
    db = np.diff(b_edges)      # deg
    # build b-centers for cos(b) correction
    _, bgrid = np.meshgrid(l_edges[:-1], b_edges[:-1], indexing="xy")
    bcent = bgrid + db[:, None] / 2.0
    cell_area = dl[None, :] * db[:, None] * np.cos(np.deg2rad(bcent))  # deg^2
    Adeg2 = float(cell_area[labels > 0].sum())
    return Adeg2

# ----------------------- main -----------------------

def parse_args():
    p = argparse.ArgumentParser(description="QC mini-map (TikZ) + bootstrap for persistence on G and K.")
    p.add_argument("--nodes",  required=True, help="topo_nodes_patch.csv")
    p.add_argument("--labels", required=True, help="topo_label_grid_patch.npz")
    p.add_argument("--out-prefix", default="qc", help="prefix for all outputs")

    # look/feel
    p.add_argument("--tikz-width",  default="0.70\\textwidth")
    p.add_argument("--tikz-height", default="0.42\\textwidth")
    p.add_argument("--mark-size",   type=float, default=1.6)
    p.add_argument("--colormap",    default="viridis")

    # bootstrap controls (alias supported)
    p.add_argument("--nboot", dest="B", type=int, default=10000, help="bootstrap replicates")
    p.add_argument("--B", dest="B", type=int, help=argparse.SUPPRESS)
    p.add_argument("--seed", type=int, default=42, help="bootstrap seed")
    return p.parse_args()

def main():
    a = parse_args()

    # load nodes
    nodes = pd.read_csv(a.nodes)
    need = {"ID", "l_mean", "b_mean"}
    if not need.issubset(nodes.columns):
        raise SystemExit("ERROR: nodes CSV must contain columns: ID, l_mean, b_mean")

    # detect metric columns
    pG_col = pick_col(nodes, ["persistence", "persistence_G", "pers_G", "G_persistence", "pG"])
    pK_col = pick_col(nodes, ["persistence_K", "pers_K", "K_persistence", "pK"])

    if pG_col is None:
        raise SystemExit("ERROR: could not find persistence on G (expected one of: persistence, persistence_G, pers_G, G_persistence, pG).")

    # ---------- pG ----------
    out_pg_csv = f"{a.out_prefix}_centroids_pG.csv"
    df_pg = nodes[["ID", "l_mean", "b_mean", pG_col]].rename(columns={pG_col: "pG"}).copy()
    df_pg.to_csv(out_pg_csv, index=False)
    print("Saved:", out_pg_csv)

    caption_pg = "QC mini-map: node centroids color-coded by topological persistence on $p_{\\mathrm G}$."
    tex_pg = gen_tikz_snippet(
        csv_name=out_pg_csv, meta_col="pG", colorbar_title="$p_{\\mathrm G}$",
        width=a.tikz_width, height=a.tikz_height, mark_size=a.mark_size,
        colormap=a.colormap, label="fig:centroidsPersistenceG", caption=caption_pg
    )
    out_pg_tex = f"{a.out_prefix}_centroids_pG.tex"
    write_text(out_pg_tex, tex_pg)
    print("Saved:", out_pg_tex)

    pg_vals = pd.to_numeric(df_pg["pG"], errors="coerce").to_numpy()
    medG, loG, hiG = bootstrap_ci_median(pg_vals, B=a.B, seed=a.seed)
    boot_pG_csv = f"{a.out_prefix}_bootstrap_pG.csv"
    pd.DataFrame([{"stat": "median(p_G)", "value": medG, "ci_low": loG, "ci_high": hiG}]).to_csv(boot_pG_csv, index=False)
    print("Saved:", boot_pG_csv)

    # ---------- pK (optional) ----------
    have_pK = pK_col is not None
    if have_pK:
        out_pk_csv = f"{a.out_prefix}_centroids_pK.csv"
        df_pk = nodes[["ID", "l_mean", "b_mean", pK_col]].rename(columns={pK_col: "pK"}).copy()
        df_pk.to_csv(out_pk_csv, index=False)
        print("Saved:", out_pk_csv)

        caption_pk = "QC mini-map: node centroids color-coded by topological persistence on $p_{\\mathrm K}$."
        tex_pk = gen_tikz_snippet(
            csv_name=out_pk_csv, meta_col="pK", colorbar_title="$p_{\\mathrm K}$",
            width=a.tikz_width, height=a.tikz_height, mark_size=a.mark_size,
            colormap=a.colormap, label="fig:centroidsPersistenceK", caption=caption_pk
        )
        out_pk_tex = f"{a.out_prefix}_centroids_pK.tex"
        write_text(out_pk_tex, tex_pk)
        print("Saved:", out_pk_tex)

        pk_vals = pd.to_numeric(df_pk["pK"], errors="coerce").to_numpy()
        medK, loK, hiK = bootstrap_ci_median(pk_vals, B=a.B, seed=a.seed)
        boot_pK_csv = f"{a.out_prefix}_bootstrap_pK.csv"
        pd.DataFrame([{"stat": "median(p_K)", "value": medK, "ci_low": loK, "ci_high": hiK}]).to_csv(boot_pK_csv, index=False)
        print("Saved:", boot_pK_csv)
    else:
        medK = loK = hiK = np.nan
        print("Note: column for persistence on K not found; skipping pK products.")

    # ---------- node density ----------
    Adeg2 = area_from_grid(a.labels)
    N = int(nodes.shape[0])
    lam, lam_lo, lam_hi = poisson_rate_ci(N, Adeg2, alpha=0.05)

    den_csv = f"{a.out_prefix}_bootstrap_node_density.csv"
    pd.DataFrame([{
        "stat": "node_density (per deg^2)",
        "value": lam, "ci_low": lam_lo, "ci_high": lam_hi,
        "N": N, "area_deg2": Adeg2
    }]).to_csv(den_csv, index=False)
    print("Saved:", den_csv)

    # ---------- combined summary + LaTeX table ----------
    rows = [{"metric": "median($p_{\\mathrm G}$)", "value": medG, "ci_low": loG, "ci_high": hiG}]
    if have_pK:
        rows.append({"metric": "median($p_{\\mathrm K}$)", "value": medK, "ci_low": loK, "ci_high": hiK})
    rows.append({"metric": "nodes/deg$^2$", "value": lam, "ci_low": lam_lo, "ci_high": lam_hi})

    summary_csv = f"{a.out_prefix}_bootstrap_summary.csv"
    pd.DataFrame(rows).to_csv(summary_csv, index=False)
    print("Saved:", summary_csv)

    tex_tbl = r"""
%% Auto-generated: bootstrap summary table
\pgfplotstableread[col sep=comma]{%s}\bootsum
\begin{table}[htbp]
  \centering
  \caption{Bootstrap summary: median $p_{\mathrm G}$%s and node density (95\%% CI).}
  \pgfplotstabletypeset[
    col sep=comma,
    columns={metric,value,ci_low,ci_high},
    columns/metric/.style={string type, column name={Metric}},
    columns/value/.style={column name={Value}, fixed, precision=3},
    columns/ci_low/.style={column name={CI$_{\rm low}$}, fixed, precision=3},
    columns/ci_high/.style={column name={CI$_{\rm high}$}, fixed, precision=3},
    every head row/.style={before row=\toprule, after row=\midrule},
    every last row/.style={after row=\bottomrule}
  ]{\bootsum}
  \label{tab:BootstrapSummary}
\end{table}
"""[1:] % (summary_csv, (", $p_{\\mathrm K}$" if have_pK else ""))
    summary_tex = f"{a.out_prefix}_bootstrap_summary_table.tex"
    write_text(summary_tex, tex_tbl)
    print("Saved:", summary_tex)

    print("\nDone.")

if __name__ == "__main__":
    main()
