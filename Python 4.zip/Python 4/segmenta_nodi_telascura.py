import os
import numpy as np
import pandas as pd
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import NearestNeighbors
from astropy.coordinates import SkyCoord
import astropy.units as u
import matplotlib.pyplot as plt

# =============== PARAMETRI PRINCIPALI ===============
TARGET_MIN_NODES   = 10       # vogliamo almeno 10 nodi "validi"
MIN_SIZE_PRIMARY   = 6        # soglia membri/cluster "pulito"
MIN_SIZE_FALLBACK  = 5        # fallback automatico
ALPHA_K            = 2.5      # peso asse ∇K (2.0–3.0 consigliato)

# Tuning veloce
TUNING_SAMPLE_MAX  = 20000
EPS_MULTIPLIERS    = [0.95, 1.00, 1.05, 1.15]
MIN_SAMPLES_CAND   = [6, 7, 8, 5]  # includo 5 come recupero
FAST_PREFILTER     = True
PREFILTER_THRESHOLD_ROWS = 300_000
GRADK_KEEP_TOP_Q   = 0.70     # su dataset enormi: tieni top 30% per |∇K|

# Refine ricorsivo del cluster più grande
AUTO_REFINE        = True
MAX_SPLITS         = 3
EPS_SHRINK         = 0.75     # riduci eps localmente (0.6–0.8)
MIN_SAMPLES_DEC    = 1        # min_samples locale = mins_star - 1 (min 5)

GRADK_PREFERRED    = ['gradK_proxy', 'gradK', 'gradK_estimated']
GRADK_LABEL        = r'$\nabla \mathcal{K}$'

file_candidates = [
    "gaia_codex_with_kinematics.csv",
    "gaia_codex_filtered_density.csv",
    "gaia_extracted_codex.csv"
]

# ===================== UTILITY =======================
def summarize(df_base, labels):
    tmp = df_base.copy()
    tmp['cluster'] = labels
    tmp = tmp[tmp['cluster'] != -1]
    if tmp.empty:
        return pd.DataFrame(), 0
    summ = tmp.groupby('cluster').agg(
        l_mean=('l','mean'),
        b_mean=('b','mean'),
        mean_gradK=('gradK','mean'),
        num_members=('gradK','count')
    ).reset_index()
    return summ, len(summ)

def count_with_min_size(summary, kmin):
    if summary.empty: return 0
    return int((summary['num_members'] >= kmin).sum())

def score(summary, kmin, target=TARGET_MIN_NODES):
    n_ok = count_with_min_size(summary, kmin)
    mean_members_ok = summary.loc[summary['num_members'] >= kmin, 'num_members'].mean() if n_ok>0 else 0.0
    flag = 1 if n_ok >= target else 0
    return (flag, n_ok, mean_members_ok)

# ================== 1) FILE SORGENTE =================
selected_file = None
for path in file_candidates:
    if os.path.exists(path):
        df_test = pd.read_csv(path, nrows=5)
        if {'ra','dec'}.issubset(df_test.columns):
            selected_file = path
            break
if not selected_file:
    raise FileNotFoundError("Nessun file valido trovato.")
print(f"📁 File selezionato: {selected_file}")

# ====== 2) CARICAMENTO + CONVERSIONE COORDINATE =====
df = pd.read_csv(selected_file)
coords = SkyCoord(ra=df['ra'].values * u.degree, dec=df['dec'].values * u.degree, frame='icrs')
df['l'] = coords.galactic.l.degree
df['b'] = coords.galactic.b.degree

# ===================== 3) COLONNA ∇K =================
gradK_col = None
for c in GRADK_PREFERRED:
    if c in df.columns:
        gradK_col = c; break
if not gradK_col:
    for c in df.columns:
        if 'gradk' in c.lower():
            gradK_col = c; break
if not gradK_col:
    raise ValueError("Nessuna colonna gradK trovata.")
print(f"🧠 Colonna ∇𝒦 utilizzata: {gradK_col}")

# ================== 4) DATASET DI BASE =================
df_base = df[['l','b',gradK_col]].dropna().rename(columns={gradK_col:'gradK'})

# Prefiltro opzionale per dataset enormi
if FAST_PREFILTER and len(df_base) > PREFILTER_THRESHOLD_ROWS:
    q = df_base['gradK'].abs().quantile(GRADK_KEEP_TOP_Q)
    before = len(df_base)
    df_base = df_base[df_base['gradK'].abs() >= q].copy()
    after = len(df_base)
    print(f"⚡ Prefiltro |∇𝒦|: {before} → {after} (top {int((1-GRADK_KEEP_TOP_Q)*100)}%)")

# ================= 5) ISTOGRAMMA ∇K (rapido) =========
plt.figure()
plt.hist(df_base['gradK'], bins=100)
plt.title("Distribuzione " + GRADK_LABEL); plt.xlabel(GRADK_LABEL); plt.ylabel("Frequenza")
plt.grid(True, alpha=0.3); plt.tight_layout()
plt.savefig("distribuzione_gradK.png")

# ===================== 6) SCALING =====================
# Peso su ∇K per aumentare la sensibilità alla coerenza
X_raw = np.hstack([
    df_base[['l','b']].values,
    (df_base[['gradK']].values * ALPHA_K)
])
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_raw)

# ============ 7) STIMA EPS SU SUBSET (K-DIST) =========
n = len(df_base)
sample_n = min(TUNING_SAMPLE_MAX, n)
idx = np.random.choice(n, size=sample_n, replace=False) if n > sample_n else np.arange(n)
X_s = X_scaled[idx]

k = 5
nbrs = NearestNeighbors(n_neighbors=k, algorithm='kd_tree', leaf_size=40).fit(X_s)
dists, _ = nbrs.kneighbors(X_s)
eps0 = np.percentile(dists[:, -1], 95)
print(f"🔎 eps stimato (95° k-dist, k={k}): {eps0:.3f}")

# ====== 8) TUNING RAPIDO (massimizza nodi puliti) =====
best = None  # (score_tuple, eps, ms, labels, summary)

for em in EPS_MULTIPLIERS:
    eps_try = max(0.05, eps0 * em)
    for ms in MIN_SAMPLES_CAND:
        # gate su subset per non sprecare run full
        db_s = DBSCAN(eps=eps_try, min_samples=ms, algorithm='kd_tree', leaf_size=40).fit(X_s)
        summ_s, _ = summarize(df_base.iloc[idx], db_s.labels_)
        sc_s = score(summ_s, MIN_SIZE_PRIMARY)
        if sc_s[1] >= 6 or sc_s[0] == 1:
            db = DBSCAN(eps=eps_try, min_samples=ms, algorithm='kd_tree', leaf_size=40).fit(X_scaled)
            summ, _ = summarize(df_base, db.labels_)
            sc_full = score(summ, MIN_SIZE_PRIMARY)
            if (best is None) or (sc_full > best[0]):
                best = (sc_full, eps_try, ms, db.labels_, summ)
            if sc_full[0] == 1:
                break
    if best and best[0][0] == 1:
        break

# Fallback se nulla di buono
if best is None:
    db = DBSCAN(eps=eps0, min_samples=max(MIN_SAMPLES_CAND), algorithm='kd_tree', leaf_size=40).fit(X_scaled)
    summ, _ = summarize(df_base, db.labels_)
    best = (score(summ, MIN_SIZE_PRIMARY), eps0, max(MIN_SAMPLES_CAND), db.labels_, summ)

(sc_tuple, eps_star, mins_star, labels_star, summary_star) = best
print(f"🔧 Selezionato eps={eps_star:.3f}, min_samples={mins_star} ⇒ nodi≥{MIN_SIZE_PRIMARY}: {sc_tuple[1]}")

# ====== 9) AUTO-REFINE: split ricorsivo cluster più grande =====
labels_ref = labels_star.copy()

if AUTO_REFINE:
    df_lab = df_base.copy()
    df_lab['cluster'] = labels_ref
    for split_round in range(MAX_SPLITS):
        summ_now, _ = summarize(df_base, labels_ref)
        if count_with_min_size(summ_now, MIN_SIZE_PRIMARY) >= TARGET_MIN_NODES:
            print(f"✅ Obiettivo raggiunto prima dei refine (round {split_round}).")
            break
        if summ_now.empty:
            break

        big_id = int(summ_now.sort_values('num_members', ascending=False).iloc[0]['cluster'])
        idx_big = (df_lab['cluster'].values == big_id)
        X_big = X_scaled[idx_big]

        eps_local = max(0.05, eps_star * EPS_SHRINK)
        ms_local = max(5, mins_star - MIN_SAMPLES_DEC)

        db_big = DBSCAN(eps=eps_local, min_samples=ms_local,
                        algorithm='kd_tree', leaf_size=40).fit(X_big)
        new = db_big.labels_
        # se non ha creato nuovi cluster, salta
        new_clusters = len(set(new)) - (1 if -1 in new else 0)
        if new_clusters <= 1:
            print(f"ℹ️  Round {split_round+1}: nessuno split utile (eps_local={eps_local:.3f}, ms_local={ms_local}).")
            continue

        # rimappa i nuovi cluster nel globale: -1 resta nel cluster originale
        max_label = labels_ref.max() if len(labels_ref) else -1
        next_id = max_label + 1
        j = 0
        for i, is_big in enumerate(idx_big):
            if is_big:
                nl = new[j]; j += 1
                if nl == -1:
                    # mantieni il vecchio cluster (niente perdita di punti)
                    labels_ref[i] = big_id
                else:
                    labels_ref[i] = next_id + nl

        df_lab['cluster'] = labels_ref
        print(f"✂️  Split round {split_round+1}: creati {new_clusters} sottocluster dal cluster {big_id}.")

# ====== 10) SUMMARY + FILTRO DIMENSIONALE =====
summary_use, _ = summarize(df_base, labels_ref)

# usa soglia 6; se non basta per ≥10, fallback a 5
if count_with_min_size(summary_use, MIN_SIZE_PRIMARY) < TARGET_MIN_NODES:
    print(f"⚠️ Con soglia {MIN_SIZE_PRIMARY} ho {count_with_min_size(summary_use, MIN_SIZE_PRIMARY)} nodi ⇒ fallback a {MIN_SIZE_FALLBACK}.")
    min_size_eff = MIN_SIZE_FALLBACK
else:
    min_size_eff = MIN_SIZE_PRIMARY

summary_use = summary_use[summary_use['num_members'] >= min_size_eff].copy()

# cap a 20 nodi: prendi i migliori per |∇K| (tie-break su dimensione)
if len(summary_use) > 20:
    summary_use['score'] = summary_use['mean_gradK'].abs()
    summary_use = summary_use.sort_values(['score','num_members'], ascending=[False, False]).head(20).drop(columns='score')

summary_use = summary_use.sort_values('cluster').reset_index(drop=True)
summary_use['ID_Node'] = [f"T-Node-{int(c):04d}" for c in summary_use['cluster']]
summary_use['eps'] = eps_star
summary_use['min_samples'] = mins_star
summary_use['min_size_threshold'] = min_size_eff

out_csv = f"telascura_nodes_refined_min10_k{MIN_SIZE_PRIMARY}.csv"
summary_use.to_csv(out_csv, index=False)
print(f"📁 File salvato: {out_csv} — nodi={len(summary_use)}, soglia membri={min_size_eff}")

# ===================== 11) MAPPA =====================
plt.figure(figsize=(10,6))
sc = plt.scatter(summary_use['l_mean'], summary_use['b_mean'],
                 c=summary_use['mean_gradK'], cmap='coolwarm',
                 s=60, edgecolor='k', linewidths=0.5)
plt.colorbar(sc, label=f'{GRADK_LABEL} medio')
plt.xlabel("l [°]"); plt.ylabel("b [°]")
plt.title(f"Mappa Nodi Coerenti Telascura (≥{TARGET_MIN_NODES}, membri≥{min_size_eff}) — eps={eps_star:.3f}, min_samples={mins_star}")
plt.grid(True, alpha=0.3); plt.tight_layout()
plt.savefig(f"mappa_nodi_telascura_refined_min10_k{min_size_eff}.png", dpi=160)
print("🗺️ Mappa salvata.")
