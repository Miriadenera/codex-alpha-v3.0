#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
radec_to_lb.py
---------------
Add Galactic coordinates (l_deg, b_deg) from equatorial RA/Dec (deg) to a CSV.

Usage:
  python radec_to_lb.py --in gaia_codex_filtered_density.csv \
                        --col-ra ra --col-dec dec \
                        --out gaia_codex_filtered_density_lb.csv
"""
import argparse
import numpy as np
import pandas as pd
from pathlib import Path

def radec_to_lb(ra_deg, dec_deg):
    # IAU 1958 (J2000) constants
    alpha_g = np.deg2rad(192.85948)   # RA of North Galactic Pole
    delta_g = np.deg2rad(27.12825)    # Dec of North Galactic Pole
    l_omega = np.deg2rad(32.93192)    # Galactic longitude of ascending node

    ra = np.deg2rad(ra_deg)
    dec = np.deg2rad(dec_deg)

    sinb = np.sin(dec)*np.sin(delta_g) + np.cos(dec)*np.cos(delta_g)*np.cos(ra - alpha_g)
    b = np.arcsin(np.clip(sinb, -1.0, 1.0))

    y = np.cos(dec) * np.sin(ra - alpha_g)
    x = np.sin(dec) * np.cos(delta_g) - np.cos(dec) * np.sin(delta_g) * np.cos(ra - alpha_g)
    l = l_omega + np.arctan2(y, x)

    # Wrap to [0, 2π)
    l = np.mod(l, 2*np.pi)

    return np.rad2deg(l), np.rad2deg(b)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="infile", required=True, help="input CSV with RA/Dec (deg)")
    ap.add_argument("--out", dest="outfile", required=True, help="output CSV with l_deg,b_deg added")
    ap.add_argument("--col-ra", default="ra", help="RA column name (deg)")
    ap.add_argument("--col-dec", default="dec", help="Dec column name (deg)")
    args = ap.parse_args()

    df = pd.read_csv(args.infile)
    if args.col_ra not in df.columns or args.col_dec not in df.columns:
        raise SystemExit(f"Columns '{args.col_ra}' or '{args.col_dec}' not found in {args.infile}.")

    l_deg, b_deg = radec_to_lb(df[args.col_ra].values, df[args.col_dec].values)
    df_out = df.copy()
    df_out["l_deg"] = l_deg
    df_out["b_deg"] = b_deg
    df_out.to_csv(args.outfile, index=False)
    print(f"[WRITE] {args.outfile} with columns l_deg,b_deg added.")

if __name__ == "__main__":
    main()
