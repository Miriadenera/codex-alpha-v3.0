import pandas as pd
from astropy.io.votable import parse
from astropy.table import Table

# === STEP 1 – Caricamento file VOT ===
votable = parse("1748519392555O-result.vot")
table = votable.get_first_table().to_table()
df = table.to_pandas()

# === STEP 2 – Stampa colonne disponibili ===
print("📌 Colonne trovate nel file VOT:")
print(df.columns.tolist())

# === STEP 3 – Filtro: solo stelle con parallasse valida ===
if 'parallax_error' in df.columns:
    df = df[(df['parallax'] > 0) & (df['parallax_error'] < 0.1)]
else:
    print("⚠️ Colonna 'parallax_error' non trovata. Uso solo filtro parallax > 0.")
    df = df[df['parallax'] > 0]

# === STEP 4 – Calcolo distanza in parsec ===
df['distance_pc'] = 1000 / df['parallax']  # milliarcosecondi → pc

# === STEP 5 – Coordinate cartesiane ===
from astropy.coordinates import SkyCoord
import astropy.units as u

coords = SkyCoord(
    ra=df['ra'].values * u.degree,
    dec=df['dec'].values * u.degree,
    distance=df['distance_pc'].values * u.pc,
    frame='icrs'
)

df['x_pc'] = coords.cartesian.x.value
df['y_pc'] = coords.cartesian.y.value
df['z_pc'] = coords.cartesian.z.value

# === STEP 6 – Densità locale e ∇𝒦 ===
from sklearn.neighbors import NearestNeighbors
import numpy as np

positions = df[['x_pc', 'y_pc', 'z_pc']].values
nn = NearestNeighbors(n_neighbors=10).fit(positions)
distances, _ = nn.kneighbors(positions)

df['local_density'] = 1 / distances.mean(axis=1)
df['gradK_proxy'] = np.gradient(df['local_density'])

# === STEP 7 – Output ===
print("\n✅ Prime righe:")
print(df[['ra', 'dec', 'distance_pc', 'x_pc', 'y_pc', 'z_pc', 'local_density', 'gradK_proxy']].head())

# === STEP 8 – Salva CSV (facoltativo) ===
df.to_csv("gaia_extracted_codex.csv", index=False)
print("\n💾 File salvato: gaia_extracted_codex.csv")
