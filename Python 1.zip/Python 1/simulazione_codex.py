import numpy as np
import matplotlib.pyplot as plt

# Parametri della simulazione
N = 200                      # Numero di nodi nel reticolo 1D
dx = 0.1                    # Spaziatura del reticolo
dt = 0.01                   # Passo temporale
steps = 1000               # Numero di passi temporali
lambda_c = 0.1             # Fattore di accoppiamento

# Potenziale simbolico: V(K) = a*K^2 + b*K^4 + c*K^6
a, b, c = 1.0, -0.5, 0.25

# Inizializzazione del campo K(x)
K = np.random.rand(N) * 0.1   # Piccole fluttuazioni iniziali
K_new = np.copy(K)

# Funzione gradiente discreto (Laplaciano centrale)
def gradient(K):
    grad = np.zeros_like(K)
    grad[1:-1] = (K[2:] - 2 * K[1:-1] + K[:-2]) / dx**2
    return grad

# Funzione derivata del potenziale
def dV_dK(K):
    return 2*a*K + 4*b*K**3 + 6*c*K**5

# Funzione proiezione informazionale Ω(x) (maschera binaria fissa)
Omega = np.ones(N)
Omega[:20] = 0   # Esempio: zona incoerente ai bordi
Omega[-20:] = 0

# Simulazione temporale
for step in range(steps):
    grad_K = gradient(K)
    K_new = K + dt * Omega * (-dV_dK(K) - lambda_c * grad_K)
    K = np.copy(K_new)

# Plot finale
x = np.linspace(0, N*dx, N)
plt.plot(x, K, label='Campo informazionale K(x)')
plt.title("Simulazione Campo $\\mathcal{K}(x)$ – Codex Alpha")
plt.xlabel("x")
plt.ylabel("$\\mathcal{K}(x)$")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()
