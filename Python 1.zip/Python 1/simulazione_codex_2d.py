import numpy as np
import matplotlib.pyplot as plt

# Dimensione del reticolo
Nx, Ny = 100, 100
dx = dy = 1.0
dt = 0.01
steps = 1000

# Parametri del potenziale informazionale
alpha = 1.0
beta = -1.5
gamma = 1.0
lambda_c = 0.2  # costante di rigidezza del gradiente

# Inizializzazione dei campi
K = np.random.normal(0, 0.05, (Nx, Ny))   # campo iniziale
K_new = np.copy(K)
K_old = np.copy(K)

# Maschera di proiezione Omega(x, y)
Omega = np.ones((Nx, Ny))
Omega[:10, :] = 0
Omega[-10:, :] = 0
Omega[:, :10] = 0
Omega[:, -10:] = 0

# Iterazione temporale
for step in range(steps):
    laplacian = (
        np.roll(K, 1, axis=0) + np.roll(K, -1, axis=0) +
        np.roll(K, 1, axis=1) + np.roll(K, -1, axis=1) -
        4 * K
    ) / dx**2

    potential_grad = alpha * K + beta * K**3 + gamma * K**5

    # Equazione del moto discreta
    K_new = 2 * K - K_old + dt**2 * Omega * (lambda_c * laplacian - potential_grad)

    K_old = np.copy(K)
    K = np.copy(K_new)

# Visualizzazione finale
plt.figure(figsize=(8, 6))
plt.imshow(K, cmap='viridis', extent=(0, Nx*dx, 0, Ny*dy))
plt.colorbar(label=r"$\mathcal{K}(x, y)$")
plt.title(r"Simulazione campo $\mathcal{K}(x, y)$ – Codex Alpha 2D")
plt.xlabel("x")
plt.ylabel("y")
plt.tight_layout()
plt.show()
