#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Raccoglie i nomi delle colonne da tutti i CSV nella cartella corrente
(e, se richiesto, nelle sottocartelle) e scrive un riepilogo in sommary.csv.

Campi output: file, has_header, delimiter, num_columns, columns
"""
import argparse
import csv
import os
from pathlib import Path

ENCODINGS = ["utf-8", "utf-8-sig", "cp1252", "latin-1"]
DELIMS = [",", ";", "\t", "|"]

def detect_encoding(path: Path):
    for enc in ENCODINGS:
        try:
            with open(path, "r", encoding=enc, newline="") as f:
                f.read(4096)
            return enc
        except UnicodeDecodeError:
            continue
    return None

def read_sample(path: Path, enc: str, nbytes: int = 65536) -> str:
    with open(path, "r", encoding=enc, newline="") as f:
        return f.read(nbytes)

def detect_delimiter_and_header(sample: str):
    sniffer = csv.Sniffer()
    # delimiter
    try:
        dialect = sniffer.sniff(sample, delimiters=DELIMS)
        delim = dialect.delimiter
        quotechar = getattr(dialect, "quotechar", '"')
    except Exception:
        # fallback: scegli il delimitatore che produce più colonne nella prima riga non vuota
        first_line = next((ln for ln in sample.splitlines() if ln.strip()), "")
        if not first_line:
            delim, quotechar = ",", '"'
        else:
            delim = max(DELIMS, key=lambda d: first_line.count(d))
            quotechar = '"'
    # header?
    try:
        has_header = sniffer.has_header(sample)
    except Exception:
        has_header = True  # default ottimistico
    return delim, quotechar, has_header

def get_header(path: Path, enc: str, delim: str, quotechar: str, has_header: bool):
    header = []
    with open(path, "r", encoding=enc, newline="") as f:
        reader = csv.reader(f, delimiter=delim, quotechar=quotechar)
        first_row = next(reader, [])
        if has_header:
            header = [c.strip() for c in first_row]
        else:
            # Non c'è header: prova a vedere se i valori sembrano nomi; altrimenti crea col1..N
            looks_like_names = all(isinstance(x, str) and not x.strip().replace(".", "", 1).isdigit()
                                   for x in first_row)
            header = [c.strip() for c in first_row] if looks_like_names else [f"col{i+1}" for i in range(len(first_row))]
    return header

def main():
    ap = argparse.ArgumentParser(description="Crea un riepilogo delle colonne di tutti i CSV nella cartella.")
    ap.add_argument("--root", default=".", help="Cartella di partenza (default: .)")
    ap.add_argument("--recursive", action="store_true", help="Cerca anche nelle sottocartelle.")
    ap.add_argument("--out", default="sommary.csv", help="Nome file di output CSV (default: sommary.csv)")
    args = ap.parse_args()

    root = Path(args.root)
    if not root.exists():
        print(f"[ERR] Root non esiste: {root}")
        return

    files = []
    if args.recursive:
        files = [p for p in root.rglob("*.csv") if p.is_file()]
    else:
        files = [p for p in root.glob("*.csv") if p.is_file()]

    rows_out = []
    for path in sorted(files):
        try:
            enc = detect_encoding(path)
            if enc is None:
                rows_out.append({
                    "file": str(path.relative_to(root)),
                    "has_header": "unknown",
                    "delimiter": "unknown",
                    "num_columns": 0,
                    "columns": "DECODE_ERROR"
                })
                continue

            sample = read_sample(path, enc)
            delim, quotechar, has_header = detect_delimiter_and_header(sample)
            header = get_header(path, enc, delim, quotechar, has_header)
            rows_out.append({
                "file": str(path.relative_to(root)),
                "has_header": str(bool(has_header)),
                "delimiter": "\\t" if delim == "\t" else delim,
                "num_columns": len(header),
                "columns": " | ".join(header)
            })
        except Exception as e:
            rows_out.append({
                "file": str(path.relative_to(root)),
                "has_header": "unknown",
                "delimiter": "unknown",
                "num_columns": 0,
                "columns": f"ERROR: {type(e).__name__}: {e}"
            })

    # scrivi output
    out_path = root / args.out
    with open(out_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["file", "has_header", "delimiter", "num_columns", "columns"])
        writer.writeheader()
        for r in rows_out:
            writer.writerow(r)

    print(f"[WRITE] {out_path}  (rows={len(rows_out)})")

if __name__ == "__main__":
    main()
