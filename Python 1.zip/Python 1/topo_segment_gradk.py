#!/usr/bin/env python3
# Topological segmentation of the informational gradient in (l,b).
# Uses gradK_proxy explicitly. ASCII-only.

import json
import argparse
import numpy as np
import pandas as pd

# deps
try:
    from skimage.feature import peak_local_max
    from skimage.segmentation import watershed
    from skimage.measure import find_contours
    from skimage.morphology import local_minima, h_minima
except Exception as e:
    raise SystemExit(
        "Missing scikit-image. Install it with:\n"
        "  pip install scikit-image\n"
        f"Original import error: {e}"
    )

from scipy.stats import binned_statistic_2d
from scipy.ndimage import gaussian_filter, binary_dilation

# optional fallback to compute l,b from ra,dec if l,b are missing
try:
    from astropy.coordinates import SkyCoord
    import astropy.units as u
    _HAS_ASTROPY = True
except Exception:
    _HAS_ASTROPY = False

# ===================== defaults =====================
INPUT_CSV    = "gaia_codex_with_kinematics.csv"   # must contain l,b (or ra,dec) and gradK_proxy
GRADK_COL    = "gradK_proxy"                      # forced name
OUT_NODES    = "topo_nodes.csv"
OUT_GEOJSON  = "topo_basins.geojson"
OUT_LABELS   = "topo_label_grid.npz"

# grid/segmentation default settings (can be overridden via CLI)
DEF_deg_per_pix_l = 0.02
DEF_deg_per_pix_b = 0.02
DEF_gauss_sigma   = 1.5
DEF_min_peak_sep  = 5
DEF_min_region_px = 30
DEF_export_polygons = False
# ===================================================

def parse_args():
    p = argparse.ArgumentParser(
        description="Topological segmentation over gradK_proxy in (l,b)."
    )
    p.add_argument("--input", default=INPUT_CSV)
    p.add_argument("--grad-col", default=GRADK_COL)
    p.add_argument("--out-nodes", default=OUT_NODES)
    p.add_argument("--out-geojson", default=OUT_GEOJSON)
    p.add_argument("--out-labels", default=OUT_LABELS)
    p.add_argument("--deg-per-pix-l", type=float, default=DEF_deg_per_pix_l)
    p.add_argument("--deg-per-pix-b", type=float, default=DEF_deg_per_pix_b)
    p.add_argument("--sigma", type=float, default=DEF_gauss_sigma)
    p.add_argument("--min-peak-sep", type=int, default=DEF_min_peak_sep)
    p.add_argument("--min-region-px", type=int, default=DEF_min_region_px)
    p.add_argument("--export-polygons", action="store_true", default=DEF_export_polygons)
    return p.parse_args()

def ensure_lb(df):
    """Ensure columns l,b exist; if not and ra,dec exist, compute (requires astropy)."""
    if {"l","b"}.issubset(df.columns):
        return df
    if {"ra","dec"}.issubset(df.columns) and _HAS_ASTROPY:
        c = SkyCoord(ra=df["ra"].values*u.deg, dec=df["dec"].values*u.deg, frame="icrs")
        df = df.copy()
        df["l"] = c.galactic.l.deg
        df["b"] = c.galactic.b.deg
        return df
    raise ValueError("CSV must contain l,b or (ra,dec) with astropy available.")

def rasterize_mean(l, b, v, l_edges, b_edges):
    stat = binned_statistic_2d(b, l, v, statistic="mean",  bins=[b_edges, l_edges])
    cnt  = binned_statistic_2d(b, l, v, statistic="count", bins=[b_edges, l_edges]).statistic
    return stat.statistic, cnt  # grids shaped (nb, nl)

def compute_gradients(field, dl, db):
    gy, gx = np.gradient(field, db, dl)   # numpy order: rows (b), cols (l)
    G = np.sqrt(gx*gx + gy*gy)
    return gx, gy, G

def hessian_type(K, iy, ix, db, dl):
    nb, nl = K.shape
    iy = np.clip(iy, 1, nb-2)
    ix = np.clip(ix, 1, nl-2)
    dK_db_f  = (K[iy+1, ix] - K[iy, ix]) / db
    dK_db_b  = (K[iy, ix] - K[iy-1, ix]) / db
    d2K_db2  = (dK_db_f - dK_db_b) / db
    dK_dl_f  = (K[iy, ix+1] - K[iy, ix]) / dl
    dK_dl_b  = (K[iy, ix] - K[iy, ix-1]) / dl
    d2K_dl2  = (dK_dl_f - dK_dl_b) / dl
    d2K_dbdl = (K[iy+1, ix+1] - K[iy+1, ix-1] - K[iy-1, ix+1] + K[iy-1, ix-1]) / (4.0*db*dl)
    H = np.array([[d2K_db2, d2K_dbdl],[d2K_dbdl, d2K_dl2]], dtype=float)
    vals = np.linalg.eigvalsh(H)
    if np.all(vals > 0):  return "min"
    if np.all(vals < 0):  return "max"
    return "saddle"

def basin_persistence(G, region_mask, marker_val):
    rim = binary_dilation(region_mask) & (~region_mask)
    rim_vals = G[rim]
    if rim_vals.size == 0 or not np.isfinite(marker_val):
        return np.nan
    border_med = np.nanmedian(rim_vals)
    return float(border_med - marker_val)

# -------- adaptive marker utilities --------
def _thin_by_distance(coords, G, min_sep):
    """Greedy thinning: prefer deeper minima (lower G)."""
    if coords.size == 0:
        return coords
    vals = G[coords[:,0], coords[:,1]]
    order = np.argsort(vals)  # from deepest minimum
    keep = []
    used = np.zeros(len(coords), dtype=bool)
    for j in order:
        if used[j]:
            continue
        p = coords[j]
        keep.append(p)
        dy = coords[:,0] - p[0]
        dx = coords[:,1] - p[1]
        used |= (dy*dy + dx*dx) < (min_sep*min_sep)
    return np.array(keep, dtype=int)

def find_markers_adaptive(G, mask, min_peak_sep):
    # 1) pure local minima
    Gw = G.copy()
    Gw[~mask] = np.nanmax(Gw[mask])
    mins = local_minima(Gw) & mask
    coords = np.column_stack(np.nonzero(mins))
    coords = _thin_by_distance(coords, G, min_peak_sep)
    if coords.size:
        return coords

    # 2) h-minima with adaptive h
    h = float(np.nanstd(Gw[mask]) * 0.25)
    mins2 = h_minima(Gw, h=h) & mask
    coords = np.column_stack(np.nonzero(mins2))
    coords = _thin_by_distance(coords, G, min_peak_sep)
    if coords.size:
        return coords

    # 3) percentile fallback
    q = float(np.nanquantile(Gw[mask], 0.30))
    yy, xx = np.where((Gw <= q) & mask)
    coords = np.column_stack([yy, xx])
    coords = _thin_by_distance(coords, G, min_peak_sep)
    return coords
# -------------------------------------------

def main():
    args = parse_args()

    # load
    df = pd.read_csv(args.input)
    df = ensure_lb(df)
    if args.grad_col not in df.columns:
        raise ValueError(f"Column '{args.grad_col}' not found in CSV.")
    sub = df[["l","b", args.grad_col]].dropna().copy()
    sub = sub[np.isfinite(sub[args.grad_col])]
    if len(sub) == 0:
        raise ValueError("No finite data in gradK_proxy.")

    # grid
    lmin, lmax = float(np.nanmin(sub["l"])), float(np.nanmax(sub["l"]))
    bmin, bmax = float(np.nanmin(sub["b"])), float(np.nanmax(sub["b"]))
    nl = max(2, int(np.ceil((lmax - lmin)/args.deg_per_pix_l)))
    nb = max(2, int(np.ceil((bmax - bmin)/args.deg_per_pix_b)))
    l_edges = np.linspace(lmin, lmax, nl+1)
    b_edges = np.linspace(bmin, bmax, nb+1)
    dl = (l_edges[1]-l_edges[0])
    db = (b_edges[1]-b_edges[0])
    pix_area_deg2 = dl * db

    # rasterize per-bin mean of gradK_proxy and star counts
    K_grid, N_grid = rasterize_mean(sub["l"].values, sub["b"].values,
                                    sub[args.grad_col].values, l_edges, b_edges)
    mask = np.isfinite(K_grid)
    if not mask.any():
        raise ValueError("Raster is empty; increase area or relax bin size.")

    # smoothing with fill for NaN
    K_s = K_grid.copy()
    K_s[~mask] = np.nan
    fill = float(np.nanmedian(K_s[mask]))
    K_s[~mask] = fill
    K_s = gaussian_filter(K_s, sigma=args.sigma)
    K_s[~mask] = np.nan

    # gradients on smoothed raster
    gx, gy, G = compute_gradients(K_s, dl, db)
    G[~mask] = np.nan

    # markers: robust adaptive search for minima of G
    coords = find_markers_adaptive(G, mask, args.min_peak_sep)
    if coords.size == 0:
        raise RuntimeError("Still no markers after adaptive search; try coarser grid or sigma ~ 0.8-1.2.")

    markers = np.zeros_like(G, dtype=int)
    for i, (iy, ix) in enumerate(coords, start=1):
        markers[iy, ix] = i

    # watershed segmentation on G
    labels = watershed(G, markers=markers, mask=mask)

    # filter tiny basins
    valid_labels, counts = np.unique(labels[labels > 0], return_counts=True)
    keep = set(valid_labels[counts >= args.min_region_px])

    # centers
    l_centers = 0.5*(l_edges[:-1] + l_edges[1:])
    b_centers = 0.5*(b_edges[:-1] + b_edges[1:])

    rows = []
    features = []
    for lab in sorted(list(keep)):
        reg = (labels == lab)
        if reg.sum() < args.min_region_px:
            continue

        iy, ix = np.nonzero(reg)
        cy = int(np.round(iy.mean()))
        cx = int(np.round(ix.mean()))
        cy = np.clip(cy, 0, len(b_centers)-1)
        cx = np.clip(cx, 0, len(l_centers)-1)

        l_mean = float(l_centers[cx])
        b_mean = float(b_centers[cy])

        area_deg2 = float(reg.sum() * pix_area_deg2)
        Nstars    = float(np.nansum(N_grid[reg]))
        K_mean    = float(np.nanmean(K_s[reg]))
        # simple variability proxy inside basin
        gradK_mean= float(np.nanmean(np.abs(K_s[reg] - K_mean)))

        node_type = hessian_type(K_s, cy, cx, db, dl)

        if markers[cy, cx] > 0:
            marker_val = float(G[cy, cx])
        else:
            my, mx = np.where((markers > 0) & reg)
            if my.size:
                k = int(np.argmin((my-cy)**2 + (mx-cx)**2))
                marker_val = float(G[my[k], mx[k]])
            else:
                marker_val = np.nan
        persistence = basin_persistence(G, reg, marker_val)

        node_id = f"T-Topo-{lab:04d}"
        rows.append([node_id, l_mean, b_mean, node_type, area_deg2, Nstars, K_mean, gradK_mean, persistence])

        feat = {
            "type": "Feature",
            "properties": {
                "id": node_id,
                "type": node_type,
                "area_deg2": area_deg2,
                "Nstars": Nstars,
                "K_mean": K_mean,
                "gradK_mean": gradK_mean,
                "persistence": persistence
            },
            "geometry": {"type": "Point", "coordinates": [l_mean, b_mean]}
        }
        features.append(feat)

        if args.export_polygons:
            mask_float = reg.astype(float)
            conts = find_contours(mask_float, level=0.5)
            if conts:
                contour = max(conts, key=lambda c: c.shape[0])
                poly = []
                for yy, xx in contour:
                    yy = np.clip(int(round(yy)), 0, len(b_centers)-1)
                    xx = np.clip(int(round(xx)), 0, len(l_centers)-1)
                    poly.append([float(l_centers[xx]), float(b_centers[yy])])
                if len(poly) > 3:
                    features.append({
                        "type": "Feature",
                        "properties": {"id": node_id, "kind": "polygon"},
                        "geometry": {"type": "Polygon", "coordinates": [poly]}
                    })

    cols = ["ID","l_mean","b_mean","type","area_deg2","Nstars","K_mean","gradK_mean","persistence"]
    pd.DataFrame(rows, columns=cols).to_csv(args.out_nodes, index=False)
    print("Saved nodes CSV:", args.out_nodes, " (N=", len(rows), ")")

    gj = {"type": "FeatureCollection", "features": features,
          "crs": {"type":"name","properties":{"name":"galactic_l_b_deg"}}}
    with open(args.out_geojson, "w", encoding="utf-8") as f:
        json.dump(gj, f)
    print("Saved basins GeoJSON:", args.out_geojson, " (features:", len(features), ")")

    np.savez_compressed(args.out_labels,
                        labels=labels.astype(np.int32),
                        l_edges=l_edges, b_edges=b_edges,
                        K_s=K_s, G=G)
    print("Saved label grid:", args.out_labels)

if __name__ == "__main__":
    main()
