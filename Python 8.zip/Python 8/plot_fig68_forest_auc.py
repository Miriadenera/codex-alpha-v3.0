#!/usr/bin/env python3
# plot_fig68_forest_auc_boot.py
import argparse, numpy as np, pandas as pd, matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

def block_ids(l, b, nx=4, ny=3):
    i = np.floor((l - l.min()) / (l.max()-l.min()+1e-9) * nx).astype(int)
    j = np.floor((b - b.min()) / (b.max()-b.min()+1e-9) * ny).astype(int)
    i = np.clip(i, 0, nx-1); j = np.clip(j, 0, ny-1)
    return i + nx*j

def fit_lr(df, colsX, sample_weight=None):
    X = df[colsX].to_numpy()
    y = df["y"].to_numpy()
    lr = LogisticRegression(
        solver="lbfgs", max_iter=200, fit_intercept=True
    )
    lr.fit(X, y, sample_weight=sample_weight)
    # coeff senza intercetta
    betas = lr.coef_.ravel()
    # probabilità per AUC
    p = lr.predict_proba(X)[:,1]
    auc = roc_auc_score(y, p, sample_weight=sample_weight)
    return betas, auc

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--table", default="fig68_table.csv")
    ap.add_argument("--B", type=int, default=600)
    ap.add_argument("--nx", type=int, default=4)
    ap.add_argument("--ny", type=int, default=3)
    ap.add_argument("--out-pdf", default="fig68_forest_auc.pdf")
    ap.add_argument("--out-csv", default="fig68_betas_auc.csv")
    args = ap.parse_args()

    df = pd.read_csv(args.table)
    cols = [c for c in ["absb","Sigma_star","A_lambda"] if c in df.columns]
    labels = [r"$|b|$", r"$\Sigma_\star$", r"$A_\lambda$"][:len(cols)]
    w = df["S"].to_numpy() if "S" in df.columns else None

    # fit su full sample
    betas_hat, auc_hat = fit_lr(df, cols, sample_weight=w)

    # block bootstrap per CI di betas e AUC
    bid = block_ids(df["l_deg"].to_numpy(), df["b_deg"].to_numpy(), args.nx, args.ny)
    uniq = np.unique(bid)
    rng = np.random.default_rng(42)
    B = args.B
    Bbet = np.zeros((B, len(cols)))
    Bauc = np.zeros(B)
    for b in range(B):
        sel = rng.choice(uniq, size=len(uniq), replace=True)
        mask = np.isin(bid, sel)
        if mask.sum() < 20:
            Bbet[b,:] = np.nan; Bauc[b] = np.nan; continue
        ww = w[mask] if w is not None else None
        bb, aa = fit_lr(df[mask], cols, sample_weight=ww)
        Bbet[b,:] = bb; Bauc[b] = aa
    # rimuovi NaN eventualmente
    Bbet = Bbet[~np.isnan(Bbet).any(1)]
    Bauc = Bauc[~np.isnan(Bauc)]

    lo = np.quantile(Bbet, 0.025, axis=0)
    hi = np.quantile(Bbet, 0.975, axis=0)
    auc_lo, auc_hi = np.quantile(Bauc, [0.025, 0.975])

    # --- plot
    fig = plt.figure(figsize=(6.3, 3.2))
    ax = fig.add_axes([0.10, 0.20, 0.55, 0.70])
    y_pos = np.arange(len(cols))[::-1]
    ax.hlines(y_pos, lo[::-1], hi[::-1])
    ax.plot(betas_hat[::-1], y_pos, "o")
    ax.set_yticks(y_pos); ax.set_yticklabels(labels[::-1])
    ax.axvline(0.0, linestyle="--", linewidth=1)
    ax.set_xlabel("Log-odds coefficient (95% block CI)")
    ax.set_title("Logistic controls")

    ax2 = fig.add_axes([0.72, 0.35, 0.24, 0.45])
    ax2.bar([0], [auc_hat], width=0.6)
    ax2.vlines(0, auc_lo, auc_hi, linewidth=3)
    ax2.set_xticks([0]); ax2.set_xticklabels(["AUC"])
    ax2.set_ylim(0.5, 1.0)
    ax2.set_ylabel("AUC (block CI)")

    fig.savefig(args.out_pdf, bbox_inches="tight")
    pd.DataFrame({
        "name":labels, "beta":betas_hat, "lo":lo, "hi":hi,
        "auc":[auc_hat], "auc_lo":[auc_lo], "auc_hi":[auc_hi]
    }).to_csv(args.out_csv, index=False)
    print(f"[WRITE] {args.out_pdf}\n[WRITE] {args.out_csv}")
    print(f"AUC={auc_hat:.3f}  (95% block CI: {auc_lo:.3f}–{auc_hi:.3f})")

if __name__ == "__main__":
    main()
