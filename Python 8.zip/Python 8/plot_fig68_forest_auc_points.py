Set-Content -Encoding UTF8 plot_fig68_forest_auc_points.py 
import argparse, numpy as np, pandas as pd, matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.utils import resample

parser=argparse.ArgumentParser()
parser.add_argument("--table", required=True)
parser.add_argument("--B", type=int, default=600)
parser.add_argument("--out-pdf", default="fig68_forest_auc.pdf")
parser.add_argument("--out-csv", default="fig68_betas_auc.csv")
args=parser.parse_args()

T = pd.read_csv(args.table)
X = T[["abs_b","Sigma_star","Sel"]].values.astype(float)
y = T["y"].values.astype(int)
# standardizza per comparabilità dei beta
m = X.mean(0); s = X.std(0); s[s==0]=1.0
Xs = (X-m)/s

if len(np.unique(y))<2:
    raise SystemExit("Logit needs both classes: y has a single class. Regenerate points.")

# stima centrale
lr = LogisticRegression(solver="liblinear")
lr.fit(Xs,y)
beta_hat = lr.coef_.ravel()
auc_hat = roc_auc_score(y, lr.predict_proba(Xs)[:,1])

# bootstrap (IID sui punti campionati)
B=args.B
betas = np.zeros((B,3)); aucs = np.zeros(B)
rs = np.random.RandomState(42)
for b in range(B):
    idx = rs.randint(0,len(y), size=len(y))
    Xb, yb = Xs[idx], y[idx]
    if len(np.unique(yb))<2:
        betas[b,:]=np.nan; aucs[b]=np.nan; continue
    lrb = LogisticRegression(solver="liblinear")
    lrb.fit(Xb,yb)
    betas[b,:]=lrb.coef_.ravel()
    aucs[b]=roc_auc_score(yb, lrb.predict_proba(Xb)[:,1])

# CI 95%
q = lambda v: np.nanpercentile(v,[2.5,97.5])
ci = np.vstack([q(betas[:,0]), q(betas[:,1]), q(betas[:,2])])
ci_auc = q(aucs)

# salva csv
out = pd.DataFrame({
    "beta":["beta_abs_b","beta_Sigma_star","beta_Sel"],
    "hat": beta_hat,
    "ci_lo": ci[:,0],
    "ci_hi": ci[:,1]
})
out.to_csv(args.out_csv, index=False)

# plot forest + inset AUC
fig = plt.figure(figsize=(6.1,3.3))
ax = fig.add_axes([0.10,0.18,0.58,0.74])
names = [r"$\beta_1$ (|b|)", r"$\beta_2$ ($\Sigma_\star$)", r"$\beta_3$ ($S$)"]
ypos = np.arange(3)[::-1]+1
ax.axvline(0, lw=0.8, ls="--", alpha=0.6)
ax.errorbar(beta_hat, ypos, xerr=np.abs(np.vstack([beta_hat-ci[:,0], ci[:,1]-beta_hat])),
            fmt="s", capsize=3)
ax.set_yticks(ypos); ax.set_yticklabels(names)
ax.set_xlabel("Logit coefficient")
ax.set_ylim(0.4,3.6)

ax2 = fig.add_axes([0.74,0.28,0.22,0.6])
ax2.bar([0],[auc_hat], width=0.35)
ax2.vlines([0], [ci_auc[0]], [ci_auc[1]], lw=2)
ax2.set_xticks([0]); ax2.set_xticklabels(["AUC"])
ax2.set_ylim(0.45,1.0)

fig.savefig(args.out_pdf, bbox_inches="tight")
print(f"[WRITE] {args.out_pdf} ; AUC={auc_hat:.3f}  (95% CI {ci_auc[0]:.3f}–{ci_auc[1]:.3f})")
