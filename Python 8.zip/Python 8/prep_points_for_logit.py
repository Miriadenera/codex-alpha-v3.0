Set-Content -Encoding UTF8 prep_points_for_logit.py 
import argparse, json, numpy as np, pandas as pd
from shapely.geometry import shape, Point
parser=argparse.ArgumentParser()
parser.add_argument("--basins-geo", required=True)
parser.add_argument("--density-csv", required=True)
parser.add_argument("--selection-csv", default=None)
parser.add_argument("--col-l", default="l_deg")
parser.add_argument("--col-b", default="b_deg")
parser.add_argument("--col-sigma", default="local_density")
parser.add_argument("--sample", type=int, default=4000)
parser.add_argument("--out", default="fig68_points.csv")
args=parser.parse_args()

# 1) Geometria unione bacini
with open(args.basins_geo,"r",encoding="utf-8") as f:
    gj=json.load(f)
geoms=[]
for feat in (gj["features"] if "features" in gj else [gj]):
    try: geoms.append(shape(feat["geometry"]))
    except Exception: pass
from shapely.ops import unary_union
U = unary_union(geoms)

# 2) Catalogo densità (porta con te |b|)
df = pd.read_csv(args.density_csv, low_memory=False)
L = df[args.col_l].values; B = df[args.col_b].values
df = pd.DataFrame({
    "l": L, "b": B, 
    "absb": np.abs(B),
    "sigma": pd.to_numeric(df[args.col_sigma], errors="coerce")
}).dropna()

# 3) Maschera inside/outside rispetto ai bacini
inside = np.array([U.contains(Point(l,b)) for l,b in zip(df["l"].values, df["b"].values)], dtype=bool)
df["y"] = inside.astype(int)

# 4) Campionamento bilanciato (metà dentro, metà fuori)
n = min(args.sample//2, inside.sum(), (~inside).sum())
if n < 50:
    raise SystemExit("Too few positives/negatives on patch for a balanced sample.")
pos = df[inside].sample(n, random_state=7)
neg = df[~inside].sample(n, random_state=11)
S = pd.concat([pos,neg], ignore_index=True)

# 5) (Opzionale) attacca S(l,b) dal selection map con nearest su poche righe
if args.selection_csv:
    sel = pd.read_csv(args.selection_csv)
    colL = "l_deg_aligned" if "l_deg_aligned" in sel.columns else ("l_deg" if "l_deg" in sel.columns else args.col_l)
    colB = "b_deg" if "b_deg" in sel.columns else args.col_b
    sl = sel[colL].values; sb = sel[colB].values
    sS = sel[[c for c in sel.columns if c.lower().startswith("s")]][sel[[c for c in sel.columns if c.lower().startswith("s")]].columns[0]].values
    # nearest per ciascun punto campionato (S ha poche righe -> ok)
    idx = np.argmin((S["l"].values[:,None]-sl[None,:])**2 + (S["b"].values[:,None]-sb[None,:])**2, axis=1)
    S["Sel"] = sS[idx]
else:
    S["Sel"] = 1.0

S.rename(columns={"absb":"abs_b","sigma":"Sigma_star"}, inplace=True)
S[["y","abs_b","Sigma_star","Sel","l","b"]].to_csv(args.out, index=False)
print(f"[WRITE] {args.out}  (n={len(S)}, pos={S['y'].sum()}, neg={(1-S['y']).sum()})")

