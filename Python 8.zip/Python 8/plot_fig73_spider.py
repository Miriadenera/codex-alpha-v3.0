#!/usr/bin/env python3
"""
plot_fig73_spider.py  —  Make the Fig. 73 spider plot from fig73_spider_metrics.csv
-----------------------------------------------------------------------------------
Reads the CSV created by make_fig73_and_tab12.py and produces:
  • fig73_spider.pdf (and optional PNG) — a radial "spider" with |z|-scores per metric
  • fig73_latex.txt  — a ready-to-\input{} LaTeX snippet for the figure

Columns required in CSV:
  metric,label,z,null_median,null_lo,null_hi (others are ignored by the plotter)
If z is NaN for some row, the point is omitted (legend entry remains).

Usage (one line):
  python plot_fig73_spider.py --csv fig73_spider_metrics.csv --out-pdf fig73_spider.pdf --out-tex fig73_latex.txt
"""
import argparse, numpy as np, pandas as pd, matplotlib.pyplot as plt
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default="fig73_spider_metrics.csv")
    ap.add_argument("--out-pdf", default="fig73_spider.pdf")
    ap.add_argument("--out-png", default=None)
    ap.add_argument("--out-tex", default="fig73_latex.txt")
    args = ap.parse_args()

    df = pd.read_csv(args.csv)
    df["label"] = df["label"].astype(str)

    m = np.isfinite(df["z"].values.astype(float))
    Z = df.loc[m, "z"].astype(float).values
    labels = df.loc[m, "label"].tolist()

    if len(Z) == 0:
        print("[WARN] No finite z-scores found; producing an empty placeholder figure.")
        labels = ["(no metrics)"]
        Z = np.array([0.0])

    N = len(Z)
    theta = np.linspace(0, 2*np.pi, N, endpoint=False)
    theta = np.r_[theta, theta[0]]
    r = np.r_[np.abs(Z), np.abs(Z[0])]

    fig = plt.figure(figsize=(5.0,5.0))
    ax = fig.add_axes([0.08,0.08,0.84,0.84], polar=True)
    ax.plot(theta, r, marker="o")
    ax.fill(theta, r, alpha=0.1)
    for zref in (1,2,3):
        ax.plot(np.linspace(0,2*np.pi,400), np.full(400,zref), ls="--", lw=0.6)
    ax.set_xticks(np.linspace(0, 2*np.pi, N, endpoint=False))
    ax.set_xticklabels(labels, fontsize=9)
    ax.set_yticks([1,2,3]); ax.set_yticklabels(["1σ","2σ","3σ"])
    ax.set_title("Spider summary (|z|-scores vs null)", va="bottom")

    fig.savefig(args.out_pdf, bbox_inches="tight")
    if args.out_png:
        fig.savefig(args.out_png, dpi=200, bbox_inches="tight")

    tex = f"""% --- Fig. 73 (auto) ---
\begin{{figure}}[t]
\centering
\includegraphics[width=0.58\textwidth]{{{args.out_pdf}}}
\caption{{Spider/null summary: absolute $z$-scores per metric relative to the selection-preserving null bands. Dashed circles mark 1, 2 and 3$\sigma$.}}
\label{{fig:spider_summary}}
\end{{figure}}
""".strip()
    Path(args.out_tex).write_text(tex, encoding="utf-8")
    print(f"[WRITE] {args.out_pdf}")
    if args.out_png:
        print(f"[WRITE] {args.out_png}")
    print(f"[WRITE] {args.out_tex}")

if __name__ == "__main__":
    main()
