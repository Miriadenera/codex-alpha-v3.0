import numpy as np, pandas as pd, matplotlib.pyplot as plt
df = pd.read_csv("topo_nodes_patch.csv")
plt.figure(figsize=(8,5))
sizes = np.clip(df["area_deg2"].values * 800, 10, 200)
sc = plt.scatter(df["l_mean"], df["b_mean"], c=df["persistence_K"],
                 s=sizes, edgecolor="k", linewidth=0.4)
plt.colorbar(sc, label="Persistence K")
plt.xlabel("l [deg]"); plt.ylabel("b [deg]"); plt.grid(alpha=0.3)
plt.tight_layout(); plt.savefig("topo_centroids_persistenceK_patch.png", dpi=200)
