#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse, numpy as np, pandas as pd, matplotlib.pyplot as plt

def rose_hist(ax, angles_deg, nbins=18):
    th = np.deg2rad(angles_deg)
    bins = np.linspace(0, np.pi/2, nbins+1)
    counts, edges = np.histogram(th, bins=bins)
    widths = np.diff(edges)
    centers = edges[:-1] + widths/2.0
    r = counts.astype(float); r = r/r.max() if r.max()>0 else r
    ax.bar(centers, r, width=widths, align="center", edgecolor="none", alpha=0.85)
    ax.set_theta_zero_location("E"); ax.set_theta_direction(-1)
    ax.set_thetamin(0); ax.set_thetamax(90)
    ax.set_yticklabels([])
    ax.set_xticks(np.deg2rad([0,30,60,90])); ax.set_xticklabels(["0°","30°","60°","90°"])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--angles", required=True, help="CSV con colonna delta_deg (gradi).")
    ap.add_argument("--out", default="fig69_combined.pdf")
    args = ap.parse_args()
    df = pd.read_csv(args.angles)
    if "delta_deg" not in df.columns:
        raise SystemExit("Manca la colonna 'delta_deg'")
    th = np.deg2rad(df["delta_deg"].values)
    R = np.abs(np.mean(np.exp(1j*2.0*th)))
    Z = len(th) * (R**2)
    m = float(np.mean(np.abs(np.cos(th))))
    # null (shuffle IID) per banda
    B=600
    rng = np.random.default_rng(123)
    mnull = [float(np.mean(np.abs(np.cos(th[rng.permutation(len(th))])))) for _ in range(B)]
    m_lo, m_hi = np.percentile(mnull, [2.5,97.5])

    fig = plt.figure(figsize=(6.3,3.4))
    axL = fig.add_subplot(121, projection="polar")
    rose_hist(axL, df["delta_deg"].values)
    axL.set_title("Rose of Δθ (axial)", fontsize=10)
    axL.text(0.02, 0.98, f"Rayleigh Z = {Z:.2f}", transform=axL.transAxes, ha="left", va="top", fontsize=8)
    axR = fig.add_subplot(122)
    axR.bar([0],[m], width=0.5)
    axR.vlines([0], [m_lo], [m_hi], lw=3, alpha=0.6, color="tab:orange")
    axR.set_xticks([0]); axR.set_xticklabels([r"$\langle|\cos\Delta\theta|\rangle$"])
    axR.set_ylim(0.0, 1.0); axR.set_ylabel(r"$\langle|\cos\Delta\theta|\rangle$")
    fig.savefig(args.out, bbox_inches="tight")
    print(f"[WRITE] {args.out}")

if __name__=="__main__":
    main()
