#!/usr/bin/env python3
# prep_grid_for_logit.py
import argparse, json
import numpy as np, pandas as pd
from shapely.geometry import shape, Point
from shapely.strtree import STRtree
from scipy.spatial import cKDTree

def nn_lookup(xy_src, vals_src, xy_q):
    tree = cKDTree(xy_src)
    d, idx = tree.query(xy_q, k=8)
    w = 1.0 / np.maximum(d, 1e-6)
    if w.ndim == 1:
        return vals_src[idx]
    w = w / w.sum(axis=1, keepdims=True)
    return (vals_src[idx] * w).sum(axis=1)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--basins-geo", required=True, help="topo_basins_patch.geojson")
    ap.add_argument("--density-csv", required=True, help="gaia_codex_filtered_density_lb_aligned.csv")
    ap.add_argument("--col-l", default="l_deg_aligned")
    ap.add_argument("--col-b", default="b_deg")
    ap.add_argument("--col-sigma", default="local_density")
    ap.add_argument("--selection-csv", default=None, help="selection_map.csv (l_deg,b_deg,S)")
    ap.add_argument("--extinction-csv", default=None, help="extinction_map.csv (l_deg,b_deg,A_lambda)")
    ap.add_argument("--grid-deg", type=float, default=0.5)
    ap.add_argument("--out", default="fig68_table.csv")
    args = ap.parse_args()

    # --- basins polygons
    gj = json.load(open(args.basins_geo, "r", encoding="utf-8"))
    polys = [shape(f["geometry"]) for f in gj["features"]]
    tree = STRtree(polys)

    # --- density points (definiscono bbox e Sigma_star)
    dfD = pd.read_csv(args.density_csv)
    col_l = args.col_l
    col_b = args.col_b
    L = dfD[col_l].to_numpy()
    B = dfD[col_b].to_numpy()
    sig = dfD[args.col_sigma].astype(float).to_numpy()

    # bbox + griglia
    lmin, lmax = L.min(), L.max()
    bmin, bmax = B.min(), B.max()
    padL = 0.5 * args.grid_deg
    padB = 0.5 * args.grid_deg
    lgrid = np.arange(lmin - padL, lmax + padL + 1e-6, args.grid_deg)
    bgrid = np.arange(bmin - padB, bmax + padB + 1e-6, args.grid_deg)
    LL, BB = np.meshgrid(lgrid, bgrid)
    llc, bbc = LL.ravel(), BB.ravel()
    absb = np.abs(bbc)

    # label y via point-in-polygon
    pts = [Point(l, b) for l, b in zip(llc, bbc)]
    y = np.zeros(len(pts), dtype=int)
    for i, p in enumerate(pts):
        cand = tree.query(p)  # candidati che intersecano il bbox
        if any(g.contains(p) for g in cand):
            y[i] = 1

    # Sigma_star dalla mappa densità (NN pesato)
    xy_src = np.c_[L, B]
    xy_q   = np.c_[llc, bbc]
    Sigma_star = nn_lookup(xy_src, sig, xy_q)

    # pesi di selezione S (opzionale)
    S = np.ones_like(absb)
    if args.selection_csv:
        dfs = pd.read_csv(args.selection_csv)
        Ss = dfs["S"].astype(float).to_numpy()
        S = nn_lookup(np.c_[dfs[col_l], dfs[col_b]], Ss, xy_q)

    # estinzione A_lambda (opzionale)
    A_lambda = np.zeros_like(absb)
    if args.extinction_csv:
        dfe = pd.read_csv(args.extinction_csv)
        colA = "A_lambda"
        candA = [c for c in dfe.columns if c.startswith("A_")]
        if candA: colA = candA[0]
        Avals = dfe[colA].astype(float).to_numpy()
        A_lambda = nn_lookup(np.c_[dfe[col_l], dfe[col_b]], Avals, xy_q)

    out = pd.DataFrame(dict(
        l_deg=llc, b_deg=bbc, absb=absb, Sigma_star=Sigma_star, A_lambda=A_lambda, S=S, y=y
    ))
    out.to_csv(args.out, index=False)
    print(f"[WRITE] {args.out} ({len(out)} rows)")

if __name__ == "__main__":
    main()
