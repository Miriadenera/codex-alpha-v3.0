import pandas as pd

# Carica i dati già filtrati
df = pd.read_csv("gaia_codex_filtered_density.csv")

# Soglia di alta coerenza informazionale
threshold_gradK = 0.3
high_gradK = df[df['gradK_proxy'].abs() > threshold_gradK]

# Ordina per densità decrescente
high_gradK_sorted = high_gradK.sort_values(by='local_density', ascending=False)

# Salva i primi 500 nodi coerenti come candidate zone ∇𝒦 stabili
high_gradK_sorted.head(500).to_csv("gaia_high_gradK_zones.csv", index=False)

print("Salvati i nodi di alta coerenza informazionale.")
