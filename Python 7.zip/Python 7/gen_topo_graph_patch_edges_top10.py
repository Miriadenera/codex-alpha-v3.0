#!/usr/bin/env python3
# Extract first 10 edges (u, v, weight) from the v1 patch graph JSON.
# Input: telascura_topo_graph_v1_patch.json
# Output: topo_edges_patch_top10.csv  (ASCII-only)

import json
import pandas as pd

IN_JSON  = "telascura_topo_graph_v1_patch.json"
OUT_CSV  = "topo_edges_patch_top10.csv"
N_TAKE   = 10   # change if you want more rows

def main():
    with open(IN_JSON, "r", encoding="utf-8") as f:
        g = json.load(f)
    edges = g.get("edges", [])
    df = pd.DataFrame(edges)[["u", "v", "weight"]]
    # keep file order; if you prefer shortest edges, uncomment the next line:
    # df = df.sort_values("weight", ascending=True)
    df.head(N_TAKE).to_csv(OUT_CSV, index=False)
    print("Saved:", OUT_CSV, "rows:", min(N_TAKE, len(df)))

if __name__ == "__main__":
    main()
