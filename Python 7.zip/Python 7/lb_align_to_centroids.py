#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lb_align_to_centroids.py
------------------------
Align Galactic longitudes in a target CSV (e.g., density map with l_deg,b_deg)
to the circular mean longitude of min-basin centroids (basins_min_centroids.csv).
Fixes 0/360 wrap mismatches before building arm/GMC templates.

Usage (PowerShell, one line):
  python lb_align_to_centroids.py --ref basins_min_centroids.csv \
    --target gaia_codex_filtered_density_lb.csv \
    --col-l l_deg --col-b b_deg \
    --out gaia_codex_filtered_density_lb_aligned.csv
  # add --overwrite to replace l_deg instead of creating l_deg_aligned
"""
import argparse
import numpy as np
import pandas as pd

def circ_mean_deg(vals_deg):
    ang = np.deg2rad(np.mod(vals_deg, 360.0))
    mu = np.angle(np.mean(np.exp(1j * ang)))
    return float((np.rad2deg(mu) + 360.0) % 360.0)

def align_to_mu(l_deg, mu_deg):
    l = np.asarray(l_deg, dtype=float)
    # candidates: l-360, l, l+360  → pick closest to mu
    cand = np.stack([l - 360.0, l, l + 360.0], axis=0)
    idx = np.argmin(np.abs(cand - mu_deg), axis=0)
    chosen = cand[idx, np.arange(cand.shape[1])]
    return (chosen + 360.0) % 360.0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ref", required=True, help="CSV with centroids (needs columns l_deg,b_deg)")
    ap.add_argument("--target", required=True, help="CSV to align (has Galactic columns)")
    ap.add_argument("--col-l", default="l_deg", help="longitude column name in target CSV")
    ap.add_argument("--col-b", default="b_deg", help="latitude column name in target CSV (unused)")
    ap.add_argument("--out", required=True, help="output CSV path")
    ap.add_argument("--overwrite", action="store_true", help="overwrite target longitude column")
    args = ap.parse_args()

    ref = pd.read_csv(args.ref)
    if not {"l_deg", "b_deg"}.issubset(ref.columns):
        raise SystemExit("Reference file must contain columns l_deg,b_deg.")
    mu = circ_mean_deg(ref["l_deg"].values)

    df = pd.read_csv(args.target)
    if args.col_l not in df.columns:
        raise SystemExit(f"Column '{args.col_l}' not found in target CSV.")
    l_al = align_to_mu(df[args.col_l].values, mu)

    out = df.copy()
    if args.overwrite:
        out[args.col_l] = l_al
        added = f"overwrote {args.col_l}"
    else:
        out[args.col_l + "_aligned"] = l_al
        added = f"added {args.col_l}_aligned"
    out.to_csv(args.out, index=False)
    print(f"[WRITE] {args.out}  (mu={mu:.3f} deg; {added})")

if __name__ == "__main__":
    main()
