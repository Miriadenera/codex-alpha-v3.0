from manim import *

class NodoInformazionaleTransitionV2(Scene):
    def construct(self):
        # Pre-Page: Nodo coerente (grafico denso)
        pre_nodes = VGroup(*[Dot(LEFT*3 + np.array([x, y, 0]), radius=0.07, color=BLUE)
                            for x in [-0.5, 0, 0.5] for y in [-0.5, 0, 0.5]])
        pre_edges = VGroup(*[
            Line(p1.get_center(), p2.get_center(), color=BLUE_B)
            for p1 in pre_nodes for p2 in pre_nodes if p1 != p2 and np.linalg.norm(p1.get_center() - p2.get_center()) <= 1.1
        ])
        pre_label = Text("Pre-Page", font_size=24).next_to(pre_nodes, DOWN)

        # Transizione: spariscono connessioni, nodo centrale rilascia flusso
        center_node = Dot(color=ORANGE).move_to(ORIGIN)
        arrows = VGroup(
            Arrow(center_node.get_center(), UP, color=RED),
            Arrow(center_node.get_center(), RIGHT, color=RED)
        )
        trans_label = Text("Transizione", font_size=24).next_to(center_node, DOWN)

        # Post-Page: Rete decoerente, nodi più distanti e meno legami
        post_nodes = VGroup(*[Dot(RIGHT*3 + np.array([x, y, 0]), radius=0.07, color=ORANGE)
                            for x in [-0.7, 0, 0.7] for y in [-0.7, 0, 0.7]])
        post_edges = VGroup(*[
            Line(p1.get_center(), p2.get_center(), color=ORANGE)
            for p1 in post_nodes for p2 in post_nodes if p1 != p2 and np.linalg.norm(p1.get_center() - p2.get_center()) <= 0.9
        ])
        post_label = Text("Post-Page", font_size=24).next_to(post_nodes, DOWN)

        # Animazioni
        self.play(FadeIn(pre_nodes), FadeIn(pre_edges), Write(pre_label))
        self.wait(1)
        self.play(FadeOut(pre_nodes), FadeOut(pre_edges), FadeIn(center_node), FadeIn(arrows), Write(trans_label))
        self.wait(1)
        self.play(FadeOut(center_node), FadeOut(arrows), FadeIn(post_nodes), FadeIn(post_edges), Write(post_label))
        self.wait(2)
