#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make_arms_from_density.py
-------------------------
Build spiral-arm ridge polylines from a point CSV with per-star or gridded
density ("local_density"), by binning to a flat-sky grid, smoothing, and
tracking ridge maxima row-wise, then linking them into polylines.

Usage (example):
  python make_arms_from_density.py --root "." \
    --density-csv gaia_codex_filtered_density.csv \
    --col-l l_deg --col-b b_deg --col-val local_density \
    --grid 0.1 --sigma 0.30 --ridge-quant 0.90 --min-length 6 \
    --out-geojson template_arms.geojson --out-csv arms_ridge.csv

Outputs:
  - template_arms.geojson  (LineString polylines in [l,b] degrees)
  - arms_ridge.csv         (arm_id,l_deg,b_deg) for downstream scripts
"""
import json, argparse
import numpy as np
import pandas as pd
from pathlib import Path

def gaussian_kernel(size, sigma):
    # odd size
    r = (size-1)//2
    x = np.arange(-r, r+1)
    g = np.exp(-(x**2)/(2*sigma**2))
    g = g/np.sum(g)
    return g

def smooth2d(arr, sigma_pix):
    k = int(max(3, np.ceil(6*sigma_pix)//2*2+1))  # ~3 sigma on each side
    g = gaussian_kernel(k, sigma_pix)
    tmp = np.apply_along_axis(lambda m: np.convolve(m, g, mode='same'), 0, arr)
    sm  = np.apply_along_axis(lambda m: np.convolve(m, g, mode='same'), 1, tmp)
    return sm

def rowwise_peaks(M, q=0.90):
    """For each row (fixed b-index), take local maxima above quantile q of that row."""
    ridges = []
    H, W = M.shape
    for r in range(H):
        row = M[r,:]
        thresh = np.quantile(row[~np.isnan(row)], q) if np.any(~np.isnan(row)) else np.nan
        if np.isnan(thresh):
            continue
        cand = []
        for c in range(1, W-1):
            if np.isnan(row[c-1]) or np.isnan(row[c]) or np.isnan(row[c+1]): 
                continue
            if row[c] >= row[c-1] and row[c] >= row[c+1] and row[c] >= thresh:
                cand.append(c)
        if cand:
            ridges.append((r, cand))
    return ridges

def link_across_rows(ridges, max_jump=2):
    """Link candidate peak columns across adjacent rows into polylines (list of (r,c))."""
    polylines = []
    # map from (row index) to list of columns
    from collections import defaultdict
    col_by_row = defaultdict(list)
    for r, cols in ridges:
        col_by_row[r] = cols[:]
    rows = sorted(col_by_row.keys())
    used = set()
    for r in rows:
        for c in col_by_row[r]:
            if (r,c) in used:
                continue
            # start new polyline
            line = [(r,c)]; used.add((r,c))
            # grow forward
            rf = r+1; prev_c = c
            while rf in col_by_row:
                ccands = col_by_row[rf]
                if not ccands: break
                # choose nearest column to prev_c within max_jump
                diffs = [(abs(prev_c - cc), cc) for cc in ccands]
                diffs.sort()
                if diffs[0][0] <= max_jump:
                    cc = diffs[0][1]
                    if (rf,cc) in used: break
                    line.append((rf,cc)); used.add((rf,cc)); prev_c = cc; rf += 1
                else:
                    break
            # grow backward
            rb = r-1; prev_c = c
            while rb in col_by_row:
                ccands = col_by_row[rb]
                if not ccands: break
                diffs = [(abs(prev_c - cc), cc) for cc in ccands]
                diffs.sort()
                if diffs[0][0] <= max_jump:
                    cc = diffs[0][1]
                    if (rb,cc) in used: break
                    line.insert(0,(rb,cc)); used.add((rb,cc)); prev_c = cc; rb -= 1
                else:
                    break
            polylines.append(line)
    return polylines

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=str, default=".")
    ap.add_argument("--density-csv", type=str, required=True)
    ap.add_argument("--col-l", type=str, default="l_deg")
    ap.add_argument("--col-b", type=str, default="b_deg")
    ap.add_argument("--col-val", type=str, default="local_density")
    ap.add_argument("--grid", type=float, default=0.1, help="grid step (deg)")
    ap.add_argument("--sigma", type=float, default=0.30, help="Gaussian smoothing (deg)")
    ap.add_argument("--ridge-quant", type=float, default=0.90, help="row-wise quantile for ridge peaks")
    ap.add_argument("--max-jump", type=int, default=2, help="max columns jump to link rows")
    ap.add_argument("--min-length", type=int, default=6, help="min vertices per polyline to keep")
    ap.add_argument("--out-geojson", type=str, default="template_arms.geojson")
    ap.add_argument("--out-csv", type=str, default="arms_ridge.csv")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    df = pd.read_csv(root/args.density_csv)
    L = df[args.col-l if args.col_l else "l_deg"] if False else df[args.col_l]
    B = df[args.col_b]
    V = df[args.col_val]
    # bounds
    lmin,lmax = float(np.min(L)), float(np.max(L))
    bmin,bmax = float(np.min(B)), float(np.max(B))
    dl = args.grid; db = args.grid
    nl = int(np.floor((lmax-lmin)/dl))+1
    nb = int(np.floor((bmax-bmin)/db))+1
    # bin mean of V (or counts if V missing)
    H = np.full((nb,nl), np.nan)
    C = np.zeros((nb,nl))
    for l,b,v in zip(L,B,V):
        il = min(nl-1, max(0, int((l-lmin)/dl)))
        ib = min(nb-1, max(0, int((b-bmin)/db)))
        if np.isnan(H[ib,il]):
            H[ib,il] = float(v); C[ib,il]=1.0
        else:
            H[ib,il] += float(v); C[ib,il]+=1.0
    mask = C>0
    H[mask] = H[mask]/C[mask]
    # smoothing: convert sigma deg -> pixels
    sigma_pix = max(0.5, args.sigma/args.grid)
    S = smooth2d(np.nan_to_num(H, nan=np.nanmean(H)), sigma_pix)

    # ridge extraction
    ridges = rowwise_peaks(S, q=args.ridge_quant)
    lines_rc = link_across_rows(ridges, max_jump=args.max_jump)
    lines_rc = [ln for ln in lines_rc if len(ln)>=args.min_length]

    # convert to (l,b) polylines (remember b rows go from bottom to top)
    polylines = []
    for line in lines_rc:
        pts = []
        for r,c in line:
            l = lmin + c*dl
            b = bmin + r*db
            pts.append([float(l), float(b)])
        polylines.append(pts)

    # GeoJSON
    gj = {"type":"FeatureCollection","features":[]}
    for i,pts in enumerate(polylines, start=1):
        gj["features"].append({
            "type":"Feature",
            "properties":{"arm_id": f"arm_{i}"},
            "geometry":{"type":"LineString","coordinates": pts}
        })
    Path(args.out-geojson if False else args.out_geojson).write_text(json.dumps(gj, ensure_ascii=False), encoding="utf-8")

    # CSV
    rows=[]
    for i,pts in enumerate(polylines, start=1):
        for l,b in pts:
            rows.append({"arm_id": f"arm_{i}", "l_deg": l, "b_deg": b})
    pd.DataFrame(rows).to_csv(args.out_csv, index=False)
    print(f"[WRITE] {args.out_geojson} and {args.out_csv} with {len(polylines)} polylines.")

if __name__ == "__main__":
    main()
