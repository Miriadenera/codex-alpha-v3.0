import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Griglia radiale
r = np.linspace(0, 10, 200)
R, T = np.meshgrid(r, np.linspace(0, 2*np.pi, 200))

# Cas A: nodo gaussiano
A, sigma = 1.0, 2.0
K_A = A * np.exp(-R**2 / sigma**2)

# Cas B: nodo con deformazione Schwarzschild (M piccola)
M = 0.5
f = np.sqrt(1 - 2*M / (R + 1e-6))
K_B = A * f * np.exp(-R**2 / sigma**2)

# Cas C: nodo pulsante con materia
omega, lam = 3.0, 0.2
rho = np.exp(-R**2/16)  # densità radiale gaussiana materia
K_C = A * (1 + lam * rho) * np.exp(-R**2 / sigma**2) * np.sin(omega * T)

# Visualizzazione
fig = plt.figure(figsize=(18,5))

# Caso A
ax = fig.add_subplot(131, projection='3d')
ax.plot_surface(R, T, K_A, cmap='viridis', rstride=5, cstride=5)
ax.set_title('Caso A: Nodo Minkowski')
ax.set_xlabel('r'); ax.set_ylabel('θ (fittizio)'); ax.set_zlabel('K')

# Caso B
ax = fig.add_subplot(132, projection='3d')
ax.plot_surface(R, T, K_B, cmap='plasma', rstride=5, cstride=5)
ax.set_title('Caso B: Nodo Schwarzschild')
ax.set_xlabel('r'); ax.set_ylabel('θ'); ax.set_zlabel('K')

# Caso C
ax = fig.add_subplot(133, projection='3d')
ax.plot_surface(R, T, K_C, cmap='inferno', rstride=10, cstride=10)
ax.set_title('Caso C: Nodo Pulsante con Materia')
ax.set_xlabel('r'); ax.set_ylabel('t (fase)'); ax.set_zlabel('K')

plt.tight_layout()
plt.show()
