#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make_gmcs_from_density_holes.py
-------------------------------
Build a GMC circular catalog from low-density "holes" in a gridded density map.

Usage (example):
  python make_gmcs_from_density_holes.py --root "." \
    --density-csv gaia_codex_filtered_density.csv \
    --col-l l_deg --col-b b_deg --col-val local_density \
    --grid 0.1 --hole-quant 0.15 --min-area 6 \
    --out-csv gmc_catalog.csv

Emits:
  - gmc_catalog.csv (l_deg,b_deg,r_deg) circles approximating low-density components
"""
import argparse
import numpy as np
import pandas as pd
from collections import deque
from pathlib import Path

def connected_components(mask):
    H,W = mask.shape
    seen = np.zeros_like(mask, dtype=bool)
    comps = []
    for r in range(H):
        for c in range(W):
            if mask[r,c] and not seen[r,c]:
                q=deque([(r,c)]); seen[r,c]=True; comp=[(r,c)]
                while q:
                    i,j=q.popleft()
                    for di in (-1,0,1):
                        for dj in (-1,0,1):
                            if di==0 and dj==0: continue
                            ni=i+di; nj=j+dj
                            if 0<=ni<H and 0<=nj<W and mask[ni,nj] and not seen[ni,nj]:
                                seen[ni,nj]=True; q.append((ni,nj)); comp.append((ni,nj))
                comps.append(comp)
    return comps

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=str, default=".")
    ap.add_argument("--density-csv", type=str, required=True)
    ap.add_argument("--col-l", type=str, default="l_deg")
    ap.add_argument("--col-b", type=str, default="b_deg")
    ap.add_argument("--col-val", type=str, default="local_density")
    ap.add_argument("--grid", type=float, default=0.1)
    ap.add_argument("--hole-quant", type=float, default=0.15, help="quantile threshold for low-density mask")
    ap.add_argument("--min-area", type=int, default=6, help="minimum component size (pixels)")
    ap.add_argument("--out-csv", type=str, default="gmc_catalog.csv")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    df = pd.read_csv(root/args.density_csv)
    L = df[args.col_l].values; B = df[args.col_b].values; V = df[args.col_val].values
    lmin,lmax = float(np.min(L)), float(np.max(L))
    bmin,bmax = float(np.min(B)), float(np.max(B))
    dl=db=args.grid
    nl = int(np.floor((lmax-lmin)/dl))+1
    nb = int(np.floor((bmax-bmin)/db))+1
    H = np.zeros((nb,nl), dtype=float)
    C = np.zeros((nb,nl), dtype=int)
    for l,b,v in zip(L,B,V):
        il = min(nl-1, max(0, int((l-lmin)/dl)))
        ib = min(nb-1, max(0, int((b-bmin)/db)))
        H[ib,il] += float(v); C[ib,il]+=1
    mask = C>0
    H[mask] = H[mask]/np.maximum(C[mask],1)

    # low-density mask (holes)
    thr = np.quantile(H[mask], args.hole_quant) if np.any(mask) else 0.0
    low = (H<=thr) & mask
    comps = connected_components(low)
    rows=[]
    for comp in comps:
        if len(comp) < args.min_area: 
            continue
        rs = np.array([r for r,c in comp]); cs = np.array([c for r,c in comp])
        r0 = float(np.mean(rs)); c0 = float(np.mean(cs))
        # approximate equivalent radius (pixels)
        area_pix = float(len(comp))
        r_pix = np.sqrt(area_pix/np.pi)
        # map to degrees
        l0 = lmin + c0*dl; b0 = bmin + r0*db
        r_deg = r_pix*dl
        rows.append({"l_deg": l0, "b_deg": b0, "r_deg": r_deg})
    pd.DataFrame(rows).to_csv(root/args.out_csv, index=False)
    print(f"[WRITE] {args.out_csv} with {len(rows)} GMC-like circles.")

if __name__ == "__main__":
    main()
