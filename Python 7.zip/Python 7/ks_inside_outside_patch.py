#!/usr/bin/env python3
# KS inside (min basins) vs outside (non-min / rim) on kinematic variables.
# Adds winsorization and ECDF downsampling for clean plots + CSVs for TikZ.

import argparse, numpy as np, pandas as pd
from scipy.stats import ks_2samp
from scipy.ndimage import binary_dilation
import matplotlib.pyplot as plt

_R = np.array([[-0.0548755604, -0.8734370902, -0.4838350155],
               [ 0.4941094279, -0.4448296300,  0.7469822445],
               [-0.8676661490, -0.1980763734,  0.4559837762]])

def icrs_to_gal_l_b(ra_deg, dec_deg):
    ra  = np.deg2rad(np.asarray(ra_deg, float))
    dec = np.deg2rad(np.asarray(dec_deg, float))
    x = np.cos(dec)*np.cos(ra); y = np.cos(dec)*np.sin(ra); z = np.sin(dec)
    X = _R @ np.vstack([x, y, z])
    l = np.rad2deg(np.arctan2(X[1], X[0])) % 360.0
    b = np.rad2deg(np.arcsin(np.clip(X[2], -1.0, 1.0)))
    return l, b

def ecdf(x):
    x = np.sort(x); n = float(len(x))
    y = np.arange(1, len(x)+1) / n
    return x, y

def thin_ecdf(x, y, n_keep=400):
    if len(x) <= n_keep:
        return x, y
    idx = np.linspace(0, len(x)-1, n_keep).astype(int)
    return x[idx], y[idx]

def parse_args():
    p = argparse.ArgumentParser(description="KS inside (min) vs outside (non-min / rim)")
    p.add_argument("--stars",  required=True)
    p.add_argument("--labels", required=True, help="topo_label_grid_patch.npz")
    p.add_argument("--nodes",  required=True, help="topo_nodes_patch.csv")
    p.add_argument("--vars", nargs="+", default=["mu_total","v_t_kms"])
    p.add_argument("--l-col", default=None)
    p.add_argument("--b-col", default=None)
    p.add_argument("--ra-col", default="ra")
    p.add_argument("--dec-col", default="dec")
    p.add_argument("--out-csv", default="ks_inside_outside_patch.csv")
    p.add_argument("--out-fig", default="ks_inside_outside_patch.png")
    p.add_argument("--min-n", type=int, default=30, help="min samples per side for KS")
    p.add_argument("--winsor", type=float, default=0.995,
                   help="clip both tails to [1-winsor, winsor] quantiles (per variable)")
    p.add_argument("--n-ecdf", type=int, default=400, help="max ECDF points per curve")
    return p.parse_args()

def main():
    a = parse_args()

    # ---- load stars
    df = pd.read_csv(a.stars)
    if a.l_col and a.b_col and a.l_col in df.columns and a.b_col in df.columns:
        l = pd.to_numeric(df[a.l_col], errors="coerce").to_numpy()
        b = pd.to_numeric(df[a.b_col], errors="coerce").to_numpy()
    elif a.ra_col in df.columns and a.dec_col in df.columns:
        l, b = icrs_to_gal_l_b(df[a.ra_col].to_numpy(), df[a.dec_col].to_numpy())
    else:
        raise SystemExit("Need (l,b) or (ra,dec) in star CSV.")

    # ---- topo grid + min labels
    z = np.load(a.labels)
    labels  = z["labels"].astype(int)
    l_edges = z["l_edges"]; b_edges = z["b_edges"]

    nodes = pd.read_csv(a.nodes)
    lab_min = set(int(str(s).split("-")[-1]) for s,t in zip(nodes["ID"], nodes["type"]) if str(t).strip().lower()=="min")

    # map stars to cells
    ix = np.searchsorted(l_edges, l, side="right") - 1
    iy = np.searchsorted(b_edges, b, side="right") - 1
    valid = (ix>=0)&(iy>=0)&(ix<len(l_edges)-1)&(iy<len(b_edges)-1)
    ix = np.clip(ix, 0, len(l_edges)-2); iy = np.clip(iy, 0, len(b_edges)-2)

    lab_star = np.zeros(len(df), dtype=int)
    lab_star[valid] = labels[iy[valid], ix[valid]]

    inside_mask  = np.isin(lab_star, list(lab_min))
    outside_mask = (lab_star>0) & (~inside_mask)

    n_in  = int(inside_mask.sum()); 
    n_out = int(outside_mask.sum())
    print(f"Counts: inside(min)={n_in}, outside(rest)={n_out}")

    # if outside too small, use 1-px rim around min
    if n_out < a.min_n:
        min_mask = np.isin(labels, list(lab_min))
        rim = binary_dilation(min_mask) & (~min_mask)
        rim_star = np.zeros(len(df), dtype=bool)
        rim_star[valid] = rim[iy[valid], ix[valid]]
        outside_mask = rim_star
        n_out = int(outside_mask.sum())
        print(f"Fallback to rim: outside(rim)={n_out}")

    # ---- KS + ECDF (with winsorization and thinning)
    rows = []
    plt.figure(figsize=(9,5))
    plotted_any = False

    for var in a.vars:
        if var not in df.columns:
            print(f"WARN: '{var}' not found, skipping.")
            continue

        xin  = pd.to_numeric(df.loc[inside_mask,  var], errors="coerce").dropna().to_numpy()
        xout = pd.to_numeric(df.loc[outside_mask, var], errors="coerce").dropna().to_numpy()
        if len(xin) < a.min_n or len(xout) < a.min_n:
            print(f"WARN: {var} too few points (inside={len(xin)}, outside={len(xout)}).")
            continue

        # winsor limits on pooled data
        xpool = np.concatenate([xin, xout])
        q = a.winsor
        qlo, qhi = np.quantile(xpool, [1.0-q, q])
        xin  = np.clip(xin,  qlo, qhi)
        xout = np.clip(xout, qlo, qhi)

        stat, p = ks_2samp(xin, xout, alternative="two-sided", mode="auto")
        rows.append({"var":var, "n_in":len(xin), "n_out":len(xout), "ks_stat":stat, "p":p})

        # ECDF
        xi, yi = ecdf(xin);   xi, yi   = thin_ecdf(xi, yi, a.n_ecdf)
        xo, yo = ecdf(xout);  xo, yo   = thin_ecdf(xo, yo, a.n_ecdf)

        # save ECDF for TikZ
        pd.DataFrame({"value":xi, "ecdf":yi}).to_csv(f"ecdf_{var}_inside.csv", index=False)
        pd.DataFrame({"value":xo, "ecdf":yo}).to_csv(f"ecdf_{var}_outside.csv", index=False)

        # plot (nice limits)
        xmin = min(xi.min(), xo.min()); xmax = max(xi.max(), xo.max())
        plt.step(xi, yi, where="post", label=f"{var} inside (n={len(xi)})")
        plt.step(xo, yo, where="post", label=f"{var} outside (n={len(xo)})")
        plt.xlim(xmin, xmax)
        plotted_any = True

    pd.DataFrame(rows).to_csv(a.out_csv, index=False)
    if plotted_any:
        plt.xlabel("Value"); plt.ylabel("ECDF"); plt.grid(alpha=0.25)
        plt.legend(loc="best"); plt.tight_layout()
    else:
        plt.text(0.5,0.5,"No sufficient data",ha="center",va="center",transform=plt.gca().transAxes)
        plt.xlabel("Value"); plt.ylabel("ECDF"); plt.tight_layout()
    plt.savefig(a.out_fig, dpi=220)

if __name__ == "__main__":
    main()
