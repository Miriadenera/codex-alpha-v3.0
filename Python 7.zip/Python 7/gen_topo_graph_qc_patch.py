import json, collections, csv

IN_JSON  = "telascura_topo_graph_v1_patch.json"
OUT_QC   = "topo_graph_qc_patch.csv"
OUT_TOP  = "topo_graph_degree_top10_patch.csv"
TOP_N    = 10

def main():
    with open(IN_JSON, "r", encoding="utf-8") as f:
        g = json.load(f)

    nodes = [n["id"] for n in g.get("nodes", [])]
    edges = [(e["u"], e["v"]) for e in g.get("edges", [])]

    N = len(nodes)
    E = len(edges)

    # degree
    deg = collections.Counter()
    adj = {nid: set() for nid in nodes}
    for u, v in edges:
        if u in adj and v in adj and u != v:
            deg[u] += 1; deg[v] += 1
            adj[u].add(v); adj[v].add(u)

    mean_deg = (2.0 * E / N) if N > 0 else 0.0
    # density for simple undirected graph
    dens = (E / (N * (N - 1) / 2.0)) if N > 1 else 0.0

    # connected components (BFS)
    seen = set()
    comps = []
    for nid in nodes:
        if nid in seen:
            continue
        q = [nid]; seen.add(nid); cur = []
        while q:
            x = q.pop()
            cur.append(x)
            for y in adj[x]:
                if y not in seen:
                    seen.add(y); q.append(y)
        comps.append(cur)

    num_comp = len(comps)
    max_comp = max((len(c) for c in comps), default=0)

    # write QC summary
    rows = [
        ("N_nodes", N),
        ("N_edges", E),
        ("mean_degree", round(mean_deg, 3)),
        ("density", round(dens, 6)),
        ("num_components", num_comp),
        ("largest_component_size", max_comp),
    ]
    with open(OUT_QC, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["metric","value"]); w.writerows(rows)

    # top-10 by degree
    top = sorted(deg.items(), key=lambda kv: (-kv[1], kv[0]))[:TOP_N]
    with open(OUT_TOP, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["id","degree"]); w.writerows(top)

    print("Saved:", OUT_QC, "and", OUT_TOP)

if __name__ == "__main__":
    main()