#!/usr/bin/env python3
import argparse, numpy as np, pandas as pd, matplotlib.pyplot as plt
from pathlib import Path
from PIL import Image

def imread_gray(p):
    return np.asarray(Image.open(p).convert("L"), dtype=float)

def percentile_stretch(a, p1=2, p99=98):
    lo, hi = np.nanpercentile(a, [p1, p99])
    if hi <= lo: hi = lo + 1.0
    return np.clip((a - lo)/(hi - lo), 0, 1)

def parse_axis(arg):
    x1,y1,x2,y2 = [float(t) for t in arg.split(",")]
    return x1,y1,x2,y2

def sample_line_profile(img, x1,y1,x2,y2, width_px=15, nsamp=800):
    t = np.linspace(0, 1, nsamp)
    xs = x1 + (x2-x1)*t
    ys = y1 + (y2-y1)*t
    dx, dy = (x2-x1), (y2-y1)
    L = (dx*dx + dy*dy)**0.5 + 1e-9
    nx, ny = -dy/L, dx/L
    half = max(1, int(round(width_px/2)))
    prof = []
    H, W = img.shape
    for x,y in zip(xs, ys):
        vals = []
        for k in range(-half, half+1):
            xx = int(round(x + nx*k))
            yy = int(round(y + ny*k))
            if 0 <= yy < H and 0 <= xx < W:
                vals.append(img[yy, xx])
        prof.append(np.mean(vals) if vals else np.nan)
    prof = np.array(prof, float)
    if len(prof) > 11:
        k = 11
        ker = np.ones(k, float)/k
        prof = np.convolve(np.nan_to_num(prof, nan=np.nanmedian(prof)), ker, mode="same")
    dist = t * L
    return dist, prof

def color_profile(gimg, rimg, x1,y1,x2,y2, width_px=15, nsamp=800):
    d_g, p_g = sample_line_profile(gimg, x1,y1,x2,y2, width_px, nsamp)
    _,   p_r = sample_line_profile(rimg, x1,y1,x2,y2, width_px, nsamp)
    m_g = np.nanmedian(p_g) or 1.0
    m_r = np.nanmedian(p_r) or 1.0
    g_norm = p_g / m_g
    r_norm = p_r / m_r
    return d_g, (g_norm - r_norm)

def draw_overlay(ax, img, axis, angles_deg=None, lines_csv=None, label=True):
    x1,y1,x2,y2 = axis
    H, W = img.shape
    ax.imshow(percentile_stretch(img), cmap="gray", origin="upper")
    ax.plot([x1,x2], [y1,y2], color="cyan", lw=2.5)
    if lines_csv and Path(lines_csv).exists():
        df = pd.read_csv(lines_csv)
        for _,r in df.iterrows():
            ax.plot([r["x1"],r["x2"]],[r["y1"],r["y2"]], ls="--", lw=1.5, color="orange")
    elif angles_deg:
        cx, cy = 0.5*(x1+x2), 0.5*(y1+y2)
        L = ((x2-x1)**2 + (y2-y1)**2)**0.5 * 0.6
        base = np.arctan2(y2-y1, x2-x1)
        for a in angles_deg:
            th = base + np.deg2rad(a)
            ax.plot([cx-L*np.cos(th), cx+L*np.cos(th)],
                    [cy-L*np.sin(th), cy+L*np.sin(th)],
                    ls=(0,(6,4)), lw=1.8, color="orange")
    if label: ax.set_title("A) Image + axis + putative $\\nabla\\mathcal{K}$ lines")
    ax.set_xlim(0, W); ax.set_ylim(H, 0)
    ax.set_xticks([]); ax.set_yticks([])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--img")
    ap.add_argument("--gimg")
    ap.add_argument("--rimg")
    ap.add_argument("--axis", help="x1,y1,x2,y2 in pixel")
    ap.add_argument("--axis-csv")
    ap.add_argument("--width", type=int, default=15)
    ap.add_argument("--angles")
    ap.add_argument("--lines-csv")
    ap.add_argument("--out-prefix", default="fig72")
    args = ap.parse_args()

    if args.gimg and args.rimg:
        gimg = imread_gray(args.gimg); rimg = imread_gray(args.rimg)
        base_img = gimg
    elif args.img:
        base_img = imread_gray(args.img)
        gimg = rimg = None
    else:
        raise SystemExit("Devi dare --img oppure --gimg e --rimg.")

    H, W = base_img.shape
    if args.axis:
        axis = parse_axis(args.axis)
    elif args.axis_csv and Path(args.axis_csv).exists():
        xy = pd.read_csv(args.axis_csv)
        axis = (float(xy.iloc[0].x), float(xy.iloc[0].y),
                float(xy.iloc[-1].x), float(xy.iloc[-1].y))
    else:
        axis = (0.1*W, 0.5*H, 0.9*W, 0.5*H)

    angles_deg = [float(a) for a in args.angles.split(",")] if args.angles else None

    fig = plt.figure(figsize=(7.5,6.5))
    axA = fig.add_axes([0.07,0.55,0.40,0.40])
    draw_overlay(axA, base_img, axis, angles_deg=angles_deg, lines_csv=args.lines_csv, label=True)

    axB = fig.add_axes([0.57,0.55,0.38,0.40])
    x1,y1,x2,y2 = axis
    dist, sb = sample_line_profile(base_img, x1,y1,x2,y2, width_px=args.width, nsamp=1000)
    sbn = sb/np.nanmedian(sb)
    axB.plot(dist, sbn, lw=2); axB.grid(alpha=0.25)
    axB.set_xlabel("distance along axis [px]")
    axB.set_ylabel("surface brightness (arb., norm.)")
    axB.set_title("B) Surface-brightness profile")

    axC = fig.add_axes([0.07,0.08,0.40,0.40])
    if gimg is not None and rimg is not None:
        dcol, gmr = color_profile(gimg, rimg, x1,y1,x2,y2, width_px=args.width, nsamp=800)
        axC.plot(dcol, gmr, lw=2, label="g − r (arb.)")
        axC.axhline(0, ls="--", lw=1, alpha=0.6)
        axC.set_ylabel("color (arb.)"); axC.legend(frameon=False)
        axC.set_title("C) Color profile (g−r, qualitative)")
    else:
        axC.text(0.5,0.5,"No color bands provided", ha="center", va="center", transform=axC.transAxes)
        axC.set_title("C) Color profile (N/A)")
    axC.set_xlabel("distance along axis [px]"); axC.grid(alpha=0.25)

    axD = fig.add_axes([0.57,0.08,0.38,0.40])
    axD.set_xlim(-1,1); axD.set_ylim(-1,1); axD.set_aspect("equal")
    axD.axhline(0, color="C0", lw=2.5, label="Axis")
    if angles_deg:
        for a in angles_deg:
            th = np.deg2rad(a)
            axD.plot([-np.cos(th), np.cos(th)], [-np.sin(th), np.sin(th)],
                     ls=(0,(6,4)), lw=2, color="orange")
    axD.set_xticks([]); axD.set_yticks([])
    axD.set_title("D) Schematic: putative $\\nabla\\mathcal{K}$ lines")

    out_pdf = f"{args.out_prefix}_context.pdf"
    fig.savefig(out_pdf, bbox_inches="tight")
    print(f"[WRITE] {out_pdf}")

    # --- niente f-string enorme: solo una riga formattata, il resto stringhe normali ---
    tex_lines = [
        "% --- Fig. 72 (context) auto-generated ---",
        "\\begin{figure*}[t]",
        "\\centering",
        f"\\includegraphics[width=0.90\\textwidth]{{{out_pdf}}}",
        "\\caption{Four–panel context figure (image with bridge axis and putative $\\nabla\\mathcal{K}$ coherence lines; surface–brightness profile; color profile; and schematic). Discussion only; no quantitative mixing with our main dataset.}",
        "\\label{fig:context_bridge}",
        "\\end{figure*}",
    ]
    out_tex = f"{args.out_prefix}_latex.txt"
    Path(out_tex).write_text("\n".join(tex_lines), encoding="utf-8")
    print(f"[WRITE] {out_tex}")

if __name__ == "__main__":
    main()
