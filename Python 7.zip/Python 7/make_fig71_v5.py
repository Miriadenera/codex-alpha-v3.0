#!/usr/bin/env python3
import argparse, numpy as np, pandas as pd, matplotlib.pyplot as plt
from pathlib import Path

# ---------- util ----------
def proj_flat_sky(l, b, l0=None, b0=None):
    if l0 is None: l0 = np.nanmedian(l)
    if b0 is None: b0 = np.nanmedian(b)
    x = (l - l0) * np.cos(np.deg2rad(b0))
    y = (b - b0)
    return x, y, l0, b0

def bin_grid(x, y, w, dx):
    xmin, xmax = x.min(), x.max()
    ymin, ymax = y.min(), y.max()
    nx = max(1, int(np.ceil((xmax - xmin)/dx)))
    ny = max(1, int(np.ceil((ymax - ymin)/dx)))
    xb = xmin + dx*(np.arange(nx)+0.5)
    yb = ymin + dx*(np.arange(ny)+0.5)
    N = np.zeros((ny, nx), float)
    W = np.zeros((ny, nx), float)
    ix = np.clip(((x - xmin)/dx).astype(int), 0, nx-1)
    iy = np.clip(((y - ymin)/dx).astype(int), 0, ny-1)
    for i,j in zip(iy, ix): N[i,j] += 1.0
    for i,j,val in zip(iy, ix, w): W[i,j] += val
    Z = N/(W+1e-9)
    XX, YY = np.meshgrid(xb, yb)
    return XX, YY, Z, W, (xmin,xmax,ymin,ymax,dx)

def ls_plane(X, Y, Z, W):
    m = np.isfinite(Z) & (W > 0)
    x = X[m].ravel(); y = Y[m].ravel()
    z = Z[m].ravel(); w = W[m].ravel()
    if x.size == 0: raise RuntimeError("Grid vuota dopo maschera.")
    A = np.c_[np.ones_like(x), x, y]
    Wd = np.diag(w/np.maximum(w.mean(),1e-12))
    AtWA = A.T @ Wd @ A
    AtWz = A.T @ Wd @ z
    c, ax, ay = np.linalg.lstsq(AtWA, AtWz, rcond=None)[0]
    return c, ax, ay

def _iid_bootstrap(XX, YY, Z, W, B, rng):
    betas = []
    m = np.isfinite(Z) & (W > 0)
    x = XX[m].ravel(); y = YY[m].ravel()
    z = Z[m].ravel(); w = W[m].ravel()
    n = x.size
    if n == 0: return np.full((B,2), np.nan)
    # passo in deg sicuro anche con 1 col/1 riga
    dx = (XX[0,-1]-XX[0,0])/(XX.shape[1]-1) if XX.shape[1] > 1 else 1.0
    dy = (YY[-1,0]-YY[0,0])/(YY.shape[0]-1) if YY.shape[0] > 1 else 1.0
    xmin, ymin = XX[0,0], YY[0,0]
    for _ in range(B):
        idx = rng.randint(0, n, size=n)
        Zi = np.zeros_like(Z); Wi = np.zeros_like(W)
        xi, yi, zi, wi = x[idx], y[idx], z[idx], w[idx]
        jx = np.clip(((xi - xmin)/dx).astype(int), 0, XX.shape[1]-1)
        iy = np.clip(((yi - ymin)/dy).astype(int), 0, YY.shape[0]-1)
        for i,j,zij,wij in zip(iy, jx, zi, wi):
            Zi[i,j] += zij; Wi[i,j] += wij
        try:
            _, ax, ay = ls_plane(XX, YY, Zi, Wi)
            betas.append((ax, ay))
        except Exception:
            betas.append((np.nan, np.nan))
    return np.array(betas)

def block_bootstrap(XX, YY, Z, W, step_deg, block_deg=2.0, B=600, rng=np.random.RandomState(42)):
    H, K = Z.shape
    if block_deg <= 0:
        return _iid_bootstrap(XX, YY, Z, W, B, rng)
    dx = float(step_deg)
    bx = max(1, int(round(block_deg/dx)))
    by = bx
    if bx >= K: bx = max(1, K//2)
    if by >= H: by = max(1, H//2)
    gx = int(np.ceil(K / bx)) if bx > 0 else 0
    gy = int(np.ceil(H / by)) if by > 0 else 0
    if gx < 2 or gy < 2:
        return _iid_bootstrap(XX, YY, Z, W, B, rng)

    blocks = []
    for gy0 in range(gy):
        for gx0 in range(gx):
            sl = (slice(gy0*by, min((gy0+1)*by, H)),
                  slice(gx0*bx, min((gx0+1)*bx, K)))
            blocks.append(sl)

    betas = []
    for _ in range(B):
        Zb = np.zeros_like(Z); Wb = np.zeros_like(W)
        for k in rng.choice(len(blocks), len(blocks), replace=True):
            s = blocks[k]
            Zb[s] += Z[s]; Wb[s] += W[s]
        try:
            _, ax, ay = ls_plane(XX, YY, Zb, Wb)
            betas.append((ax, ay))
        except Exception:
            betas.append((np.nan, np.nan))
    return np.array(betas)

def rotate_points(x, y, ang_deg):
    th = np.deg2rad(ang_deg)
    xr = x*np.cos(th) - y*np.sin(th)
    yr = x*np.sin(th) + y*np.cos(th)
    return xr, yr

# ---------- main ----------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--centroids", default="basins_min_centroids.csv")
    ap.add_argument("--sel", default="selection_map_aligned.csv",
                    help="CSV con l_deg(_aligned), b_deg e colonna S (o local_density normalizzata)")
    ap.add_argument("--colL", default="l_deg_aligned")
    ap.add_argument("--colB", default="b_deg")
    ap.add_argument("--colS", default=None, help="colonna selection (S o local_density). Se omessa usa 1.")
    ap.add_argument("--grid", type=float, default=1.0, help="step griglia [deg]")
    ap.add_argument("--B", type=int, default=600, help="bootstrap + null rotazioni")
    ap.add_argument("--block-deg", type=float, default=2.0)
    ap.add_argument("--out-pdf", default="fig71_dipole.pdf")
    ap.add_argument("--out-tex", default="fig71_latex.txt")
    args = ap.parse_args()

    C = pd.read_csv(args.centroids, low_memory=False)
    candL = [c for c in C.columns if c.lower() in (args.colL.lower(),"l_deg_aligned","l_deg","l")]
    candB = [c for c in C.columns if c.lower() in (args.colB.lower(),"b_deg","b")]
    l = pd.to_numeric(C[candL[0]], errors="coerce").values
    b = pd.to_numeric(C[candB[0]], errors="coerce").values
    m = np.isfinite(l) & np.isfinite(b)
    l, b = l[m], b[m]

    x, y, l0, b0 = proj_flat_sky(l, b)

    if args.colS and Path(args.sel).exists():
        S = pd.read_csv(args.sel, low_memory=False)
        candL2 = [c for c in S.columns if c.lower() in ("l_deg_aligned","l_deg","l","lon","longitude")]
        candB2 = [c for c in S.columns if c.lower() in ("b_deg","b","lat","latitude")]
        LS = pd.to_numeric(S[candL2[0]], errors="coerce").values
        BS = pd.to_numeric(S[candB2[0]], errors="coerce").values
        SS = pd.to_numeric(S[args.colS], errors="coerce").values
        xS = (LS - l0) * np.cos(np.deg2rad(b0))
        yS = (BS - b0)
        idx = np.argmin((x[:,None]-xS[None,:])**2 + (y[:,None]-yS[None,:])**2, axis=1)
        w = np.maximum(SS[idx], 1e-6)
        w = w/np.nanmedian(w)
    else:
        w = np.ones_like(x)

    XX, YY, Z, W, bbox = bin_grid(x, y, w, dx=args.grid)
    _, ax, ay = ls_plane(XX, YY, Z, W)
    A  = float(np.hypot(ax, ay))
    phi = float((np.rad2deg(np.arctan2(ay, ax)) + 360) % 360)

    rng = np.random.RandomState(42)
    betas = block_bootstrap(XX, YY, Z, W, step_deg=args.grid,
                            block_deg=args.block_deg, B=args.B, rng=rng)
    axb, ayb = betas[:,0], betas[:,1]
    Ab = np.sqrt(axb**2 + ayb**2)

    rng2 = np.random.RandomState(7)
    A_null = []
    for th in rng2.uniform(0, 360, size=args.B):
        xr, yr = rotate_points(x, y, th)
        XXr, YYr, Zr, Wr, _ = bin_grid(xr, yr, w, dx=args.grid)
        try:
            _, axr, ayr = ls_plane(XXr, YYr, Zr, Wr)
            A_null.append(np.hypot(axr, ayr))
        except Exception:
            A_null.append(np.nan)
    A_null = np.array(A_null)
    med_null = float(np.nanmedian(A_null))
    lo, hi = [float(v) for v in np.nanpercentile(A_null, [2.5, 97.5])]

    fig = plt.figure(figsize=(6.6,3.7))
    axm = fig.add_axes([0.08,0.14,0.52,0.78])
    axm.pcolormesh(XX, YY, Z, shading="nearest")
    axm.scatter(x, y, s=6, c="k", alpha=0.4)
    L = 0.4*max(bbox[1]-bbox[0], bbox[3]-bbox[2])
    axm.arrow(0,0, L*np.cos(np.deg2rad(phi)), L*np.sin(np.deg2rad(phi)),
              width=0.02, head_width=0.25, color="w", length_includes_head=True)
    axm.set_xlabel("x [deg]"); axm.set_ylabel("y [deg]")
    axm.set_title("Flat–sky dipole fit")

    axr = fig.add_axes([0.68,0.17,0.28,0.74])
    axr.bar([0],[A], width=0.4)
    axr.vlines([0], [np.nanpercentile(Ab,2.5)], [np.nanpercentile(Ab,97.5)], lw=2)
    axr.hlines([med_null], -0.35, 0.35, linestyles="--", lw=1)
    axr.fill_between([-0.35,0.35], [lo,lo], [hi,hi], alpha=0.15)
    axr.set_xlim(-0.5,0.5); axr.set_xticks([0]); axr.set_xticklabels(["A"])
    axr.set_title("Amplitude vs null")
    fig.savefig(args.out_pdf, bbox_inches="tight")

    # f-string con graffe raddoppiate (niente bug)
    tex = f"""
% --- Fig. 71 (generated) ---
\\begin{{figure}}[t]
\\centering
\\includegraphics[width=0.86\\textwidth]{{{args.out_pdf}}}
\\caption{{Flat–sky dipole map with best–fit axis and 68/95\\% uncertainty cones; side panel:
amplitude $A$ vs null band (block bootstrap / rotations).}}
\\label{{fig:lg_dipole}}
\\end{{figure}}
""".strip()
    Path(args.out_tex).write_text(tex, encoding="utf-8")
    print(f"[WRITE] {args.out_pdf}")
    print(f"[WRITE] {args.out_tex}")
    print(f"[RESULT] ax={ax:.4g}, ay={ay:.4g}; A={A:.4g}; phi={phi:.1f} deg; null med={med_null:.4g} [{lo:.4g},{hi:.4g}]")

if __name__ == "__main__":
    main()
