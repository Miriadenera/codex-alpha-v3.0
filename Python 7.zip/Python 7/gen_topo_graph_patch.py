#!/usr/bin/env python3
# Build a Telascura graph (v1) from the patched topological products.
# Inputs: topo_nodes_patch.csv, topo_label_grid_patch.npz
# Outputs: telascura_topo_graph_v1_patch.json, topo_edges_patch.geojson
# ASCII-only.

import json
import argparse
import numpy as np
import pandas as pd

DEF_NODES_CSV = "topo_nodes_patch.csv"
DEF_NPZ       = "topo_label_grid_patch.npz"
DEF_OUT_JSON  = "telascura_topo_graph_v1_patch.json"
DEF_OUT_GJ    = "topo_edges_patch.geojson"

def parse_args():
    p = argparse.ArgumentParser(
        description="Build Telascura topo graph v1 (adjacency from label grid)."
    )
    p.add_argument("--nodes", default=DEF_NODES_CSV)
    p.add_argument("--npz",   default=DEF_NPZ)
    p.add_argument("--out-json", default=DEF_OUT_JSON)
    p.add_argument("--out-geojson", default=DEF_OUT_GJ)
    return p.parse_args()

def centroid_dist_deg(a_l, a_b, b_l, b_b):
    # small-angle distance in deg (scale l by cos of mean b)
    b_mean = 0.5 * (a_b + b_b)
    dl = (a_l - b_l) * np.cos(np.deg2rad(b_mean))
    db = (a_b - b_b)
    return float(np.hypot(dl, db))

def unique_pairs_from_grid(labels):
    """Return sorted unique label pairs (a<b) that touch in the raster."""
    lab = labels.astype(np.int32)
    H, W = lab.shape
    pairs = []

    # horizontal neighbors
    a = lab[:, :-1]; b = lab[:, 1:]
    m = (a > 0) & (b > 0) & (a != b)
    if m.any():
        ab = np.stack([np.minimum(a,b), np.maximum(a,b)], axis=-1)[m]
        pairs.append(ab)

    # vertical neighbors
    a = lab[:-1, :]; b = lab[1:, :]
    m = (a > 0) & (b > 0) & (a != b)
    if m.any():
        ab = np.stack([np.minimum(a,b), np.maximum(a,b)], axis=-1)[m]
        pairs.append(ab)

    # diag down-right
    a = lab[:-1, :-1]; b = lab[1:, 1:]
    m = (a > 0) & (b > 0) & (a != b)
    if m.any():
        ab = np.stack([np.minimum(a,b), np.maximum(a,b)], axis=-1)[m]
        pairs.append(ab)

    # diag down-left
    a = lab[:-1, 1:]; b = lab[1:, :-1]
    m = (a > 0) & (b > 0) & (a != b)
    if m.any():
        ab = np.stack([np.minimum(a,b), np.maximum(a,b)], axis=-1)[m]
        pairs.append(ab)

    if not pairs:
        return []

    all_pairs = np.vstack(pairs)
    # deduplicate
    all_pairs = np.unique(all_pairs, axis=0)
    return [tuple(map(int, p)) for p in all_pairs]

def main():
    args = parse_args()

    nodes = pd.read_csv(args.nodes)
    z = np.load(args.npz)
    labels = z["labels"].astype(np.int32)

    # map numeric label -> ID ("T-Topo-XXXX" -> XXXX)
    label_to_id = {}
    for _, r in nodes.iterrows():
        try:
            labnum = int(str(r["ID"]).split("-")[-1])
            label_to_id[labnum] = str(r["ID"])
        except Exception:
            pass

    # adjacency from touching labels in the raster
    touching = unique_pairs_from_grid(labels)

    # build edges
    edges = []
    for a, b in touching:
        if a in label_to_id and b in label_to_id:
            u = label_to_id[a]; v = label_to_id[b]
            ra = nodes.loc[nodes["ID"] == u, ["l_mean","b_mean"]].values
            rb = nodes.loc[nodes["ID"] == v, ["l_mean","b_mean"]].values
            if len(ra)==1 and len(rb)==1:
                w = centroid_dist_deg(float(ra[0,0]), float(ra[0,1]),
                                      float(rb[0,0]), float(rb[0,1]))
                edges.append({"u":u, "v":v, "type":"adjacent_basin", "weight":w})

    # graph JSON
    graph = {
        "version": "telascura-map-v1",
        "nodes": [{
            "id": str(r["ID"]),
            "l": float(r["l_mean"]), "b": float(r["b_mean"]),
            "type": str(r["type"]),
            "area_deg2": float(r["area_deg2"]),
            "Nstars": float(r["Nstars"]),
            "K_mean": float(r["K_mean"]),
            "gradK_mean": float(r["gradK_mean"]),
            "persistence_G": float(r["persistence"]),
            "persistence_K": float(r["persistence_K"])
        } for _, r in nodes.iterrows()],
        "edges": edges,
        "meta": {
            "source": "topo_patch_segment_gradk.py",
            "adjacency": "touching pixels (4+diagonals)"
        }
    }

    with open(args.out_json, "w", encoding="utf-8") as f:
        json.dump(graph, f, indent=2)
    print("Saved graph:", args.out_json, "nodes:", len(graph["nodes"]), "edges:", len(edges))

    # edges GeoJSON (LineString between centroids)
    features = []
    for e in edges:
        ra = nodes.loc[nodes["ID"]==e["u"], ["l_mean","b_mean"]].values[0]
        rb = nodes.loc[nodes["ID"]==e["v"], ["l_mean","b_mean"]].values[0]
        features.append({
            "type":"Feature",
            "properties":{"u":e["u"],"v":e["v"],"weight":e["weight"]},
            "geometry":{"type":"LineString","coordinates":[[float(ra[0]),float(ra[1])],
                                                          [float(rb[0]),float(rb[1])]]}
        })
    gj = {"type":"FeatureCollection","features":features,
          "crs":{"type":"name","properties":{"name":"galactic_l_b_deg"}}}
    with open(args.out_geojson, "w", encoding="utf-8") as f:
        json.dump(gj, f)
    print("Saved edges GeoJSON:", args.out_geojson, "features:", len(features))

if __name__ == "__main__":
    main()
